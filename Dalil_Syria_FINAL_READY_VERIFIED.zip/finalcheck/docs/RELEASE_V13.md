# Release V13

Core remains V0.12. This package is the next implementation increment and supersedes V12.

Tests: 46 passed.
