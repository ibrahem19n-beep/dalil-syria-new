"""Small, replay-safe outbox publisher foundation. Transport is injected by the caller."""
from ..db import get_conn

def claim_batch(limit=50):
    with get_conn() as conn:
        rows=conn.execute("""WITH picked AS (SELECT id FROM commerce.outbox_events WHERE status='pending' AND available_at<=now() ORDER BY id FOR UPDATE SKIP LOCKED LIMIT %s)
        UPDATE commerce.outbox_events o SET status='processing',attempts=attempts+1 FROM picked WHERE o.id=picked.id RETURNING o.*""",(limit,)).fetchall(); conn.commit(); return rows

def mark_published(event_id):
    with get_conn() as conn:
        conn.execute("UPDATE commerce.outbox_events SET status='published',published_at=now() WHERE event_id=%s",(event_id,)); conn.commit()

def mark_failed(event_id,error):
    with get_conn() as conn:
        conn.execute("UPDATE commerce.outbox_events SET status=CASE WHEN attempts>=10 THEN 'failed' ELSE 'pending' END,last_error=%s,available_at=now()+least(interval '1 hour', interval '5 seconds' * power(2,least(attempts,8))) WHERE event_id=%s",(str(error)[:2000],event_id)); conn.commit()
