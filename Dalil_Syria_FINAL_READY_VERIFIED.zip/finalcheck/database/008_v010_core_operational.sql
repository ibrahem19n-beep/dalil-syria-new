-- V0.10 core operational hardening
CREATE INDEX IF NOT EXISTS idx_places_status_verification ON places(status, verification_status);
CREATE INDEX IF NOT EXISTS idx_places_location_status ON places(location_id, status);
CREATE INDEX IF NOT EXISTS idx_reviews_place_status ON reviews(place_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_favorites_user_created ON favorites(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reports_status_created ON reports(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id, created_at DESC);

-- Keep coordinates and PostGIS geometry synchronized for existing/new records.
CREATE OR REPLACE FUNCTION sync_place_geom() RETURNS trigger AS $$
BEGIN
  IF NEW.latitude IS NOT NULL AND NEW.longitude IS NOT NULL THEN
    NEW.geom := ST_SetSRID(ST_MakePoint(NEW.longitude, NEW.latitude),4326)::geography;
  ELSE
    NEW.geom := NULL;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_sync_place_geom ON places;
CREATE TRIGGER trg_sync_place_geom BEFORE INSERT OR UPDATE OF latitude, longitude ON places
FOR EACH ROW EXECUTE FUNCTION sync_place_geom();

UPDATE places SET geom = CASE WHEN latitude IS NOT NULL AND longitude IS NOT NULL
 THEN ST_SetSRID(ST_MakePoint(longitude,latitude),4326)::geography ELSE NULL END
WHERE geom IS DISTINCT FROM CASE WHEN latitude IS NOT NULL AND longitude IS NOT NULL
 THEN ST_SetSRID(ST_MakePoint(longitude,latitude),4326)::geography ELSE NULL END;
