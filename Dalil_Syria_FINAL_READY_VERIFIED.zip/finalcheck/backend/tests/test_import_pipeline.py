from app.import_pipeline import parse_csv, validate_row, classify_duplicate

def test_csv_normalization_and_aliases():
    rows=parse_csv('\ufeffالاسم,الهاتف,العنوان\n مطعم دمشق , 0999  , الشام  ')
    assert rows[0]['name']=='مطعم دمشق'
    assert rows[0]['phone']=='0999'

def test_import_validation():
    assert validate_row({'name':'مكان'}).valid
    assert not validate_row({'name':''}).valid
    assert not validate_row({'name':'x','latitude':'91','longitude':'36'}).valid

def test_duplicate_classification():
    row={'name':'مطعم دمشق','phone':'0999'}
    result=classify_duplicate(row,[{'id':12,'name':'مطعم دمشق','phone':'0999'}])
    assert result['duplicate'] is True and result['place_id']==12
