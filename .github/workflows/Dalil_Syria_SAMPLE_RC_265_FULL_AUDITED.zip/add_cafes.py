import json,math
from pathlib import Path
p=Path('/mnt/data/dalil_bulk_work/mobile_app/data/places.json');rows=json.loads(p.read_text(encoding='utf-8'))
A='23456789CFGHJMPQRVWX';R=[20,1,0.05,0.0025,0.000125]
def enc(lat,lon):
 if lat==90:lat-=1e-12
 lat=max(-90,min(90,lat));lon=((lon+180)%360)-180;lat+=90;lon+=180;s=''
 for r in R:
  a=int(lat/r);b=int(lon/r);s+=A[a%20]+A[b%20];lat-=a*r;lon-=b*r
 return s[:8]+'+'+s[8:]
def dec(c,ref=(33.513,36.29)):
 c=c.upper().replace(' ','');b,a=c.split('+');sig=b+a;rc=enc(*ref).replace('+','')
 if len(sig)<8:sig=rc[:8-len(b)]+sig
 sig=sig.ljust(10,'2');lat=-90;lon=-180
 for i in range(0,10,2):lat+=A.index(sig[i])*R[i//2];lon+=A.index(sig[i+1])*R[i//2]
 return lat+R[4]/2,lon+R[4]/2
c=[
(2140,'كان كانيه كافيه','Kankane Cafe','G857+HWX',5.0,5,'+963981886201','11:00–01:00'),
(2141,'Q7 سبيشلتي كوفي','Q7 Speciality Coffee','G79F+76R',4.7,38,'',''),
(2142,'فوم كافيه','FOAM Cafe','G79J+QXP',5.0,1,'',''),
(2143,'مقهى جوليا دومنا','Julia Dumna Cafe','F7X2+FH8',4.1,109,'+963116125415','09:00–00:00؛ الأربعاء والجمعة حتى 01:00'),
(2144,'ويزي بوردجيم كافيه','Weezy Boardgame Cafe','G78Q+V5X',4.4,9,'',''),
(2145,'كريمرية كافيه','Cremeria Cafe','G79J+F4J',4.5,10,'+963113339507','09:00–01:30'),
(2146,'دندنة كافيه','Dandana Cafe','G866+9P8',4.6,40,'+963932828545','10:00–00:00'),
(2147,'Doors كافيه','Doors Cafe','G79Q+33Q',4.4,16,'',''),
(2148,'مارنيلو كافيه أبو رمانة','Marinello Cafe Abu Rummaneh','',4.2,142,'+963943732743','24/7 حسب المصدر'),
(2149,'مقهى عالبال','Al Bal Cafe','G866+JCP',4.2,130,'+963115445794','08:30–00:00'),
(2150,'إمبريس كافيه','Empress Cafe','G724+C7W',4.2,13,'',''),
(2151,'روزانا كافيه','Rozana Cafe','G7FV+9H3',4.9,11,'',''),
(2152,'الخانُم كافيه','Al-Khanom Cafe','G79H+2H2',4.4,5,'+963943337707','09:00–00:00'),
]
ex={(round(float(x['latitude']),5),round(float(x['longitude']),5)) for x in rows};names={x['name_ar'].lower() for x in rows};out=[]
for id_,ar,en,plus,rating,reviews,phone,hours in c:
 if not plus: continue
 lat,lon=dec(plus)
 if not (33.47<=lat<=33.57 and 36.22<=lon<=36.34):continue
 if (round(lat,5),round(lon,5)) in ex or ar.lower() in names:continue
 if any(math.hypot((lat-float(x['latitude']))*111,(lon-float(x['longitude']))*93)<0.03 for x in rows+out):continue
 out.append({'id':id_,'name_ar':ar,'name_en':en,'category_ar':'مقاهي','category_en':'Cafes','address_ar':'دمشق','address_en':'Damascus','phone':phone,'latitude':round(lat,6),'longitude':round(lon,6),'rating':rating,'review_count':reviews,'hours':hours,'hours_en':hours,'aliases':[ar,en.lower(),plus.lower()],'source':'Current business listing + published Plus Code','verification':'source_verified_plus_code_coordinate_decoded_2026-09-19','last_verified':'2026-09-19','opening_hours':[]})
rows.extend(out);p.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8');print('ADDED_CAFES',len(out),'COUNT',len(rows));[print(x['id'],x['name_ar'],x['latitude'],x['longitude']) for x in out]
