# API Contract V1

GET /api/v1/places
GET /api/v1/places/{place_id}
GET /api/v1/search?q=&page=&limit=
GET /api/v1/nearby?latitude=&longitude=&radius_m=
GET /api/v1/places/{place_id}/around?radius_m=

Future authenticated endpoints:
POST /api/v1/me/favorites/{place_id}
DELETE /api/v1/me/favorites/{place_id}
POST /api/v1/places/{place_id}/reviews
POST /api/v1/places/{place_id}/reports

Admin namespace:
 /api/v1/admin/places
 /api/v1/admin/brands
 /api/v1/admin/locations
 /api/v1/admin/reports
 /api/v1/admin/reviews
 /api/v1/admin/audit-logs
