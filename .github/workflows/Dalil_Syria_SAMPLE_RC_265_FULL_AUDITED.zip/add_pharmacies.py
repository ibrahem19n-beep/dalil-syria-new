import json,math
from pathlib import Path
p=Path('/mnt/data/dalil_bulk_work/mobile_app/data/places.json'); rows=json.loads(p.read_text(encoding='utf-8'))
A='23456789CFGHJMPQRVWX';R=[20,1,0.05,0.0025,0.000125]
def enc(lat,lon):
 if lat==90: lat-=1e-12
 lat=max(-90,min(90,lat));lon=((lon+180)%360)-180;lat+=90;lon+=180;s=''
 for r in R:
  a=int(lat/r);b=int(lon/r);s+=A[a%20]+A[b%20];lat-=a*r;lon-=b*r
 return s[:8]+'+'+s[8:]
def dec(c,ref=(33.513,36.29)):
 c=c.upper().replace(' ','');b,a=c.split('+');sig=b+a;rc=enc(*ref).replace('+','')
 if len(sig)<8:sig=rc[:8-len(b)]+sig
 sig=sig.ljust(10,'2');lat=-90;lon=-180
 for i in range(0,10,2):lat+=A.index(sig[i])*R[i//2];lon+=A.index(sig[i+1])*R[i//2]
 return lat+R[4]/2,lon+R[4]/2
c=[
(2104,'صيدلية مولهم','Moulham Pharmacy','G63X+22R','+963116669418',5.0,1,'09:00–23:00'),
(2105,'صيدلية ريتا زورق','Rita Zorak Pharmacy','G878+Q6J','+963115420075',5.0,1,'09:00–22:00'),
(2106,'صيدلية السواح','Al-Sawah Pharmacy','F7XJ+9F9','',4.6,9,''),
(2107,'صيدلية المهاجرين','Al-Muhajreen Pharmacy','G7FF+4R9','+9633717379',4.0,3,'09:00–22:00'),
(2108,'صيدلية رزان','Razan Pharmacy','G742+J97','',4.8,5,'10:00–22:00'),
(2109,'صيدلية اليسر كفرسوسة','Al-Yusr Kafr Sousa Pharmacy','F7XG+9H8','+9632142979',None,0,''),
(2110,'صيدلية هيدروجين','Hydrogen Pharmacy','G62R+84W','+963955191168',5.0,1,'10:00–22:00'),
(2111,'صيدلية كفرسوسة','Kafr Sousa Pharmacy','F7WH+MP5','+963112113032',None,0,''),
(2112,'صيدلية غزال','Ghazal Pharmacy','G79J+R73','',5.0,1,''),
(2113,'صيدلية جورجيت جحا','Georgette Joha Pharmacy','G878+W3G','',4.0,1,''),
(2114,'صيدلية نور بقلة','Nour Baqla Pharmacy','G72G+46M','',5.0,1,''),
(2115,'Pharma C+','Pharma C+ Pharmacy','G79P+W69','+963932345831',3.0,1,'08:00–00:00'),
(2116,'صيدلية ضي','Dhay Pharmacy','G742+7PX','',5.0,1,'09:30–00:00 + مناوبات ليلية'),
(2117,'صيدلية إنعام البطل','Inam Al-Batal Pharmacy','G866+74F','',3.0,1,''),
(2118,'صيدلية البيداء','Al-Baida Pharmacy','F7M5+5FQ','',5.0,1,''),
(2119,'صيدلية الجادات','Al-Jaddat Pharmacy','G7HH+5V6','',5.0,1,''),
]
ex={(round(float(x['latitude']),5),round(float(x['longitude']),5)) for x in rows}; names={x['name_ar'].lower() for x in rows};out=[]
for id_,ar,en,plus,phone,rating,reviews,hours in c:
 lat,lon=dec(plus)
 if not (33.47<=lat<=33.57 and 36.22<=lon<=36.34): continue
 if (round(lat,5),round(lon,5)) in ex or ar.lower() in names: continue
 if any(math.hypot((lat-float(x['latitude']))*111,(lon-float(x['longitude']))*93)<0.03 for x in rows+out): continue
 out.append({'id':id_,'name_ar':ar,'name_en':en,'category_ar':'صيدليات','category_en':'Pharmacies','address_ar':'دمشق','address_en':'Damascus','phone':phone,'latitude':round(lat,6),'longitude':round(lon,6),'rating':rating if rating is not None else 0,'review_count':reviews,'hours':hours,'hours_en':hours,'aliases':[ar,en.lower(),plus.lower()],'source':'Current business listing + published Plus Code','verification':'source_verified_plus_code_coordinate_decoded_2026-09-19','last_verified':'2026-09-19','opening_hours':[]})
rows.extend(out);p.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8');print('ADDED_PHARMACIES',len(out),'COUNT',len(rows));[print(x['id'],x['name_ar'],x['latitude'],x['longitude']) for x in out]
