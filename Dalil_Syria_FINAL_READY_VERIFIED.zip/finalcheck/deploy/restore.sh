#!/usr/bin/env sh
set -eu
if [ "${1:-}" = "" ]; then
  echo "Usage: $0 /path/to/backup.dump" >&2
  exit 2
fi
if [ "${CONFIRM_RESTORE:-}" != "YES" ]; then
  echo "Restore is destructive. Re-run with CONFIRM_RESTORE=YES." >&2
  exit 2
fi
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"
cat "$1" | docker compose -f deploy/docker-compose.production.yml exec -T db pg_restore -U dalil -d dalil_syria --clean --if-exists --no-owner --no-privileges
