# Dalil Syria — UI/UX Complete RC1

This package consolidates the current UI/UX work on top of the Dalil Syria V0.12 technical baseline.

## Included
- Public mobile-first discovery UI
- Search, filters, map/list experience
- Place details, hours, reviews, favorites, account flows
- Admin panel foundation and management flows
- API-connected frontend behavior
- Maps foundation integration
- Responsive Arabic RTL layout with English-ready structure
- Security/session handling fixes from the technical baseline

## Verification
- Pytest: 40 passed
- Final photographic/icon/splash/store assets are intentionally NOT installed yet.

## Next gate
Visual asset selection: choose the final app icon, splash, place imagery direction, and store/marketing visuals before installation.


## Selected Visual Asset Integration
- Official selected visual asset: `mobile_app/assets/brand/dalil-syria-selected.png`
- Source is the user-approved second image; no alternate generated image was substituted.
- Integrated into the mobile-first hero and PWA manifest.
- No new visual asset was generated or substituted.


## Visual Asset Gate — V1
- Approved primary visual: `mobile_app/assets/brand/dalil-syria-selected.png`
- This file is the user's approved second image: no Aleppo Citadel, no people, with Euphrates Dam/water, jasmine, Umayyad Mosque, Roman arch, and the selected Syrian visual composition.
- The approved primary visual is preserved exactly; no regeneration, retouching, replacement, or alternate image was introduced.
- App icon, splash artwork, internal photographic set, and store screenshots remain **unselected** and are not installed as final assets.
- PWA manifest no longer treats the primary photographic visual as the final app icon. Icon selection is a separate approval gate.
