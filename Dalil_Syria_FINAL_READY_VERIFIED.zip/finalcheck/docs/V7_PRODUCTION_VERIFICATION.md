# Dalil Syria — V7 Production Verification

V7 closes the production-verification layer around the existing backend/commerce foundation.

## Automated checks
- Python compilation
- Full pytest suite
- Production security static checks
- Container exposure checks
- Non-root backend check
- Read-only backend filesystem check
- Caddy/HSTS configuration checks
- Insecure database credential fallback check

## Load smoke
Set `DALIL_LOAD_URL` to `/health` or `/ready` on a reachable deployment and run:

`./deploy/load_check.sh`

Optional: `DALIL_LOAD_REQUESTS=1000`.

A real production load test still requires a deployed environment and realistic traffic/data; this package does not pretend that local smoke tests are equivalent.
