# Dalil Syria — RC2

Release Candidate 2. This build hardens the RC1 foundation for production:

- Strict production authentication-secret validation (32+ characters).
- Explicit production CORS policy; wildcard is rejected.
- Process-local rate limiting on login attempts (10/minute/IP).
- Release health/readiness identify RC2.
- Existing V0.7–V0.12 functionality is preserved.

## Validation
Run:

`pytest -q`

For production, provide strong `POSTGRES_PASSWORD`, `DALIL_AUTH_SECRET`, and explicit `DALIL_CORS_ORIGINS`.
