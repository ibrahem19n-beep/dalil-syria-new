# Release V15 — Import Foundation
Core remains V0.12. This package adds the provider-neutral import preparation layer and tests.

Automated QA: 49/49 passed.
