"""Production container entrypoint for replay-safe background processing.

The runtime deliberately keeps transport adapters provider-neutral. In the current
release, events are acknowledged only after the injected sink succeeds; the default
sink is an operational no-op/logger so no external message is sent accidentally.
"""
from __future__ import annotations
import json, logging, os
from .worker import run_forever

logging.basicConfig(level=os.getenv('DALIL_WORKER_LOG_LEVEL', 'INFO'))
log = logging.getLogger('dalil.worker')


def publish(event: dict) -> None:
    # Future broker/provider adapters plug in here. Never claim delivery to an
    # external system until that adapter actually confirms success.
    log.info('outbox event processed: %s', json.dumps(event, default=str, ensure_ascii=False))


def send(notification: dict) -> None:
    # Safe default: notifications are queued and processed, but no external
    # provider is contacted until an approved adapter is configured.
    log.info('notification processed: id=%s channel=%s', notification.get('id'), notification.get('channel'))


if __name__ == '__main__':
    interval = float(os.getenv('DALIL_WORKER_INTERVAL_SECONDS', '2'))
    batch = int(os.getenv('DALIL_WORKER_BATCH_SIZE', '50'))
    run_forever(publish, send, interval_seconds=interval, batch_size=batch)
