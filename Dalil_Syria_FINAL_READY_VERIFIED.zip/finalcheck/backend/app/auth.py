import base64, hashlib, hmac, json, os, time, uuid
from fastapi import Header, HTTPException
TOKEN_TTL_SECONDS = int(os.getenv('DALIL_TOKEN_TTL_SECONDS', '3600'))
_SECRET = os.getenv('DALIL_AUTH_SECRET', '')
def _b64(data: bytes) -> str: return base64.urlsafe_b64encode(data).rstrip(b'=').decode()
def _unb64(value: str) -> bytes: return base64.urlsafe_b64decode(value + '=' * (-len(value) % 4))
def hash_password(password: str) -> str:
    salt=os.urandom(16); digest=hashlib.scrypt(password.encode(),salt=salt,n=2**14,r=8,p=1); return f'scrypt${_b64(salt)}${_b64(digest)}'
def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme,salt,digest=encoded.split('$',2)
        if scheme!='scrypt': return False
        candidate=hashlib.scrypt(password.encode(),salt=_unb64(salt),n=2**14,r=8,p=1)
        return hmac.compare_digest(candidate,_unb64(digest))
    except Exception: return False
def create_token(user_id:int,roles:list[str])->str:
    if not _SECRET: raise RuntimeError('DALIL_AUTH_SECRET is not configured')
    header=_b64(json.dumps({'alg':'HS256','typ':'JWT'},separators=(',',':')).encode())
    payload=_b64(json.dumps({'sub':str(user_id),'roles':roles,'iat':int(time.time()),'exp':int(time.time())+TOKEN_TTL_SECONDS,'jti':uuid.uuid4().hex},separators=(',',':')).encode())
    body=f'{header}.{payload}'.encode(); sig=_b64(hmac.new(_SECRET.encode(),body,hashlib.sha256).digest()); return f'{header}.{payload}.{sig}'
def decode_token(token:str)->dict:
    if not _SECRET: raise HTTPException(503,'Authentication is not configured')
    try:
        header,payload,sig=token.split('.'); header_data=json.loads(_unb64(header))
        if header_data.get('alg') != 'HS256' or header_data.get('typ') != 'JWT': raise ValueError()
        expected=_b64(hmac.new(_SECRET.encode(),f'{header}.{payload}'.encode(),hashlib.sha256).digest())
        if not hmac.compare_digest(sig,expected): raise ValueError()
        data=json.loads(_unb64(payload))
        if int(data.get('exp',0))<int(time.time()): raise ValueError()
        return data
    except Exception: raise HTTPException(401,'Invalid or expired access token')
def current_user(authorization:str|None=Header(default=None)):
    if not authorization or not authorization.lower().startswith('bearer '): raise HTTPException(401,'Bearer access token required')
    return decode_token(authorization.split(' ',1)[1].strip())
def require_admin(authorization:str|None=Header(default=None)):
    data=current_user(authorization)
    try:
        from .db import get_conn
        with get_conn() as conn:
            row=conn.execute(
                "SELECT u.status, COALESCE(array_agg(r.name) FILTER (WHERE r.name IS NOT NULL), ARRAY[]::text[]) AS roles "
                "FROM users u LEFT JOIN user_roles ur ON ur.user_id=u.id LEFT JOIN roles r ON r.id=ur.role_id "
                "WHERE u.id=%s GROUP BY u.id", (int(data['sub']),)
            ).fetchone()
        if not row or row['status'] != 'active': raise HTTPException(401,'User is inactive')
        roles=set(row['roles'] or [])
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(503,'Authorization service unavailable')
    if not roles.intersection({'admin','super_admin','finance_admin'}): raise HTTPException(403,'Admin role required')
    data['roles']=sorted(roles)
    return data

REFRESH_TOKEN_TTL_SECONDS = int(os.getenv('DALIL_REFRESH_TOKEN_TTL_SECONDS', str(60 * 60 * 24 * 30)))

def create_refresh_token() -> str:
    return _b64(os.urandom(48))

def hash_refresh_token(token: str) -> str:
    return hashlib.sha256(token.encode('utf-8')).hexdigest()
