from pathlib import Path


def test_release_metadata_endpoint_and_marker():
    text = Path('backend/app/main.py').read_text()
    assert '@app.get("/api/v1/meta")' in text
    assert '"release": "1.0.0"' in text


def test_release_preflight_exists_and_is_executable():
    p = Path('deploy/release_check.sh')
    assert p.exists()
    assert p.stat().st_mode & 0o111


def test_release_docs_exist():
    assert Path('README_RELEASE.md').exists()
