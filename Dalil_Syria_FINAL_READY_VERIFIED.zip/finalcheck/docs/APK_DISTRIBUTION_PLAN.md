# Dalil Syria APK Distribution Plan

The Android app is distributed as a real standalone APK, not a PWA.

Build path:
- Android source: `android/`
- CI workflow: `.github/workflows/android-build.yml`
- Output: `android/app/build/outputs/apk/debug/app-debug.apk`

Production requirements before public release:
1. Build a release APK, not debug.
2. Create and securely preserve a permanent signing key.
3. Never lose the signing key; all future updates must use it.
4. Host APK and SHA-256 on a stable HTTPS domain.
5. Publish clear installation/update instructions.
6. Keep a rollback copy of every released APK.
7. Do not use fake signatures, modified APK mirrors, or untrusted distribution sites.

This workflow is a build bridge. It does not claim that a signed production APK already exists.
