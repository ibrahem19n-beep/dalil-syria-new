-- V0.13 technical hardening: operational notification/outbox foundation.
CREATE TABLE IF NOT EXISTS notification_templates (
 id BIGSERIAL PRIMARY KEY, code VARCHAR(120) NOT NULL UNIQUE, channel VARCHAR(30) NOT NULL, subject TEXT, body TEXT NOT NULL, language_code VARCHAR(10) NOT NULL DEFAULT 'ar', is_active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS notification_deliveries (
 id BIGSERIAL PRIMARY KEY, user_id BIGINT REFERENCES users(id) ON DELETE CASCADE, template_id BIGINT REFERENCES notification_templates(id), channel VARCHAR(30) NOT NULL, destination TEXT, payload JSONB NOT NULL DEFAULT '{}'::jsonb, status VARCHAR(30) NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','processing','sent','failed')), attempts INTEGER NOT NULL DEFAULT 0, available_at TIMESTAMPTZ NOT NULL DEFAULT now(), sent_at TIMESTAMPTZ, last_error TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_notification_delivery_queue ON notification_deliveries(status,available_at,created_at);
