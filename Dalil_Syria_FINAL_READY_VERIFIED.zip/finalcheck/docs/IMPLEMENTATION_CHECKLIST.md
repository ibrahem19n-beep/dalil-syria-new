# Dalil Syria — Current Implementation Checklist

## Core
- [x] Product rules and architecture
- [x] PostgreSQL + PostGIS schema/migrations
- [x] Places/categories/locations/brands foundation
- [x] Search/nearby APIs
- [x] Authentication/RBAC foundation
- [x] Reviews/favorites/reports/verification
- [x] Media/hours/translations APIs
- [x] Import/duplicate-review foundation
- [x] Admin moderation/user/audit APIs

## Commerce foundation
- [x] Orders/payments/providers
- [x] Currencies/FX
- [x] Fees/commissions
- [x] Partner balances/settlements/payouts
- [x] Refunds/webhooks/idempotency/reconciliation tables
- [x] Feature flags OFF by default
- [x] Outbox/domain-event tables
- [x] Production worker/outbox runtime (provider-neutral container worker)
- [ ] Real provider adapters + sandbox verification

## Security/operations
- [x] Security headers
- [x] Configurable CORS
- [x] Health/readiness
- [x] Request IDs
- [x] Docker/Caddy deployment foundation
- [x] Backup/restore scripts
- [ ] Real server deployment
- [ ] Restore drill on real infrastructure
- [ ] Rate limiting/brute-force protection
- [ ] Full refresh-token/session lifecycle
- [ ] Dependency/vulnerability scan
- [ ] Measured load/security testing

## Clients/content
- [x] Web/PWA client foundation
- [ ] Final mobile UI/UX
- [ ] Native Android build
- [ ] Native iOS build
- [ ] Complete admin UI
- [ ] Final website/SEO/content
- [ ] Final icon/splash/store/marketing assets
- [ ] Real Syria dataset and editorial content
- [ ] Final translations
- [ ] Notification delivery system

## Release
- [ ] Google Play build/testing/submission
- [ ] App Store build/testing/submission
- [ ] Public website/domain launch
- [ ] Commercial/payment activation gates
