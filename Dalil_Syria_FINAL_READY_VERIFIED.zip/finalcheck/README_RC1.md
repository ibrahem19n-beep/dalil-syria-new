# Dalil Syria — Release Candidate 1

RC1 is the first release-candidate packaging pass after V0.12.

## RC1 hardening
- Production configuration is fail-closed: no default database/auth secrets.
- Explicit CORS configuration with wildcard rejected in production.
- Docker health checks and dependency ordering for DB/API/web.
- PostgreSQL/backend ports bind to localhost by default in Compose.
- Restart policies for deployed services.
- `.env.example` documents required configuration without containing real secrets.
- Deployment gate covers HTTPS, backups, restore testing, monitoring, and smoke tests.

## Start locally
Copy `.env.example` to `.env`, replace the placeholder secrets, then run:

    docker compose up --build

## Release status
Code-level RC1 gate: prepared. Production launch still requires real hosting credentials, domain/TLS, backup target, and store accounts.
