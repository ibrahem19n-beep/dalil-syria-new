import json, re, sys
from pathlib import Path
root=Path(__file__).parent
p=root/'mobile_app/data/places.json'; a=root/'android/app/src/main/assets/mobile_app/data/places.json'
d=json.loads(p.read_text(encoding='utf-8')); ad=json.loads(a.read_text(encoding='utf-8'))
assert len(d)==265, len(d)
assert len(ad)==265
assert d==ad
assert len({x['id'] for x in d})==265
assert len({(round(x['latitude'],6),round(x['longitude'],6)) for x in d})==265
for x in d:
    for k in ('name_ar','name_en','address_ar','address_en','latitude','longitude','source','verification','last_verified'):
        assert x.get(k) not in (None,''), (x['id'],k)
    assert 33.4 <= x['latitude'] <= 33.6 and 36.15 <= x['longitude'] <= 36.4
print('AUDIT_OK places=265 ids=265 coords=265 android_sync=yes')
