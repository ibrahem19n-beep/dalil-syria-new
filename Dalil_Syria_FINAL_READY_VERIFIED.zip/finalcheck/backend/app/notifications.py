from ..db import get_conn

def queue_notification(user_id, channel, destination, payload, template_id=None):
    with get_conn() as conn:
        row=conn.execute("INSERT INTO notification_deliveries(user_id,template_id,channel,destination,payload) VALUES(%s,%s,%s,%s,%s) RETURNING id,status,created_at",(user_id,template_id,channel,destination,payload)).fetchone()
        conn.commit()
    return row

def claim_notifications(limit=50):
    with get_conn() as conn:
        rows=conn.execute("WITH picked AS (SELECT id FROM notification_deliveries WHERE status='pending' AND available_at<=now() ORDER BY id FOR UPDATE SKIP LOCKED LIMIT %s) UPDATE notification_deliveries d SET status='processing',attempts=attempts+1 FROM picked WHERE d.id=picked.id RETURNING d.*",(limit,)).fetchall()
        conn.commit(); return rows

def mark_notification_sent(delivery_id):
    with get_conn() as conn:
        conn.execute("UPDATE notification_deliveries SET status='sent',sent_at=now() WHERE id=%s",(delivery_id,)); conn.commit()

def mark_notification_failed(delivery_id,error):
    with get_conn() as conn:
        conn.execute("UPDATE notification_deliveries SET status=CASE WHEN attempts>=10 THEN 'failed' ELSE 'pending' END,last_error=%s,available_at=now()+least(interval '1 hour', interval '5 seconds' * power(2,least(attempts,8))) WHERE id=%s",(str(error)[:2000],delivery_id)); conn.commit()
