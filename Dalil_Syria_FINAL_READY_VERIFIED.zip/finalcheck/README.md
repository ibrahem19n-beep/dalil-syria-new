# دليل سوريا — V0.12 READY BUILD

Final build-hardening pass before RC1. Start locally with:

    docker compose up --build

Web: http://localhost:8080
API: http://localhost:8000/docs
Health: http://localhost:8000/health
Readiness: http://localhost:8000/ready

Before production, set strong `POSTGRES_PASSWORD`, `DALIL_AUTH_SECRET`, and `DALIL_CORS_ORIGINS` values.

## V0.15 Maps Foundation
Maps are provider-agnostic, centered on Syria by default, with configurable geocoding/satellite capability flags, coordinate validation, and a public PostGIS spatial index. A concrete provider is selected only during UI/production integration after operational/legal review.
