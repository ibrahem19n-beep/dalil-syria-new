import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MOBILE = ROOT / "mobile_app"
ICON_DIR = MOBILE / "assets" / "brand" / "icon"


def test_official_app_icon_assets_are_present():
    for name in (
        "dalil-syria-app-icon-master-1536.png",
        "dalil-syria-app-icon-512.png",
        "dalil-syria-app-icon-192.png",
        "dalil-syria-app-icon-180.png",
    ):
        assert (ICON_DIR / name).is_file()


def test_manifest_points_to_approved_external_icon():
    manifest = json.loads((MOBILE / "manifest.webmanifest").read_text(encoding="utf-8"))
    paths = {item["src"] for item in manifest["icons"]}
    assert "assets/brand/icon/dalil-syria-app-icon-192.png" in paths
    assert "assets/brand/icon/dalil-syria-app-icon-512.png" in paths
    assert all(item.get("purpose") == "any" for item in manifest["icons"])


def test_pwa_shell_and_service_worker_are_registered():
    index = (MOBILE / "index.html").read_text(encoding="utf-8")
    worker = (MOBILE / "sw.js").read_text(encoding="utf-8")
    assert 'serviceWorker.register("./sw.js")' in index
    assert "dalil-syria-shell-v1" in worker
    assert "./index.html" in worker
    assert "./app.js" in worker


def test_service_worker_does_not_cache_api_responses():
    worker = (MOBILE / "sw.js").read_text(encoding="utf-8")
    assert "url.pathname.startsWith('/api/')" in worker
