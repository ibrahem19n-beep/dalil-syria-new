# Dalil Syria — PRODUCTION

حزمة تجهيز الإنتاج فوق RC2.

## تمت إضافته
- Production Compose مستقل مع شبكة داخلية للخدمات.
- HTTPS تلقائي عبر Caddy.
- عدم نشر PostgreSQL أو Backend للعامة.
- Backend يعمل كمستخدم غير root وبنظام ملفات read-only.
- تدوير سجلات Docker.
- أدوات Backup/Restore لقاعدة PostgreSQL.
- بوابة تشغيل وإطلاق موثقة.

## التحقق المحلي
`pytest -q`

> لا يتم اعتبار Docker متحققاً في بيئة التطوير إلا بعد تشغيله فعلياً على جهاز/خادم يحتوي Docker.
