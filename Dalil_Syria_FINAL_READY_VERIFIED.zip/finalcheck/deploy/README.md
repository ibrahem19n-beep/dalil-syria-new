# Dalil Syria — Production Deployment

هذا هو مسار الإنتاج الفعلي. استخدم `deploy/docker-compose.production.yml` بدل ملف التطوير.

## 1) المتطلبات
- Docker Engine + Compose Plugin
- نطاق DNS يشير إلى الخادم
- فتح TCP 80 و443 فقط للعامة

أنشئ `.env` في جذر المشروع، ولا تضعه داخل Git:

```env
POSTGRES_PASSWORD=<strong-random-password>
DALIL_AUTH_SECRET=<at-least-32-random-characters>
DALIL_CORS_ORIGINS=https://your-domain.example
CADDY_DOMAIN=your-domain.example
DALIL_TOKEN_TTL_SECONDS=3600
```

## 2) تشغيل الإنتاج

```bash
docker compose -f deploy/docker-compose.production.yml up -d --build
```

Caddy يتولى HTTPS تلقائياً بعد توجيه DNS وفتح 80/443.

## 3) التحقق

```bash
docker compose -f deploy/docker-compose.production.yml ps
curl -fsS https://your-domain.example/health
curl -fsS https://your-domain.example/ready
```

## 4) النسخ الاحتياطي

```bash
./deploy/backup.sh
```

احفظ ملفات `backups/*.dump` خارج الخادم بشكل مشفّر. لا تعتبر النسخة الاحتياطية سليمة قبل اختبار استعادتها.

## 5) الاستعادة

الاستعادة مدمرة للبيانات الحالية:

```bash
CONFIRM_RESTORE=YES ./deploy/restore.sh backups/example.dump
```

## بوابة الإطلاق
- HTTPS فعال.
- PostgreSQL وBackend غير منشورين للعامة.
- `DALIL_AUTH_SECRET` قوي وغير افتراضي.
- CORS محدد صراحةً وليس `*`.
- `/ready` يرفض الإقلاع غير السليم.
- النسخ الاحتياطي والاستعادة مجرّبان.
- راقب 5xx وCPU/RAM/Disk وحالة DB والنسخ الاحتياطية.
- شغّل `pytest -q` قبل الترقية.
