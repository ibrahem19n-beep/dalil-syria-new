import re
import unicodedata

def normalize_query(value: str) -> str:
    value = unicodedata.normalize("NFKC", value or "")
    value = value.strip().casefold()
    value = re.sub(r"[\u064B-\u065F\u0670]", "", value)
    value = re.sub(r"[\u200c\u200d]", "", value)
    return " ".join(value.split())

def search_terms(value: str) -> tuple[str, ...]:
    return tuple(x for x in normalize_query(value).split(" ") if x)
