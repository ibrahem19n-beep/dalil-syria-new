# دليل سوريا — Official APK Download Page

Required production page sections:
- App name and official icon
- Current version
- What the app does
- Download APK button
- SHA-256 checksum
- Installation instructions for Android
- Update instructions
- Support/contact
- Privacy policy
- Previous stable release / rollback link

Do not publish an unsigned or unverified APK.
