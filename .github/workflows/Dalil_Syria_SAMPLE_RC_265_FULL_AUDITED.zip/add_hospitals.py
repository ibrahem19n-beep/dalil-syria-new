import json, math
from pathlib import Path
p=Path('/mnt/data/dalil_bulk_work/mobile_app/data/places.json'); rows=json.loads(p.read_text(encoding='utf-8'))
A='23456789CFGHJMPQRVWX'; R=[20,1,0.05,0.0025,0.000125]
def enc(lat,lon):
 if lat==90: lat-=1e-12
 lat=max(-90,min(90,lat)); lon=((lon+180)%360)-180; lat+=90; lon+=180; s=''
 for res in R:
  a=int(lat/res); b=int(lon/res); s+=A[a%20]+A[b%20]; lat-=a*res; lon-=b*res
 return s[:8]+'+'+s[8:]
def dec(c,ref=(33.513,36.29)):
 c=c.upper().replace(' ',''); b,a=c.split('+'); sig=b+a; rc=enc(*ref).replace('+','')
 if len(sig)<8: sig=rc[:8-len(b)]+sig
 sig=sig.ljust(10,'2'); lat=-90; lon=-180
 for i in range(0,10,2): lat+=A.index(sig[i])*R[i//2]; lon+=A.index(sig[i+1])*R[i//2]
 return lat+R[4]/2,lon+R[4]/2
cands=[
(2092,'مستشفى دار الشفاء','Dar Al Shifa Hospital','مشافي','Hospital','العدوي، شارع خليل الزركلي، دمشق','Al-Adawi, Khalil Al-Zarqly Street, Damascus','+963114465340','G8G4+38W',3.8,85),
(2093,'مستشفى الرازي','Al-Razi Hospital','مشافي','Hospital','أوتوستراد المزة، دمشق','Mezzeh Highway, Damascus','+963116118445','G736+PCW',3.8,59),
(2094,'مشفى المواساة الجامعي','Al-Mowasat University Hospital','مشافي','Government Hospital','عمر بن عبد العزيز، دمشق','Omar Bin Abdulaziz, Damascus','+963112133000','G767+R8X',3.4,125),
(2095,'المشفى الإيطالي','Italian Hospital Damascus','مشافي','Hospital','جمال عبد الناصر، دمشق','Gamal Abdel Nasser, Damascus','+963113326030','G7FQ+5W2',4.5,43),
(2096,'مشفى القديس لويس الفرنسي','St. Louis French Hospital','مشافي','Hospital','دمشق','Damascus','+963114440460','G898+CCX',3.8,58),
(2097,'مشفى أمية','Omaya Hospital','مشافي','Hospital','دمشق','Damascus','+963112776412','G7HV+P43',3.8,42),
(2098,'مستشفى الكندي','Al-Kindi Hospital','مشافي','Hospital','خالد بن الوليد، دمشق','Khaled Bin Al-Walid, Damascus','', 'G74W+88C',3.6,36),
(2099,'مشفى الشرق','Al-Sharq Hospital','مشافي','Hospital','29 أيار، دمشق','29 May Street, Damascus','+963963119218','G79W+H69',3.9,55),
(2100,'مشفى الهلال الأحمر','Syrian Red Crescent Hospital','مشافي','Hospital','دمشق','Damascus','', 'F8W3+5F3',4.2,25),
(2101,'مستشفى الباسل - مركز جراحة القلب','Al-Basel Cardiac Surgery Hospital','مشافي','Heart Hospital','دمشق','Damascus','+963113122340','G6GJ+99R',4.3,44),
(2102,'المشفى العسكري 601','Military Hospital 601','مشافي','Hospital','دمشق','Damascus','', 'G763+J9M',2.2,23),
(2103,'مشفى الأسدي','Al-Asadi Hospital','مشافي','Hospital','دمشق','Damascus','', 'G62Q+3RF',3.5,13),
]
excoords={(round(float(x['latitude']),5),round(float(x['longitude']),5)) for x in rows}; names={x['name_ar'].lower() for x in rows}; out=[]
for id_,ar,en,car,cen,aar,aen,phone,plus,rating,reviews in cands:
 lat,lon=dec(plus)
 if not (33.47<=lat<=33.57 and 36.22<=lon<=36.34): continue
 if (round(lat,5),round(lon,5)) in excoords or ar.lower() in names: continue
 if any(math.hypot((lat-float(x['latitude']))*111,(lon-float(x['longitude']))*93)<0.03 for x in rows+out): continue
 out.append({'id':id_,'name_ar':ar,'name_en':en,'category_ar':car,'category_en':cen,'address_ar':aar,'address_en':aen,'phone':phone,'latitude':round(lat,6),'longitude':round(lon,6),'rating':rating,'review_count':reviews,'hours':'24/7 حسب المصدر','hours_en':'24/7 per source','aliases':[ar,en.lower(),plus.lower()],'source':'Current business listing + official/directory source where available + published Plus Code','verification':'source_verified_plus_code_coordinate_decoded_2026-09-19','last_verified':'2026-09-19','opening_hours':[]})
rows.extend(out); p.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print('ADDED_HOSPITALS',len(out),'COUNT',len(rows))
for x in out: print(x['id'],x['name_ar'],x['latitude'],x['longitude'])
