# Dalil Syria V0.12 — V11 Worker Runtime

## Completed
- Background worker runtime integrated into Docker Compose.
- Outbox events and notification deliveries are claimed with database locking and processed asynchronously.
- Failed jobs return to pending with bounded exponential retry; exhausted jobs become failed.
- Worker is isolated from the public network and has no published host port.
- Provider-neutral logging sinks prevent accidental external delivery.

## Still external / gated
- Real push/email/SMS providers.
- Real payment providers.
- Production server, DNS/TLS secrets and restore drill.
- Signed Android AAB.

## Verification
- Python compilation of worker modules passes.
- Existing full pytest suite could not be rerun in this environment because the environment lacks the `psycopg` dependency and has no network access to install it. No test result is fabricated.


## V12 follow-up
Operational hardening applied in `V0_12_OPERATIONAL_HARDENING_V12.md`.
