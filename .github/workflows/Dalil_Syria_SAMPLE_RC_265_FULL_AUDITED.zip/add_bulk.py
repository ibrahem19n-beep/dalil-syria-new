import json, math
from pathlib import Path
p=Path('/mnt/data/dalil_bulk_work/mobile_app/data/places.json')
rows=json.loads(p.read_text(encoding='utf-8'))
# Coordinates decoded from the published short Plus Codes, using Damascus as the locality reference.
candidates=[
(2057,'فلافورا كافيه','Flavora Cafe','كافيه','Cafe','أحمد شوقي، دمشق','Ahmad Shawqi, Damascus','+963965008203','G79M+C39',4.8,59,'09:00–23:30 يومياً'),
(2058,'صيدلية باب مصلى','Bab Musalla Pharmacy','صيدليات','Pharmacy','المجتهد، دمشق','Al-Mujtahid, Damascus','', 'F7XX+GV3',3.5,11,'08:00–00:00'),
(2059,'DMC مركز السكري الطبي','DMC Diab Medical Center','مراكز طبية','Medical Center','دمشق','Damascus','+963937969696','G7CV+HRH',4.5,13,'09:00–22:00'),
(2060,'مشفى الشامي','Dr. Shami Hospital','مشافي','Hospital','غربي المالكي، دمشق','West Al-Malki, Damascus','+963113735090','G7C9+283',3.1,105,'24/7'),
(2061,'مطعم ست الشام','Set Al Sham Restaurant','مطاعم','Restaurant','دمشق','Damascus','+963113311238','G77P+X6R',4.3,356,'08:00–02:00 يومياً'),
(2062,'صيدلية العابد','Al-Abed Pharmacy','صيدليات','Pharmacy','شارع العابد، دمشق','Al-Abed Street, Damascus','+963114454845','G79V+WXR',3.9,8,'09:30–00:00 + مناوبات ليلية'),
(2063,'مشفى الأندلس','Al Andalus Hospital','مشافي','Hospital','عبد الله بن رواحة، دمشق','Abdullah Bin Rawaha, Damascus','+963112114363','F7WJ+7PX',2.8,87,'24/7'),
(2064,'بيت جبري','Beit Jabri','مطاعم','Restaurant','المدينة القديمة، دمشق','Old Damascus, Damascus','+963115443200','G877+585',4.2,364,'10:00–00:00'),
(2065,'بالاديوم كافيه','Palladium Cafe','مقاهي','Cafe','دمشق','Damascus','', 'G725+W5J',4.8,8,'09:00–05:00'),
(2066,'صيدلية دوانا','Dawana Pharmacy','صيدليات','Pharmacy','دمشق','Damascus','+963949570724','G79F+65P',5.0,6,'24/7'),
(2067,'صيدلية الشهبندر','Al-Shahbandar Pharmacy','صيدليات','Pharmacy','الشهبندر، دمشق','Al-Shahbandar, Damascus','+963113324514','G7FV+H4P',4.6,22,'24/7'),
(2068,'فيتنچ سوشال هاوس','Vintage Social House','مطاعم ومقاهي','Bistro','شارع الكرامة، أبو رمانة، خلف المدرسة الأمريكية، دمشق','Karama Street, Abu Rummaneh, behind the American School, Damascus','+963998468243','G78J+MHV',4.3,19,'09:00–02:00'),
(2069,'نيو قاسيون مول','New Qassion Mall','أسواق ومولات','Shopping Mall','شارع بدر، دمشق','Badr Street, Damascus','+905331949088','G8X7+962',4.3,739,'09:00–00:00؛ الجمعة حتى 01:00'),
(2070,'حديقة السبكي','Al-Sabki Park','حدائق وأماكن عامة','Park','دمشق','Damascus','', 'G79Q+J9G',4.1,812,'مفتوح 24 ساعة'),
(2071,'حمام الملك الظاهر','King Al-Zahir Bath','معالم سياحية','Historic Landmark','الملك فيصل، دمشق','King Faisal, Damascus','+963112225330','G874+23W',4.4,214,'09:00–23:59'),
(2072,'فندق داما روز','Dama Rose Hotel','فنادق','Hotel','شارع شكري القوتلي، دمشق','Shoukry Al-Qouwatly Street, Damascus','+963112229200','G77M+JX4',4.3,753,''),
(2073,'مول مزّة','Mazza Mall','أسواق ومولات','Shopping Mall','دمشق','Damascus','', 'F6WW+XC5',4.1,84,'09:30–00:00'),
(2074,'بيت رمان','Beit Rumman Boutique Hotel','فنادق','Hotel','دمشق القديمة، دمشق','Old Damascus, Damascus','+963115435002','G867+6XM',4.6,30,''),
(2075,'أفينيو مول','Avenue Mall','أسواق ومولات','Shopping Mall','دمشق','Damascus','+963113741203','G79C+JP8',4.2,376,'09:00–00:00'),
(2076,'خان أسعد باشا العظم','Khan Asaad Pasha Al-Azem','معالم سياحية','Historic Landmark','دمشق القديمة، دمشق','Old Damascus, Damascus','', 'G854+PM4',4.5,266,'09:00–15:00؛ الجمعة والسبت حسب المصدر'),
(2077,'بارون هاكوب','Baron Hakop','مطاعم','Restaurant','شارع باب توما، دمشق','Bab Touma Street, Damascus','+963115446953','G877+4X5',4.8,51,'10:00–00:00'),
(2078,'مطعم وملحمة المعلم','Almuallim Restaurant & Butchery','مطاعم','Restaurant','دمشق','Damascus','+963940013388','F7W2+PG5',4.9,39,'09:00–00:00'),
(2079,'مطعم بيت المختار','Beit Al Mukhtar Restaurant','مطاعم','Restaurant','دمشق','Damascus','+963114449048','G72G+833',4.7,21,'11:00–00:00'),
(2080,'المطعم الشرقي','Oriental Restaurant','مطاعم','Family Restaurant','دمشق القديمة، دمشق','Old Damascus, Damascus','+963115410250','G858+98V',4.2,36,'10:00–01:00'),
(2081,'مطعم الشاميات','Al-Shamiyat Restaurant','مطاعم','Restaurant','المجلس النيابي، دمشق','Parliament area, Damascus','+963112227270','G78Q+4F3',4.5,243,'08:00–01:00'),
(2082,'مطعم بيت الشرق','Beit Al Sharq Restaurant','مطاعم','Family Restaurant','دمشق','Damascus','+963996722227','G72M+WCC',4.3,64,''),
(2083,'حارتنا','Haretna Restaurant','مطاعم','Restaurant','باب توما، دمشق القديمة','Bab Touma, Old Damascus','+963115441184','G878+2FM',4.2,241,'09:00–02:00'),
(2084,'ماستر شيف','Master Chef','مطاعم','Restaurant','حمزة بن عبد المطلب، دمشق','Hamza Bin Abdul Muttalib, Damascus','+963116622267','G62R+29X',4.6,20,'12:00–00:00'),
(2085,'مطعم فيلا ورد','Villa Ward Restaurant','مطاعم','Restaurant','سوق الشعلان، دمشق','Shaalan Market, Damascus','+963937100002','G79Q+3G3',4.5,15,'10:00–23:55'),
(2086,'موناليزا','Mona Lisa Restaurant','مطاعم','Restaurant','شارع باب توما، دمشق','Bab Touma Street, Damascus','+963955449907','G868+46R',4.1,135,'09:00–01:00'),
(2087,'أبو جواد','Abo Jawad Restaurant','مطاعم','Restaurant','دمشق','Damascus','+963933079303','G62X+5CW',4.5,24,''),
(2088,'تايم آوت','Time Out Restaurant','مطاعم','Restaurant','دمشق','Damascus','+963113319740','G79R+35C',4.7,25,'08:00–01:00'),
(2089,'نوسترا كازا','Nostra Casa Restaurant','مطاعم','Restaurant','قرب الحمام، البكري، دمشق','Near Hammam, Al-Bakri, Damascus','+963115444134','G877+585',4.4,28,'09:00–01:00'),
(2090,'سيلينا','Selena Restaurant','مطاعم','Restaurant','دمشق القديمة، دمشق','Old Damascus, Damascus','+963115424759','G867+V4H',4.2,137,'10:00–01:00'),
(2091,'مطعم بلس','Plus Restaurant','مطاعم','Restaurant','دمشق','Damascus','+963116633999','G735+26H',4.2,42,'09:00–02:00'),
]
# decode short Plus Codes
A='23456789CFGHJMPQRVWX'; R=[20,1,0.05,0.0025,0.000125]
def enc(lat,lon):
    if lat==90: lat-=1e-12
    lat=max(-90,min(90,lat)); lon=((lon+180)%360)-180; lat+=90; lon+=180; s=''
    for res in R:
        a=int(lat/res); b=int(lon/res); s+=A[a%20]+A[b%20]; lat-=a*res; lon-=b*res
    return s[:8]+'+'+s[8:]
def dec(code,ref=(33.513,36.29)):
    c=code.upper().replace(' ',''); before,after=c.split('+'); sig=before+after; refc=enc(*ref).replace('+','')
    if len(sig)<8: sig=refc[:8-len(before)]+sig
    sig=sig.ljust(10,'2'); lat=-90; lon=-180
    for i in range(0,10,2): lat+=A.index(sig[i])*R[i//2]; lon+=A.index(sig[i+1])*R[i//2]
    return lat+R[4]/2,lon+R[4]/2
existing_coords={(round(float(x['latitude']),5),round(float(x['longitude']),5)) for x in rows}
existing_names={x['name_ar'].strip().lower() for x in rows}
nextrows=[]
for c in candidates:
    id_,ar,en,car,cen,aar,aen,phone,plus,rating,reviews,hours=c
    lat,lon=dec(plus)
    # reject outside Damascus city working envelope
    if not (33.47<=lat<=33.57 and 36.22<=lon<=36.34):
        continue
    if (round(lat,5),round(lon,5)) in existing_coords: continue
    if ar.strip().lower() in existing_names: continue
    # Nostra Casa intentionally shares the same plus code as Beit Jabri; reject duplicate coordinate.
    if any(math.hypot((lat-float(x['latitude']))*111,(lon-float(x['longitude']))*93)<0.03 for x in rows+nextrows):
        continue
    nextrows.append({'id':id_,'name_ar':ar,'name_en':en,'category_ar':car,'category_en':cen,'address_ar':aar,'address_en':aen,'phone':phone,'latitude':round(lat,6),'longitude':round(lon,6),'rating':rating,'review_count':reviews,'hours':hours,'hours_en':hours,'aliases':[ar,en.lower(),plus.lower()],'source':'Google/business listing + published Plus Code; cross-check where independent source available','verification':'source_verified_plus_code_coordinate_decoded_2026-09-19','last_verified':'2026-09-19','opening_hours':[]})
print('added',len(nextrows))
for x in nextrows: print(x['id'],x['name_ar'],x['latitude'],x['longitude'])
rows.extend(nextrows)
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
