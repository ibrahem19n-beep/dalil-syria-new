from dataclasses import dataclass
from abc import ABC, abstractmethod

@dataclass
class ProviderResult:
    status: str
    provider_reference: str | None = None
    failure_code: str | None = None
    raw: dict | None = None

class PaymentProvider(ABC):
    code = 'abstract'
    @abstractmethod
    def authorize(self, amount_minor, currency_code, reference, metadata=None): ...
    @abstractmethod
    def capture(self, provider_reference, amount_minor): ...
    @abstractmethod
    def cancel(self, provider_reference): ...
    @abstractmethod
    def refund(self, provider_reference, amount_minor): ...

class MockPaymentProvider(PaymentProvider):
    code = 'mock'

    def _scenario(self, metadata=None):
        value = (metadata or {}).get('scenario', 'SUCCESS').upper()
        allowed = {'SUCCESS','REQUIRES_ACTION','DECLINED','TIMEOUT','PROVIDER_ERROR'}
        return value if value in allowed else 'SUCCESS'

    def authorize(self, amount_minor, currency_code, reference, metadata=None):
        scenario = self._scenario(metadata)
        if scenario == 'REQUIRES_ACTION': return ProviderResult('requires_action', f'MOCK-ACTION-{reference}', raw={'scenario':scenario})
        if scenario == 'DECLINED': return ProviderResult('failed', None, 'DECLINED', {'scenario':scenario})
        if scenario == 'TIMEOUT': return ProviderResult('failed', None, 'TIMEOUT', {'scenario':scenario})
        if scenario == 'PROVIDER_ERROR': return ProviderResult('failed', None, 'PROVIDER_ERROR', {'scenario':scenario})
        return ProviderResult('authorized', f'MOCK-AUTH-{reference}', raw={'scenario':scenario})

    def capture(self, provider_reference, amount_minor):
        return ProviderResult('captured', provider_reference)
    def cancel(self, provider_reference):
        return ProviderResult('cancelled', provider_reference)
    def refund(self, provider_reference, amount_minor):
        return ProviderResult('refunded', f'{provider_reference}-REFUND')

PROVIDERS = {'mock': MockPaymentProvider()}
