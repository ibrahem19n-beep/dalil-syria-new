# Map provider decision

Google Maps requires a Google Cloud project, enabled Maps SDK, API key, and billing account; it cannot be safely embedded without credentials. The current build uses Esri World Street Map tiles as a stronger production-style public basemap than the previous Carto layer, with Leaflet controls and markers. Google Maps can be switched in once a restricted API key is supplied.
