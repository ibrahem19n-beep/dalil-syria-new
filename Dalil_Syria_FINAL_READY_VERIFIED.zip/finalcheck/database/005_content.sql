CREATE TABLE IF NOT EXISTS media_assets (
 id BIGSERIAL PRIMARY KEY,
 place_id BIGINT NOT NULL REFERENCES places(id) ON DELETE CASCADE,
 storage_key TEXT NOT NULL,
 url TEXT,
 mime_type TEXT,
 width INT,
 height INT,
 size_bytes BIGINT,
 status TEXT NOT NULL DEFAULT 'active',
 created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS place_hours (
 id BIGSERIAL PRIMARY KEY,
 place_id BIGINT NOT NULL REFERENCES places(id) ON DELETE CASCADE,
 day_of_week INT NOT NULL CHECK(day_of_week BETWEEN 0 AND 6),
 opens_at TIME,
 closes_at TIME,
 is_closed BOOLEAN DEFAULT FALSE,
 is_24_hours BOOLEAN DEFAULT FALSE,
 UNIQUE(place_id, day_of_week)
);

CREATE TABLE IF NOT EXISTS place_translations_v2 (
 id BIGSERIAL PRIMARY KEY,
 place_id BIGINT NOT NULL REFERENCES places(id) ON DELETE CASCADE,
 language_code TEXT NOT NULL REFERENCES languages(code),
 name TEXT,
 description TEXT,
 UNIQUE(place_id, language_code)
);

CREATE INDEX IF NOT EXISTS idx_media_place_status ON media_assets(place_id,status);
CREATE INDEX IF NOT EXISTS idx_hours_place ON place_hours(place_id);
CREATE INDEX IF NOT EXISTS idx_translations_place_lang ON place_translations_v2(place_id,language_code);
