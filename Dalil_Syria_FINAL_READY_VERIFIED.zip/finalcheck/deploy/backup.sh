#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
BACKUP_DIR="${BACKUP_DIR:-$ROOT/backups}"
mkdir -p "$BACKUP_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$BACKUP_DIR/dalil_syria_${STAMP}.dump"
cd "$ROOT"
docker compose -f deploy/docker-compose.production.yml exec -T db pg_dump -U dalil -d dalil_syria -Fc > "$OUT"
chmod 600 "$OUT"
printf '%s\n' "$OUT"
