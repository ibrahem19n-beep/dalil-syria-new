CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE SCHEMA IF NOT EXISTS commerce;

CREATE TABLE IF NOT EXISTS commerce.currencies (
 code VARCHAR(3) PRIMARY KEY, name TEXT NOT NULL, minor_unit SMALLINT NOT NULL DEFAULT 2 CHECK (minor_unit BETWEEN 0 AND 6), is_active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS commerce.exchange_rates (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), source_currency VARCHAR(3) NOT NULL REFERENCES commerce.currencies(code), target_currency VARCHAR(3) NOT NULL REFERENCES commerce.currencies(code), rate NUMERIC(30,12) NOT NULL CHECK(rate>0), effective_at TIMESTAMPTZ NOT NULL, provider TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(source_currency,target_currency,effective_at)
);
CREATE TABLE IF NOT EXISTS commerce.exchange_rate_snapshots (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), exchange_rate_id UUID NOT NULL REFERENCES commerce.exchange_rates(id), source_currency VARCHAR(3) NOT NULL, target_currency VARCHAR(3) NOT NULL, rate NUMERIC(30,12) NOT NULL, captured_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS commerce.orders (
 id BIGSERIAL PRIMARY KEY, public_id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(), user_id BIGINT REFERENCES users(id), partner_id BIGINT REFERENCES users(id), order_type VARCHAR(50) NOT NULL, status VARCHAR(30) NOT NULL DEFAULT 'pending', currency_code VARCHAR(3) NOT NULL REFERENCES commerce.currencies(code), subtotal_minor BIGINT NOT NULL DEFAULT 0, fee_minor BIGINT NOT NULL DEFAULT 0, commission_minor BIGINT NOT NULL DEFAULT 0, total_minor BIGINT NOT NULL DEFAULT 0, metadata JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS commerce.order_items (
 id BIGSERIAL PRIMARY KEY, order_id BIGINT NOT NULL REFERENCES commerce.orders(id) ON DELETE CASCADE, item_type VARCHAR(50) NOT NULL, reference_id TEXT, description TEXT, quantity BIGINT NOT NULL CHECK(quantity>0), unit_amount_minor BIGINT NOT NULL CHECK(unit_amount_minor>=0), total_amount_minor BIGINT NOT NULL CHECK(total_amount_minor>=0), metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS commerce.payment_providers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), code VARCHAR(80) NOT NULL UNIQUE, name TEXT NOT NULL, is_active BOOLEAN NOT NULL DEFAULT FALSE, priority INT NOT NULL DEFAULT 100, capabilities JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS commerce.provider_accounts (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), provider_id UUID NOT NULL REFERENCES commerce.payment_providers(id), account_name TEXT NOT NULL, currency_code VARCHAR(3) REFERENCES commerce.currencies(code), is_active BOOLEAN NOT NULL DEFAULT FALSE, credentials_ref TEXT, metadata JSONB NOT NULL DEFAULT '{}'::jsonb, UNIQUE(provider_id,account_name)
);
CREATE TABLE IF NOT EXISTS commerce.payment_methods (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), provider_account_id UUID REFERENCES commerce.provider_accounts(id), code VARCHAR(80) NOT NULL, method_type VARCHAR(50) NOT NULL, currency_code VARCHAR(3) REFERENCES commerce.currencies(code), is_active BOOLEAN NOT NULL DEFAULT FALSE, metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS commerce.payments (
 id BIGSERIAL PRIMARY KEY, public_id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(), order_id BIGINT NOT NULL REFERENCES commerce.orders(id), provider_id UUID REFERENCES commerce.payment_providers(id), provider_account_id UUID REFERENCES commerce.provider_accounts(id), payment_method_id UUID REFERENCES commerce.payment_methods(id), amount_minor BIGINT NOT NULL CHECK(amount_minor>0), currency_code VARCHAR(3) NOT NULL REFERENCES commerce.currencies(code), status VARCHAR(30) NOT NULL DEFAULT 'pending', provider_reference TEXT, failure_code TEXT, metadata JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS commerce.transactions (
 id BIGSERIAL PRIMARY KEY, public_id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(), payment_id BIGINT REFERENCES commerce.payments(id), order_id BIGINT REFERENCES commerce.orders(id), partner_id BIGINT REFERENCES users(id), transaction_type VARCHAR(40) NOT NULL, status VARCHAR(30) NOT NULL DEFAULT 'posted', amount_minor BIGINT NOT NULL, currency_code VARCHAR(3) NOT NULL REFERENCES commerce.currencies(code), exchange_rate_id UUID REFERENCES commerce.exchange_rates(id), provider_reference TEXT, metadata JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS commerce.fees (
 id BIGSERIAL PRIMARY KEY, transaction_id BIGINT REFERENCES commerce.transactions(id), fee_type VARCHAR(50) NOT NULL, amount_minor BIGINT NOT NULL CHECK(amount_minor>=0), currency_code VARCHAR(3) NOT NULL REFERENCES commerce.currencies(code), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS commerce.commissions (
 id BIGSERIAL PRIMARY KEY, transaction_id BIGINT REFERENCES commerce.transactions(id), partner_id BIGINT REFERENCES users(id), amount_minor BIGINT NOT NULL CHECK(amount_minor>=0), currency_code VARCHAR(3) NOT NULL REFERENCES commerce.currencies(code), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS commerce.partner_accounts (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), partner_id BIGINT NOT NULL REFERENCES users(id), status VARCHAR(30) NOT NULL DEFAULT 'active', created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(partner_id)
);
CREATE TABLE IF NOT EXISTS commerce.partner_balance_accounts (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), partner_account_id UUID NOT NULL REFERENCES commerce.partner_accounts(id) ON DELETE CASCADE, currency_code VARCHAR(3) NOT NULL REFERENCES commerce.currencies(code), available_minor BIGINT NOT NULL DEFAULT 0, reserved_minor BIGINT NOT NULL DEFAULT 0, updated_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(partner_account_id,currency_code), CHECK(available_minor>=0), CHECK(reserved_minor>=0)
);
CREATE TABLE IF NOT EXISTS commerce.settlements (
 id BIGSERIAL PRIMARY KEY, public_id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(), partner_id BIGINT NOT NULL REFERENCES users(id), currency_code VARCHAR(3) NOT NULL REFERENCES commerce.currencies(code), gross_minor BIGINT NOT NULL DEFAULT 0, fee_minor BIGINT NOT NULL DEFAULT 0, commission_minor BIGINT NOT NULL DEFAULT 0, net_minor BIGINT NOT NULL DEFAULT 0, status VARCHAR(30) NOT NULL DEFAULT 'pending', period_start TIMESTAMPTZ, period_end TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), completed_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS commerce.settlement_items (
 id BIGSERIAL PRIMARY KEY, settlement_id BIGINT NOT NULL REFERENCES commerce.settlements(id) ON DELETE CASCADE, transaction_id BIGINT NOT NULL UNIQUE REFERENCES commerce.transactions(id), amount_minor BIGINT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS commerce.payouts (
 id BIGSERIAL PRIMARY KEY, public_id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(), partner_id BIGINT NOT NULL REFERENCES users(id), settlement_id BIGINT REFERENCES commerce.settlements(id), payout_method_id UUID REFERENCES commerce.payment_methods(id), amount_minor BIGINT NOT NULL CHECK(amount_minor>0), currency_code VARCHAR(3) NOT NULL REFERENCES commerce.currencies(code), status VARCHAR(30) NOT NULL DEFAULT 'requested', provider_reference TEXT, failure_code TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), completed_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS commerce.refunds (
 id BIGSERIAL PRIMARY KEY, public_id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(), payment_id BIGINT NOT NULL REFERENCES commerce.payments(id), amount_minor BIGINT NOT NULL CHECK(amount_minor>0), currency_code VARCHAR(3) NOT NULL REFERENCES commerce.currencies(code), status VARCHAR(30) NOT NULL DEFAULT 'requested', provider_reference TEXT, failure_code TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), completed_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS commerce.provider_webhook_events (
 id BIGSERIAL PRIMARY KEY, provider_id UUID REFERENCES commerce.payment_providers(id), event_id TEXT NOT NULL, event_type TEXT NOT NULL, signature_valid BOOLEAN NOT NULL DEFAULT FALSE, payload JSONB NOT NULL, status VARCHAR(30) NOT NULL DEFAULT 'received', received_at TIMESTAMPTZ NOT NULL DEFAULT now(), processed_at TIMESTAMPTZ, UNIQUE(provider_id,event_id)
);
CREATE TABLE IF NOT EXISTS commerce.idempotency_keys (
 id BIGSERIAL PRIMARY KEY, key TEXT NOT NULL, actor_user_id BIGINT REFERENCES users(id), endpoint TEXT NOT NULL, request_hash TEXT NOT NULL, response_code INT, response_body JSONB, status VARCHAR(30) NOT NULL DEFAULT 'processing', created_at TIMESTAMPTZ NOT NULL DEFAULT now(), expires_at TIMESTAMPTZ, UNIQUE(key,endpoint,actor_user_id)
);
CREATE TABLE IF NOT EXISTS commerce.reconciliation_runs (
 id BIGSERIAL PRIMARY KEY, provider_id UUID REFERENCES commerce.payment_providers(id), status VARCHAR(30) NOT NULL DEFAULT 'running', started_at TIMESTAMPTZ NOT NULL DEFAULT now(), completed_at TIMESTAMPTZ, summary JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS commerce.reconciliation_items (
 id BIGSERIAL PRIMARY KEY, run_id BIGINT NOT NULL REFERENCES commerce.reconciliation_runs(id) ON DELETE CASCADE, provider_reference TEXT, internal_transaction_id BIGINT REFERENCES commerce.transactions(id), external_amount_minor BIGINT, internal_amount_minor BIGINT, status VARCHAR(30) NOT NULL, details JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS commerce.feature_flags (
 key VARCHAR(100) PRIMARY KEY, enabled BOOLEAN NOT NULL DEFAULT FALSE, description TEXT, updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS commerce.outbox_events (
 id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY, event_id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(), event_type VARCHAR(100) NOT NULL, aggregate_type VARCHAR(80) NOT NULL, aggregate_id VARCHAR(100) NOT NULL, version INTEGER NOT NULL DEFAULT 1, payload JSONB NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','processing','published','failed')), attempts INTEGER NOT NULL DEFAULT 0, available_at TIMESTAMPTZ NOT NULL DEFAULT now(), created_at TIMESTAMPTZ NOT NULL DEFAULT now(), published_at TIMESTAMPTZ, last_error TEXT
);
CREATE TABLE IF NOT EXISTS commerce.domain_events (
 id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY, event_id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(), event_type VARCHAR(100) NOT NULL, aggregate_type VARCHAR(80) NOT NULL, aggregate_id VARCHAR(100) NOT NULL, version INTEGER NOT NULL DEFAULT 1, payload JSONB NOT NULL, occurred_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_user_created ON commerce.orders(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_partner_created ON commerce.orders(partner_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_payments_order ON commerce.payments(order_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_partner_created ON commerce.transactions(partner_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_payment ON commerce.transactions(payment_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_outbox_pending ON commerce.outbox_events(status,available_at,created_at);
CREATE INDEX IF NOT EXISTS idx_domain_events_aggregate ON commerce.domain_events(aggregate_type,aggregate_id,occurred_at);

INSERT INTO commerce.currencies(code,name,minor_unit) VALUES
('SYP','Syrian Pound',2),('USD','US Dollar',2),('EUR','Euro',2),('SAR','Saudi Riyal',2),('QAR','Qatari Riyal',2),('TRY','Turkish Lira',2)
ON CONFLICT(code) DO NOTHING;
INSERT INTO commerce.feature_flags(key,enabled,description) VALUES
('commercial_enabled',false,'Master commercial gate'),('payments_enabled',false,'Real payment gate'),('booking_enabled',false,'Booking gate'),('ads_enabled',false,'Advertising gate'),('subscriptions_enabled',false,'Subscription gate'),('partner_payouts_enabled',false,'Partner payout gate'),('digital_assets_enabled',false,'Digital assets gate')
ON CONFLICT(key) DO NOTHING;
INSERT INTO roles(name) VALUES ('finance_admin'),('finance_operator'),('partner_admin') ON CONFLICT(name) DO NOTHING;

-- V0.7 compatibility hardening
ALTER TABLE commerce.orders ADD COLUMN IF NOT EXISTS user_id BIGINT REFERENCES users(id);
ALTER TABLE commerce.orders ADD COLUMN IF NOT EXISTS source VARCHAR(50);
ALTER TABLE commerce.orders ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMPTZ;
ALTER TABLE commerce.orders ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ;
ALTER TABLE commerce.orders ADD COLUMN IF NOT EXISTS idempotency_key TEXT;
ALTER TABLE commerce.orders ADD COLUMN IF NOT EXISTS fee_minor BIGINT NOT NULL DEFAULT 0;
ALTER TABLE commerce.orders ADD COLUMN IF NOT EXISTS commission_minor BIGINT NOT NULL DEFAULT 0;
ALTER TABLE commerce.payments ADD COLUMN IF NOT EXISTS authorized_amount_minor BIGINT NOT NULL DEFAULT 0;
ALTER TABLE commerce.payments ADD COLUMN IF NOT EXISTS captured_amount_minor BIGINT NOT NULL DEFAULT 0;
ALTER TABLE commerce.payments ADD COLUMN IF NOT EXISTS refunded_amount_minor BIGINT NOT NULL DEFAULT 0;
ALTER TABLE commerce.payments ADD COLUMN IF NOT EXISTS idempotency_key TEXT;
ALTER TABLE commerce.refunds ADD COLUMN IF NOT EXISTS reason TEXT;
ALTER TABLE commerce.refunds ADD COLUMN IF NOT EXISTS idempotency_key TEXT;
ALTER TABLE commerce.provider_webhook_events ADD COLUMN IF NOT EXISTS payload_hash TEXT;
ALTER TABLE commerce.provider_webhook_events ADD COLUMN IF NOT EXISTS processing_attempts INTEGER NOT NULL DEFAULT 0;
CREATE UNIQUE INDEX IF NOT EXISTS uq_refund_idempotency ON commerce.refunds(idempotency_key) WHERE idempotency_key IS NOT NULL;
INSERT INTO commerce.payment_providers(code,name,is_active,priority,capabilities) VALUES ('mock','Mock Test Provider',TRUE,100,'{"authorize":true,"capture":true,"cancel":true,"refund":true,"webhook":true}') ON CONFLICT(code) DO UPDATE SET is_active=TRUE;
