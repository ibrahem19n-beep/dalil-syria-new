# Dalil Syria V0.12 — Import Pipeline V15

Implemented a provider-neutral import preparation layer for the existing `import_jobs` / `import_rows` model.

- Arabic/English header aliases
- whitespace/BOM normalization
- CSV parsing
- required-name validation
- coordinate validation through the existing map rules
- duplicate scoring using phone/name signals
- no automatic destructive merge; uncertain rows remain reviewable

This is the preparation layer; external datasets, licensed sources, geocoding providers and bulk production execution remain deployment/provider decisions.
