# Dalil Syria V0.12 — Operational Hardening V12

Implemented without changing the V0.12 domain/API contracts.

- Worker now handles SIGTERM/SIGINT for clean container shutdown.
- Worker survives transient database/runtime exceptions instead of exiting and relies on existing DB retry/lease behavior.
- Worker container drops Linux capabilities and enables `no-new-privileges`.
- No external payment, push, email, SMS, or broker provider is enabled.
- Commercial/payment feature flags remain OFF.
- Existing 44-test suite remains the release regression gate.

This stage is operational hardening; it is not a claim of public deployment or a signed Android AAB.
