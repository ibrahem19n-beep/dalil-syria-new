# Store Launch Checklist

- [x] App identity: Dalil Syria
- [x] Package ID: com.dalilsyria.app
- [x] Version: 1.0.0
- [x] External App Icon locked to user's selected image
- [x] Core V0.12 baseline retained
- [x] Android release source prepared
- [ ] Production-signed AAB generated in real build environment
- [ ] Production backend endpoint/secrets configured
- [ ] Privacy policy URL finalized
- [ ] Play Console Data Safety / content declarations completed
- [ ] Support/contact details finalized
- [ ] User-approved store screenshots added
- [ ] Closed/internal testing completed
- [ ] Production submission completed
- [ ] Google Play review/approval completed
