# Dalil Syria V1.3 — Bulk Map Build

Implemented in this package:
- Replaced the previous MapLibre/OpenFreeMap dependency with a self-contained slippy-map engine using OpenStreetMap raster tiles, so a missing external style cannot leave a white map.
- Added pan, zoom, reset, category marker clustering, place popups, GPS marker, and route-line rendering from a real OSRM route response.
- Fixed the Arabic/English toggle: the previous duplicate click handlers toggled twice and effectively cancelled each other.
- Expanded local place loading from 500 to 10,000 records.
- Added `tools/build_bulk_places.py` to extract, clean, deduplicate, classify and batch Overture Places for Damascus + Rif Dimashq in GitHub Actions.
- Preserves the existing verified 265 records and imports up to 10,000 additional source-confirmed records when the source returns enough qualifying data.
- Batch manifest is generated under `bulk_batches/MANIFEST.json`.
- Android assets are synchronized with the web app.

The GitHub Actions build performs the bulk extraction on the runner because this local execution environment does not have external network access. The first GitHub Actions run therefore creates the actual large dataset and APK.
