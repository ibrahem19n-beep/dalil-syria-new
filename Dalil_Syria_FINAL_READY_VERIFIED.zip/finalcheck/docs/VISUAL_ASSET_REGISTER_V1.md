# Dalil Syria — Visual Asset Register V1

## Approved

| Role | Asset | Status | Rule |
|---|---|---|---|
| Primary brand/hero visual | `mobile_app/assets/brand/dalil-syria-selected.png` | APPROVED | Preserve exactly; do not substitute |
| Official external app icon | `mobile_app/assets/brand/icon/dalil-syria-app-icon-master-1536.png` | APPROVED | This is the exact image selected by the user; no design/content changes |

### App icon technical derivatives

The approved icon master is preserved unchanged. The 512px, 192px and 180px files are technical size derivatives only, created from the same approved image for platform/browser icon requirements.

## Pending approval

| Role | Status |
|---|---|
| Splash / launch artwork | PENDING USER CHOICE |
| Internal place photography direction | PENDING USER CHOICE |
| Store screenshots / marketing visuals | PENDING USER CHOICE |

## Non-negotiable visual rule

The approved primary image is the **second image selected by the user**. The same image is now also explicitly approved by the user as the **official external app icon**. Do not replace either approved asset with the first image or any newly generated alternative.

No additional internal visual assets are to be selected or installed without the user's explicit choice.
