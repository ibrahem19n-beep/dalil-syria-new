-- V0.8 operational hardening: constraints/indexes for production CRUD/search.
CREATE UNIQUE INDEX IF NOT EXISTS uq_places_slug ON places(slug);
CREATE INDEX IF NOT EXISTS idx_places_updated_at ON places(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_places_verification ON places(verification_status);
CREATE INDEX IF NOT EXISTS idx_reviews_place_status ON reviews(place_id,status);
CREATE INDEX IF NOT EXISTS idx_reports_status_created ON reports(status,created_at DESC);
