#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

fail=0
need_file() { if [ ! -f "$1" ]; then echo "MISSING: $1"; fail=1; fi; }
need_file backend/app/main.py
need_file backend/Dockerfile
need_file web/Dockerfile
need_file deploy/docker-compose.production.yml
need_file deploy/Caddyfile
need_file deploy/backup.sh
need_file deploy/restore.sh
need_file .env.example

if grep -q '^POSTGRES_PASSWORD=replace-with-a-long-random-password$' .env.example && grep -q '^DALIL_AUTH_SECRET=replace-with-at-least-32-random-characters$' .env.example; then :; else
  echo 'INVALID: example secret placeholders changed unexpectedly'; fail=1
fi
if grep -nE 'ports:|5432:5432|8000:8000' deploy/docker-compose.production.yml | grep -E '5432:5432|8000:8000' >/dev/null 2>&1; then
  echo 'INVALID: database/backend public port mapping'; fail=1
fi
if ! grep -qi 'https' README_RELEASE.md 2>/dev/null; then
  echo 'WARNING: release guide does not mention HTTPS';
fi

python -m compileall -q backend/app || fail=1
./deploy/security_check.sh || fail=1
if command -v pytest >/dev/null 2>&1; then
  pytest -q || fail=1
else
  echo 'WARNING: pytest is not installed; test suite skipped'
fi

if [ "$fail" -ne 0 ]; then exit 1; fi
echo 'Dalil Syria RELEASE preflight: PASS'
