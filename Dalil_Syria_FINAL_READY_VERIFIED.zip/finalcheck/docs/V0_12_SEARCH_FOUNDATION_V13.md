# Dalil Syria V0.12 — Search Foundation V13

Implemented production-oriented search foundation without changing the core version:
- Unicode/Arabic-aware query normalization (diacritics, whitespace, case folding).
- Search aliases through `place_aliases`.
- Normalized `places.search_text` with trigram index for scalable text matching.
- Keyset/cursor pagination replaces OFFSET for public search.
- Backward-compatible `limit`; response now exposes `next_cursor`.
- PostgreSQL `pg_trgm` extension is declared by migration.
- 46 automated tests pass.
