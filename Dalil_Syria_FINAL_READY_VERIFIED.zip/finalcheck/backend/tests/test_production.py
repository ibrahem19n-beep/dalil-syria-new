from pathlib import Path


def test_production_compose_has_no_public_db_or_backend_ports():
    text = Path('deploy/docker-compose.production.yml').read_text()
    assert 'expose:' in text
    assert '127.0.0.1:5432' not in text
    assert '"127.0.0.1:8000:8000"' not in text
    assert 'CADDY_DOMAIN' in text


def test_production_backend_is_non_root_and_read_only():
    dockerfile = Path('backend/Dockerfile').read_text()
    compose = Path('deploy/docker-compose.production.yml').read_text()
    assert 'USER 10001' in dockerfile
    assert 'read_only: true' in compose


def test_backup_restore_scripts_exist():
    assert Path('deploy/backup.sh').exists()
    assert Path('deploy/restore.sh').exists()
