from pathlib import Path
import os


def test_rc2_security_configuration():
    text = Path('backend/app/config.py').read_text()
    assert 'DALIL_AUTH_SECRET' in text
    assert '32 characters' in text


def test_rc2_rate_limit_exists():
    text = Path('backend/app/main.py').read_text()
    assert '_rate_limit' in text
    assert '429' in text


def test_rc2_release_marker():
    text = Path('backend/app/main.py').read_text()
    assert 'RC2' in text
