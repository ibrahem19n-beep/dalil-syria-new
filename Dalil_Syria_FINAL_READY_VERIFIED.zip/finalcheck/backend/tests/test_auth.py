import os
os.environ['DALIL_AUTH_SECRET']='test-secret'
from app.auth import hash_password, verify_password, create_token, decode_token

def test_password_roundtrip():
    encoded=hash_password('StrongPassword123!')
    assert verify_password('StrongPassword123!', encoded)
    assert not verify_password('wrong', encoded)

def test_token_roundtrip():
    token=create_token(7,['user','admin'])
    data=decode_token(token)
    assert data['sub']=='7'
    assert 'admin' in data['roles']

def test_token_has_standard_header_and_jti():
    token=create_token(7,['user'])
    header,payload,_=token.split('.')
    import base64, json
    decoded=json.loads(base64.urlsafe_b64decode(header + '=' * (-len(header) % 4)))
    data=decode_token(token)
    assert decoded == {'alg':'HS256','typ':'JWT'}
    assert isinstance(data['jti'], str) and len(data['jti']) == 32

def test_refresh_token_is_random_and_hashed():
    from app.auth import create_refresh_token, hash_refresh_token
    a, b = create_refresh_token(), create_refresh_token()
    assert a != b
    assert len(a) >= 60
    assert hash_refresh_token(a) != a
    assert len(hash_refresh_token(a)) == 64
