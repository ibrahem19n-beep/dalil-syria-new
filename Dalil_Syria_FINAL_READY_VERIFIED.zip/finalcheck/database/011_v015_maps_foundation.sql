-- V0.15 / Maps foundation
-- Coordinates remain authoritative in places and are synchronized to PostGIS by the existing trigger.
-- This index accelerates public map/nearby reads while keeping the provider replaceable.
CREATE INDEX IF NOT EXISTS idx_places_public_geom
ON places USING GIST (geom)
WHERE status IN ('published','active');
