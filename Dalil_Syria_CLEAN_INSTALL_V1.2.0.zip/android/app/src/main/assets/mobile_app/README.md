# Dalil Syria UI/UX V2

UI/UX iteration built on the project V0.12 core baseline, with the historical V8 technical-freeze package retained as an implementation reference.

## Included
- Mobile-first home/search/discovery experience.
- Category chips with active state.
- Map discovery with reset/location controls and place popups.
- Place cards with category, distance and rating metadata when available.
- Richer place detail sheet with favorite and map actions.
- Favorites persistence.
- Nearby results using the backend nearby endpoint.
- Official external app icon is user-approved and bundled at `assets/brand/icon/` (master preserved; platform size derivatives only).
- Splash, internal photography direction, and store marketing screenshots remain pending explicit user choice.
