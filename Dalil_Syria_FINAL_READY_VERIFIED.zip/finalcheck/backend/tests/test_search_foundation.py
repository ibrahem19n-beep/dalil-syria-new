from app.search import normalize_query, search_terms

def test_arabic_query_normalization():
    assert normalize_query("  مَطْعَم   دمشق  ") == "مطعم دمشق"

def test_search_terms():
    assert search_terms("Hotel   Damascus") == ("hotel", "damascus")
