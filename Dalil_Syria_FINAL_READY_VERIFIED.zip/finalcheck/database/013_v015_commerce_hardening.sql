-- V0.15 Commerce hardening: concrete provider-account routing and financial invariants.
CREATE UNIQUE INDEX IF NOT EXISTS uq_provider_account_currency
  ON commerce.provider_accounts(provider_id, currency_code)
  WHERE currency_code IS NOT NULL;

INSERT INTO commerce.provider_accounts(provider_id,account_name,currency_code,is_active,metadata)
SELECT p.id,'mock-default',NULL,TRUE,'{"environment":"test","managed_by":"dalil"}'::jsonb
FROM commerce.payment_providers p
WHERE p.code='mock'
  AND NOT EXISTS (SELECT 1 FROM commerce.provider_accounts a WHERE a.provider_id=p.id AND a.account_name='mock-default');

ALTER TABLE commerce.payments
  ADD CONSTRAINT chk_payment_captured_not_above_amount CHECK (captured_amount_minor <= amount_minor),
  ADD CONSTRAINT chk_payment_refunded_not_above_captured CHECK (refunded_amount_minor <= captured_amount_minor);

CREATE INDEX IF NOT EXISTS idx_webhook_events_status_received
  ON commerce.provider_webhook_events(status,received_at);
CREATE INDEX IF NOT EXISTS idx_reconciliation_items_run_status
  ON commerce.reconciliation_items(run_id,status);
