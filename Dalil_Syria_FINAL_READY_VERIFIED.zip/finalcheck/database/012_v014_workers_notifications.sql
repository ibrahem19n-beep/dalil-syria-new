-- V0.14: durable notification preferences and worker safety indexes.
CREATE TABLE IF NOT EXISTS notification_preferences (
 id BIGSERIAL PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 channel VARCHAR(30) NOT NULL,
 enabled BOOLEAN NOT NULL DEFAULT TRUE,
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(user_id, channel)
);

CREATE INDEX IF NOT EXISTS idx_notification_processing_recovery
 ON notification_deliveries(status, attempts, available_at);

CREATE INDEX IF NOT EXISTS idx_outbox_processing_recovery
 ON commerce.outbox_events(status, attempts, available_at);
