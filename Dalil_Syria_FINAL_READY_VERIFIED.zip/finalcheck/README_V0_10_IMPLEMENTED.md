# Dalil Syria V0.10 — Core Operational Build

Implemented on top of V0.9 without removing existing V0.7/V0.8/V0.9 functionality.

- FastAPI version 0.10.0.
- Hardened Place Repository create/update with contact + coordinates.
- PostGIS geometry synchronization trigger and indexes.
- Public place listing excludes draft/archived records.
- Admin place listing and soft-delete endpoint.
- Authenticated review creation with duplicate-review protection.
- Authenticated favorites list/add/remove endpoints.
- Audit logging retained for destructive admin actions.
- Added V0.10 tests.
