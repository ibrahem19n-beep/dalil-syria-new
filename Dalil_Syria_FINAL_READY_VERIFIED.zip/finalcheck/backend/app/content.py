def validate_image(mime_type: str, size_bytes: int) -> bool:
    allowed = {"image/jpeg", "image/png", "image/webp"}
    return mime_type in allowed and 0 < size_bytes <= 10 * 1024 * 1024

def validate_language(code: str) -> bool:
    return code in {"ar", "en"}
