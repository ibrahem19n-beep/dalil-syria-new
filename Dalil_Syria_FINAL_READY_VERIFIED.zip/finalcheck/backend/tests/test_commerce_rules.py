import pytest
from decimal import Decimal
from app.commerce.fx import convert_minor

def test_fx_rounding():
    assert convert_minor(100, Decimal('1.234')) == 123

def test_payment_state_machine_shape():
    states = {'pending': {'authorized','captured'}, 'authorized': {'captured'}, 'failed': set()}
    assert 'authorized' in states['pending']
    assert 'captured' in states['authorized']
    assert 'captured' not in states['failed']

def test_mock_provider_supports_core_scenarios():
    from app.commerce.provider import MockPaymentProvider
    p=MockPaymentProvider()
    assert p.authorize(100,'SYP','x').status == 'authorized'
    assert p.capture('ref',100).status == 'captured'
    assert p.cancel('ref').status == 'cancelled'
    assert p.refund('ref',50).status == 'refunded'

def test_mock_provider_failure_scenarios():
    from app.commerce.provider import MockPaymentProvider
    p=MockPaymentProvider()
    assert p.authorize(100,'SYP','x',{'scenario':'REQUIRES_ACTION'}).status == 'requires_action'
    assert p.authorize(100,'SYP','x',{'scenario':'DECLINED'}).failure_code == 'DECLINED'
    assert p.authorize(100,'SYP','x',{'scenario':'TIMEOUT'}).failure_code == 'TIMEOUT'
    assert p.authorize(100,'SYP','x',{'scenario':'PROVIDER_ERROR'}).failure_code == 'PROVIDER_ERROR'

def test_provider_resolution_contract():
    from pathlib import Path
    source=Path('backend/app/commerce/router.py').read_text()
    assert 'provider_account_id' in source

def test_refund_model_requires_currency_contract():
    from pathlib import Path
    source=Path('backend/app/commerce/router.py').read_text()
    assert 'class RefundCreate' in source and 'currency: str' in source

def test_mock_provider_error_codes_are_distinct():
    from app.commerce.provider import MockPaymentProvider
    p=MockPaymentProvider()
    assert p.authorize(100,'SYP','x',{'scenario':'TIMEOUT'}).failure_code != p.authorize(100,'SYP','x',{'scenario':'PROVIDER_ERROR'}).failure_code
