from backend.app.maps import public_config, validate_coordinates

def test_maps_public_config_has_syria_center_and_provider_abstraction(monkeypatch):
    monkeypatch.delenv('DALIL_MAPS_PROVIDER', raising=False)
    c = public_config()
    assert c['provider'] == 'auto'
    assert c['center']['latitude'] == 35.0
    assert c['center']['longitude'] == 38.5
    assert c['provider_locked'] is False

def test_coordinate_validation():
    validate_coordinates(33.5, 36.3)
    try:
        validate_coordinates(91, 36.3)
        assert False
    except ValueError:
        pass
