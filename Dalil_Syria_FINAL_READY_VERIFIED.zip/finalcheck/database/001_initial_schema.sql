CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS governorates (
 id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL,
 is_active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS locations (
 id BIGSERIAL PRIMARY KEY, parent_id BIGINT REFERENCES locations(id),
 governorate_id BIGINT REFERENCES governorates(id), name TEXT NOT NULL,
 slug TEXT NOT NULL, level TEXT NOT NULL, latitude DOUBLE PRECISION,
 longitude DOUBLE PRECISION, is_active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS brands (
 id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL,
 description TEXT, logo_url TEXT, website TEXT, status TEXT NOT NULL DEFAULT 'active',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS place_types (
 id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL,
 is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS places (
 id BIGSERIAL PRIMARY KEY, brand_id BIGINT REFERENCES brands(id),
 location_id BIGINT REFERENCES locations(id), place_type_id BIGINT REFERENCES place_types(id),
 name TEXT NOT NULL, slug TEXT NOT NULL, description TEXT, address TEXT,
 phone TEXT, whatsapp TEXT, website TEXT, latitude DOUBLE PRECISION,
 longitude DOUBLE PRECISION, geom GEOGRAPHY(POINT,4326),
 status TEXT NOT NULL DEFAULT 'draft',
 verification_status TEXT NOT NULL DEFAULT 'unverified', source TEXT,
 last_verified_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_places_brand ON places(brand_id);
CREATE INDEX IF NOT EXISTS idx_places_location ON places(location_id);
CREATE INDEX IF NOT EXISTS idx_places_status ON places(status);
CREATE INDEX IF NOT EXISTS idx_places_geom ON places USING GIST(geom);
CREATE INDEX IF NOT EXISTS idx_places_name ON places(name);

CREATE TABLE IF NOT EXISTS categories (
 id BIGSERIAL PRIMARY KEY, parent_id BIGINT REFERENCES categories(id),
 name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL, is_active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS place_categories (
 place_id BIGINT REFERENCES places(id) ON DELETE CASCADE,
 category_id BIGINT REFERENCES categories(id) ON DELETE CASCADE,
 PRIMARY KEY(place_id, category_id)
);
CREATE TABLE IF NOT EXISTS attributes (
 id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL,
 is_active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS place_attributes (
 place_id BIGINT REFERENCES places(id) ON DELETE CASCADE,
 attribute_id BIGINT REFERENCES attributes(id) ON DELETE CASCADE,
 value TEXT, PRIMARY KEY(place_id, attribute_id)
);
CREATE TABLE IF NOT EXISTS languages (
 code TEXT PRIMARY KEY, name TEXT NOT NULL, is_active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS place_translations (
 place_id BIGINT REFERENCES places(id) ON DELETE CASCADE,
 language_code TEXT REFERENCES languages(code), name TEXT, description TEXT,
 PRIMARY KEY(place_id, language_code)
);
CREATE TABLE IF NOT EXISTS place_images (
 id BIGSERIAL PRIMARY KEY, place_id BIGINT REFERENCES places(id) ON DELETE CASCADE,
 storage_key TEXT NOT NULL, url TEXT, is_cover BOOLEAN DEFAULT FALSE,
 sort_order INT DEFAULT 0, source TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS opening_hours (
 id BIGSERIAL PRIMARY KEY, place_id BIGINT REFERENCES places(id) ON DELETE CASCADE,
 day_of_week INT CHECK(day_of_week BETWEEN 0 AND 6), open_time TIME,
 close_time TIME, is_closed BOOLEAN DEFAULT FALSE, is_24_hours BOOLEAN DEFAULT FALSE
);
CREATE TABLE IF NOT EXISTS users (
 id BIGSERIAL PRIMARY KEY, email TEXT UNIQUE, phone TEXT UNIQUE, password_hash TEXT,
 preferred_language TEXT REFERENCES languages(code), status TEXT DEFAULT 'active',
 created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS favorites (
 user_id BIGINT REFERENCES users(id) ON DELETE CASCADE,
 place_id BIGINT REFERENCES places(id) ON DELETE CASCADE,
 created_at TIMESTAMPTZ DEFAULT now(), PRIMARY KEY(user_id, place_id)
);
CREATE TABLE IF NOT EXISTS reviews (
 id BIGSERIAL PRIMARY KEY, user_id BIGINT REFERENCES users(id),
 place_id BIGINT REFERENCES places(id), rating INT CHECK(rating BETWEEN 1 AND 5),
 comment TEXT, status TEXT DEFAULT 'pending', created_at TIMESTAMPTZ DEFAULT now(),
 updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS reports (
 id BIGSERIAL PRIMARY KEY, user_id BIGINT REFERENCES users(id),
 place_id BIGINT REFERENCES places(id), report_type TEXT NOT NULL,
 description TEXT, status TEXT DEFAULT 'open', created_at TIMESTAMPTZ DEFAULT now(),
 resolved_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id BIGSERIAL PRIMARY KEY, actor_user_id BIGINT REFERENCES users(id),
 action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id BIGINT,
 old_data JSONB, new_data JSONB, created_at TIMESTAMPTZ DEFAULT now()
);
