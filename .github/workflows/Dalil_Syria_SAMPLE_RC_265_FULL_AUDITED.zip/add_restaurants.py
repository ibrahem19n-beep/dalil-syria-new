import json,math
from pathlib import Path
p=Path('/mnt/data/dalil_bulk_work/mobile_app/data/places.json');rows=json.loads(p.read_text(encoding='utf-8'))
A='23456789CFGHJMPQRVWX';R=[20,1,0.05,0.0025,0.000125]
def enc(lat,lon):
 if lat==90:lat-=1e-12
 lat=max(-90,min(90,lat));lon=((lon+180)%360)-180;lat+=90;lon+=180;s=''
 for r in R:
  a=int(lat/r);b=int(lon/r);s+=A[a%20]+A[b%20];lat-=a*r;lon-=b*r
 return s[:8]+'+'+s[8:]
def dec(c,ref=(33.513,36.29)):
 c=c.upper().replace(' ','');b,a=c.split('+');sig=b+a;rc=enc(*ref).replace('+','')
 if len(sig)<8:sig=rc[:8-len(b)]+sig
 sig=sig.ljust(10,'2');lat=-90;lon=-180
 for i in range(0,10,2):lat+=A.index(sig[i])*R[i//2];lon+=A.index(sig[i+1])*R[i//2]
 return lat+R[4]/2,lon+R[4]/2
c=[
(2153,'قصر كيوان','Qasr Kiwan Restaurant','G778+5XW',4.1,245,'+963112127240','09:00–01:00'),
(2154,'مطعم عنبر','Anbar Restaurant','G865+4MX',4.6,20,'+963115416969','24/7 حسب المصدر'),
(2155,'مطعم قصر النرجس','Qasr Al-Nargis Restaurant','G866+53P',4.3,118,'+963932044499','11:00–03:00'),
(2156,'كالي كافيه ومطعم','Cali Cafe Restaurant','G79M+PCJ',4.2,97,'+963957777138','09:00–00:00'),
(2157,'جيميني كافيه وغريل','Gemini Cafe & Grill','G78P+WQ8',4.2,78,'+963993322239','13:30–00:00 + مناوبة ليلية'),
(2158,'أروكا رستوران','Aroka Restaurant','G8P3+HHJ',4.8,37,'+963112712963','14:00–00:00'),
(2159,'مطعم أم شريف','Um Sharif Restaurant','G77R+GC6',4.4,49,'+963933809100','12:30–16:00 و20:30–23:30'),
(2160,'نارة دامسكينو','Nara Damaskino Restaurant','G72G+968',4.6,18,'','08:30–02:30'),
]
ex={(round(float(x['latitude']),5),round(float(x['longitude']),5)) for x in rows};names={x['name_ar'].lower() for x in rows};out=[]
for id_,ar,en,plus,rating,reviews,phone,hours in c:
 lat,lon=dec(plus)
 if not (33.47<=lat<=33.57 and 36.22<=lon<=36.34):continue
 if (round(lat,5),round(lon,5)) in ex or ar.lower() in names:continue
 if any(math.hypot((lat-float(x['latitude']))*111,(lon-float(x['longitude']))*93)<0.03 for x in rows+out):continue
 out.append({'id':id_,'name_ar':ar,'name_en':en,'category_ar':'مطاعم','category_en':'Restaurants','address_ar':'دمشق','address_en':'Damascus','phone':phone,'latitude':round(lat,6),'longitude':round(lon,6),'rating':rating,'review_count':reviews,'hours':hours,'hours_en':hours,'aliases':[ar,en.lower(),plus.lower()],'source':'Current business listing + published Plus Code','verification':'source_verified_plus_code_coordinate_decoded_2026-09-19','last_verified':'2026-09-19','opening_hours':[]})
rows.extend(out);p.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8');print('ADDED_RESTAURANTS',len(out),'COUNT',len(rows));[print(x['id'],x['name_ar'],x['latitude'],x['longitude']) for x in out]
