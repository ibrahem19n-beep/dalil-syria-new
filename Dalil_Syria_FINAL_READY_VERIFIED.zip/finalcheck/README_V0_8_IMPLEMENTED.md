# Dalil Syria V0.8 — Implemented

V0.8 continues directly from V0.7 and adds the first operational backend layer.

Implemented:
- real password registration using scrypt
- bearer-token `/auth/me`
- role-based admin authorization for protected write operations
- repository layer for Place CRUD/list/get
- admin Place update endpoint
- protected Place creation
- pagination metadata and optional status filtering
- unique place slug database index
- operational indexes for places, reviews and reports
- audit actor is now the authenticated user instead of NULL for archive/update actions
- authentication and repository unit coverage

Validation:
- Python compilation passed
- 7 automated tests passed

Next build target: production-grade repository/service separation, review/report moderation workflows, media/hours/translation management, admin dashboard, and integration tests against PostgreSQL/PostGIS.
