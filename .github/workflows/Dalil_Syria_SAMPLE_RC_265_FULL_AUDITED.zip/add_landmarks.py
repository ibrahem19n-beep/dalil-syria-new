import json,math
from pathlib import Path
p=Path('/mnt/data/dalil_bulk_work/mobile_app/data/places.json');rows=json.loads(p.read_text(encoding='utf-8'))
A='23456789CFGHJMPQRVWX';R=[20,1,0.05,0.0025,0.000125]
def enc(lat,lon):
 if lat==90:lat-=1e-12
 lat=max(-90,min(90,lat));lon=((lon+180)%360)-180;lat+=90;lon+=180;s=''
 for r in R:
  a=int(lat/r);b=int(lon/r);s+=A[a%20]+A[b%20];lat-=a*r;lon-=b*r
 return s[:8]+'+'+s[8:]
def dec(c,ref=(33.513,36.29)):
 c=c.upper().replace(' ','');b,a=c.split('+');sig=b+a;rc=enc(*ref).replace('+','')
 if len(sig)<8:sig=rc[:8-len(b)]+sig
 sig=sig.ljust(10,'2');lat=-90;lon=-180
 for i in range(0,10,2):lat+=A.index(sig[i])*R[i//2];lon+=A.index(sig[i+1])*R[i//2]
 return lat+R[4]/2,lon+R[4]/2
c=[
(2129,'معبد جوبيتر','Jupiter Temple','G864+H5J',4.7,3),
(2130,'حديقة الأمويين','Umayyad Garden','G789+HM3',4.4,777),
(2131,'باب توما','Bab Touma','G878+H2W',4.7,672),
(2132,'زقاق الأتابكية','Atabakiya Alley','G7GP+X43',5.0,1),
(2133,'البيمارستان النوري','Nur Al-Din Bimaristan','G863+39H',4.3,46),
(2134,'نصب السيف الأموي','Umayyad Sword Monument','G76H+X8M',4.6,73),
(2135,'حديقة النيربين','Al-Nairabin Park','G7C9+X6P',4.4,281),
(2136,'حمام القيمرية','Qaimariya Bath','G866+XCW',4.7,12),
(2137,'المتحف الحربي السوري','Syrian War Museum','G77R+6C4',4.5,8),
(2138,'حديقة ابن الهيثم','Ibn Al-Haytham Park','G8H8+286',4.2,173),
(2139,'قصر نصان','Nassan Palace','G869+256',4.6,12),
]
ex={(round(float(x['latitude']),5),round(float(x['longitude']),5)) for x in rows};names={x['name_ar'].lower() for x in rows};out=[]
for id_,ar,en,plus,rating,reviews in c:
 lat,lon=dec(plus)
 if not (33.47<=lat<=33.57 and 36.22<=lon<=36.34):continue
 if (round(lat,5),round(lon,5)) in ex or ar.lower() in names:continue
 if any(math.hypot((lat-float(x['latitude']))*111,(lon-float(x['longitude']))*93)<0.03 for x in rows+out):continue
 out.append({'id':id_,'name_ar':ar,'name_en':en,'category_ar':'معالم سياحية','category_en':'Tourist Attractions','address_ar':'دمشق','address_en':'Damascus','phone':'','latitude':round(lat,6),'longitude':round(lon,6),'rating':rating,'review_count':reviews,'hours':'','hours_en':'','aliases':[ar,en.lower(),plus.lower()],'source':'Current business listing + published Plus Code','verification':'source_verified_plus_code_coordinate_decoded_2026-09-19','last_verified':'2026-09-19','opening_hours':[]})
rows.extend(out);p.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8');print('ADDED_LANDMARKS',len(out),'COUNT',len(rows));[print(x['id'],x['name_ar'],x['latitude'],x['longitude']) for x in out]
