from .db import get_conn
from .maps import validate_coordinates

class PlaceRepository:
    @staticmethod
    def list(page: int, limit: int, status: str | None = None):
        offset = (page - 1) * limit
        with get_conn() as conn:
            where = "WHERE 1=1"
            params = []
            if status:
                where += " AND status=%s"
                params.append(status)
            rows = conn.execute(
                f"SELECT id,name,slug,address,latitude,longitude,status,verification_status FROM places {where} ORDER BY id DESC LIMIT %s OFFSET %s",
                (*params, limit, offset),
            ).fetchall()
            total = conn.execute(f"SELECT count(*) AS n FROM places {where}", tuple(params)).fetchone()["n"]
        return rows, total

    @staticmethod
    def get(place_id: int):
        with get_conn() as conn:
            return conn.execute(
                "SELECT id,name,slug,description,address,phone,whatsapp,website,latitude,longitude,status,verification_status,brand_id,location_id,place_type_id,created_at,updated_at FROM places WHERE id=%s",
                (place_id,),
            ).fetchone()


    @staticmethod
    def get_public(place_id: int):
        with get_conn() as conn:
            return conn.execute(
                "SELECT id,name,slug,description,address,phone,whatsapp,website,latitude,longitude,status,verification_status,brand_id,location_id,place_type_id,created_at,updated_at FROM places WHERE id=%s AND status IN ('published','active')",
                (place_id,),
            ).fetchone()

    @staticmethod
    def create(data: dict):
        if data.get('latitude') is not None and data.get('longitude') is not None:
            validate_coordinates(float(data['latitude']), float(data['longitude']))
        with get_conn() as conn:
            row = conn.execute(
                """INSERT INTO places
                (name,slug,description,address,phone,whatsapp,website,latitude,longitude,status,verification_status)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'unverified')
                RETURNING id,name,slug,address,phone,whatsapp,website,latitude,longitude,status,verification_status,created_at""",
                (data['name'], data['slug'], data.get('description'), data.get('address'),
                 data.get('phone'), data.get('whatsapp'), data.get('website'), data.get('latitude'),
                 data.get('longitude'), data.get('status','draft'))).fetchone()
            conn.commit()
            return row

    @staticmethod
    def update(place_id: int, data: dict):
        if data.get('latitude') is not None and data.get('longitude') is not None:
            validate_coordinates(float(data['latitude']), float(data['longitude']))
        allowed = {'name','slug','description','address','phone','whatsapp','website','latitude','longitude','status'}
        fields = {k:v for k,v in data.items() if k in allowed}
        if not fields: return PlaceRepository.get(place_id)
        sets = ', '.join(f"{k}=%s" for k in fields)
        with get_conn() as conn:
            row = conn.execute(
                f"UPDATE places SET {sets}, updated_at=now() WHERE id=%s "
                "RETURNING id,name,slug,address,phone,whatsapp,website,latitude,longitude,status,verification_status,updated_at",
                (*fields.values(), place_id)).fetchone()
            conn.commit()
            return row

    @staticmethod
    def archive(place_id: int):
        with get_conn() as conn:
            row = conn.execute("UPDATE places SET status='archived',updated_at=now() WHERE id=%s RETURNING id,name,status", (place_id,)).fetchone()
            conn.commit()
            return row
