# Release V14
Core remains V0.12. V14 consolidates authentication abuse protection and production HTTP security headers on top of V13.
Tests: 46/46.
