# Dalil Syria — Store Launch Package V1

## Project
- Core version: V0.12
- App version: 1.0.0
- Application ID: com.dalilsyria.app
- Current stage: Store Launch preparation

## Locked visual assets
- Official external App Icon: `mobile_app/assets/brand/icon/dalil-syria-app-icon-master-1536.png`
- Primary internal hero: `mobile_app/assets/brand/dalil-syria-selected.png`
- Both are locked and must not be redesigned or replaced.

## Store listing draft
### App name
دليل سوريا

### Short description
اكتشف المطاعم والفنادق والسياحة والخدمات في سوريا بسهولة.

### Full description
دليل سوريا هو دليلك لاكتشاف الأماكن والخدمات في سوريا.
ابحث عن المطاعم والفنادق والمقاهي والمعالم السياحية والخدمات، واستكشف الخيارات القريبة منك، وتعرّف على التفاصيل وأوقات العمل والتقييمات والمعلومات المتاحة عن كل مكان.

هدف التطبيق هو جمع دليل الأماكن والخدمات السورية في تجربة بسيطة وسريعة وقابلة للتوسع لتخدم السكان والزوار والسياح والأعمال المحلية.

### Category direction
Travel & Local / Travel & Tourism (final Play Console category selection is an external account action).

### Content / privacy gate
Before public submission, the real production deployment must provide the final privacy-policy URL, data-safety answers, contact/support information, and any required declarations in Play Console.

### Release artifact gate
The Android project is release source/RC. A production-signed AAB must be generated with the owner's signing credentials and production backend configuration in a real Android build environment before upload.

## Visual approval gate — DO NOT AUTO-SELECT
Store screenshots and any new marketing artwork are still PENDING USER CHOICE.
Do not generate, select, or install replacement screenshots/artwork automatically.

## Final external actions still required
1. Configure production backend/API endpoint and secrets.
2. Generate production-signed Android App Bundle (AAB).
3. Complete Google Play Console app setup and required declarations.
4. Add the final user-approved store screenshots/marketing visuals.
5. Complete testing/release tracks and submit for review.

## Status
Store Launch package preparation: READY.
Public store publication: NOT YET CLAIMED — requires the real external Play Console and signed production AAB.
