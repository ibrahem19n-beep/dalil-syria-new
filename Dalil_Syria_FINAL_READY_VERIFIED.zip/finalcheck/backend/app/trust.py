VALID_STATUSES = {"pending", "verified", "rejected"}

def validate_verification_status(value: str) -> str:
    if value not in VALID_STATUSES:
        raise ValueError("invalid verification status")
    return value
