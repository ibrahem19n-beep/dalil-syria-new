CREATE TABLE IF NOT EXISTS roles (
 id BIGSERIAL PRIMARY KEY,
 name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS user_roles (
 user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 role_id BIGINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
 PRIMARY KEY(user_id, role_id)
);

INSERT INTO roles(name) VALUES
 ('user'),('moderator'),('content_manager'),('admin'),('super_admin')
ON CONFLICT(name) DO NOTHING;

CREATE INDEX IF NOT EXISTS idx_user_roles_user ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_role ON user_roles(role_id);
