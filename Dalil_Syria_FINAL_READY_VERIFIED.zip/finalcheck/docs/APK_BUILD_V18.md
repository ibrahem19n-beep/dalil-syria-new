# Dalil Syria V0.12 — APK Build Stage V18

This stage adds a reproducible GitHub Actions release APK build path.

Important:
- The generated artifact is unsigned unless signing secrets are configured.
- Never publish an unsigned APK as the official release.
- The signing key must be generated and stored outside the repository.
- Keep the same signing key for every future update.

Flow:
1. Push repository to a private GitHub repository.
2. Run the release workflow manually or push a v-tag.
3. Download the `dalil-syria-release-apk-unsigned` artifact.
4. Sign it in the next release-signing stage.
