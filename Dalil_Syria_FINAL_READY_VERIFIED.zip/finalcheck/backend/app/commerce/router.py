import hashlib, json, hmac, os
from fastapi import APIRouter, Depends, Header, HTTPException, Query
from pydantic import BaseModel, Field
from .provider import PROVIDERS
from ..db import get_conn
from ..auth import require_admin

router = APIRouter(tags=['commerce'])

class OrderItem(BaseModel):
    item_type: str = Field(min_length=1, max_length=50)
    reference_id: str | None = None
    description: str | None = None
    quantity: int = Field(gt=0)
    unit_amount_minor: int = Field(ge=0)
    metadata: dict = {}
class OrderCreate(BaseModel):
    order_type: str = Field(min_length=1, max_length=50)
    currency: str = Field(min_length=3, max_length=3)
    items: list[OrderItem] = Field(min_length=1)
    partner_id: int | None = None
    metadata: dict = {}
class PaymentCreate(BaseModel):
    order_public_id: str
    amount_minor: int = Field(gt=0)
    currency: str = Field(min_length=3, max_length=3)
    provider: str = 'mock'
    payment_method_id: str | None = None
class RefundCreate(BaseModel):
    amount_minor: int = Field(gt=0)
    currency: str = Field(min_length=3, max_length=3)
    reason: str | None = Field(default=None, max_length=200)
class WebhookCreate(BaseModel):
    event_id: str
    event_type: str
    payment_public_id: str | None = None
    status: str | None = None
    provider_reference: str | None = None
    metadata: dict = {}

PAYMENT_STATES = {
    'created': {'pending','failed','cancelled'}, 'pending': {'requires_action','authorized','captured','failed','cancelled'},
    'requires_action': {'authorized','failed','cancelled'}, 'authorized': {'captured','cancelled'},
    'captured': {'partially_refunded','refunded'}, 'partially_refunded': {'partially_refunded','refunded'},
}

def flag(conn, key):
    row=conn.execute('SELECT enabled FROM commerce.feature_flags WHERE key=%s',(key,)).fetchone()
    return bool(row and row['enabled'])

def idem_hash(payload):
    return hashlib.sha256(json.dumps(payload,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()

def ensure_idem(conn,key,endpoint,payload):
    if not key: raise HTTPException(400,'Idempotency-Key required')
    h=idem_hash(payload)
    row=conn.execute("SELECT * FROM commerce.idempotency_keys WHERE key=%s AND endpoint=%s AND actor_user_id IS NULL AND (expires_at IS NULL OR expires_at>now())",(key,endpoint)).fetchone()
    if row:
        if row['request_hash'] != h: raise HTTPException(409,'IDEMPOTENCY_CONFLICT')
        if row['status']=='completed': return dict(row['response_body']) if row['response_body'] else None
        raise HTTPException(409,'Request already processing')
    conn.execute("INSERT INTO commerce.idempotency_keys(key,endpoint,request_hash,status,expires_at) VALUES(%s,%s,%s,'processing',now()+interval '24 hours')",(key,endpoint,h))
    return None

def finish_idem(conn,key,endpoint,code,body):
    conn.execute("UPDATE commerce.idempotency_keys SET status='completed',response_code=%s,response_body=%s WHERE key=%s AND endpoint=%s AND actor_user_id IS NULL",(code,json.dumps(body),key,endpoint))

def event(conn,event_type,aggregate_type,aggregate_id,payload):
    conn.execute("INSERT INTO commerce.domain_events(event_type,aggregate_type,aggregate_id,payload) VALUES(%s,%s,%s,%s)",(event_type,aggregate_type,str(aggregate_id),json.dumps(payload)))
    conn.execute("INSERT INTO commerce.outbox_events(event_type,aggregate_type,aggregate_id,payload) VALUES(%s,%s,%s,%s)",(event_type,aggregate_type,str(aggregate_id),json.dumps(payload)))

def provider_for(conn, requested, currency, method_id=None):
    # Always resolve the concrete provider account so money cannot silently
    # route through a different account/currency configuration.
    q="""SELECT p.id,p.code,a.id AS provider_account_id
          FROM commerce.payment_providers p
          JOIN commerce.provider_accounts a ON a.provider_id=p.id
          WHERE p.is_active AND a.is_active
            AND (a.currency_code IS NULL OR a.currency_code=%s)
            AND (%s IS NULL OR EXISTS(SELECT 1 FROM commerce.payment_methods m WHERE m.id=%s AND m.provider_account_id=a.id AND m.is_active))
            AND (%s IS NULL OR p.code=%s)
          ORDER BY p.priority DESC,p.id,a.id LIMIT 1"""
    p=conn.execute(q,(currency,method_id,method_id,requested,requested)).fetchone()
    return (p,PROVIDERS.get(p['code'])) if p else (None,None)

def transition(old,new):
    if new not in PAYMENT_STATES.get(old,set()): raise HTTPException(409,'Illegal payment state transition')

@router.post('/api/v1/orders',status_code=201)
def create_order(data:OrderCreate,idempotency_key:str|None=Header(default=None,alias='Idempotency-Key')):
    with get_conn() as conn:
        replay=ensure_idem(conn,idempotency_key,'POST /api/v1/orders',data.model_dump())
        if replay is not None: return replay
        cur=conn.execute('SELECT code FROM commerce.currencies WHERE code=%s AND is_active',(data.currency.upper(),)).fetchone()
        if not cur: raise HTTPException(400,'Unsupported currency')
        subtotal=sum(i.quantity*i.unit_amount_minor for i in data.items)
        row=conn.execute("INSERT INTO commerce.orders(order_type,currency_code,partner_id,subtotal_minor,total_minor,metadata) VALUES(%s,%s,%s,%s,%s,%s) RETURNING id,public_id,status,currency_code,subtotal_minor,total_minor,created_at",(data.order_type,data.currency.upper(),data.partner_id,subtotal,subtotal,json.dumps(data.metadata))).fetchone()
        for i in data.items:
            total=i.quantity*i.unit_amount_minor
            conn.execute("INSERT INTO commerce.order_items(order_id,item_type,reference_id,description,quantity,unit_amount_minor,total_amount_minor,metadata) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)",(row['id'],i.item_type,i.reference_id,i.description,i.quantity,i.unit_amount_minor,total,json.dumps(i.metadata)))
        body=dict(row); event(conn,'OrderCreated','order',row['public_id'],body); finish_idem(conn,idempotency_key,'POST /api/v1/orders',201,body); conn.commit(); return body

@router.get('/api/v1/orders/{public_id}')
def get_order(public_id:str):
    with get_conn() as conn:
        row=conn.execute('SELECT public_id,order_type,status,currency_code,subtotal_minor,fee_minor,commission_minor,total_minor,metadata,created_at,updated_at FROM commerce.orders WHERE public_id=%s',(public_id,)).fetchone()
        if not row: raise HTTPException(404,'Order not found')
        items=conn.execute('SELECT item_type,reference_id,description,quantity,unit_amount_minor,total_amount_minor,metadata FROM commerce.order_items oi JOIN commerce.orders o ON o.id=oi.order_id WHERE o.public_id=%s ORDER BY oi.id',(public_id,)).fetchall()
    return {'order':row,'items':items}

@router.post('/api/v1/orders/{public_id}/cancel')
def cancel_order(public_id:str,role:str=Depends(require_admin)):
    with get_conn() as conn:
        o=conn.execute('SELECT * FROM commerce.orders WHERE public_id=%s FOR UPDATE',(public_id,)).fetchone()
        if not o: raise HTTPException(404,'Order not found')
        if o['status']=='cancelled': return {'public_id':public_id,'status':'cancelled'}
        if o['status'] not in {'created','pending'}: raise HTTPException(409,'Order cannot be cancelled')
        conn.execute("UPDATE commerce.orders SET status='cancelled',updated_at=now() WHERE id=%s",(o['id'],)); event(conn,'OrderCancelled','order',public_id,{'order_id':public_id}); conn.commit()
    return {'public_id':public_id,'status':'cancelled'}

@router.post('/api/v1/payments',status_code=201)
def create_payment(data:PaymentCreate,idempotency_key:str|None=Header(default=None,alias='Idempotency-Key')):
    with get_conn() as conn:
        if not flag(conn,'payments_enabled'): raise HTTPException(403,'Payments are disabled')
        replay=ensure_idem(conn,idempotency_key,'POST /api/v1/payments',data.model_dump())
        if replay is not None:return replay
        order=conn.execute('SELECT id,currency_code,total_minor FROM commerce.orders WHERE public_id=%s',(data.order_public_id,)).fetchone()
        if not order: raise HTTPException(404,'Order not found')
        if order['currency_code']!=data.currency.upper() or data.amount_minor!=order['total_minor']: raise HTTPException(400,'Payment amount/currency must match server order total')
        p,provider=provider_for(conn,data.provider,data.currency.upper(),data.payment_method_id)
        if not p or not provider: raise HTTPException(400,'No active payment provider available')
        row=conn.execute("INSERT INTO commerce.payments(order_id,provider_id,provider_account_id,payment_method_id,amount_minor,currency_code,status,metadata) VALUES(%s,%s,%s,%s,%s,%s,'created',%s) RETURNING id,public_id,status,amount_minor,currency_code,created_at",(order['id'],p['id'],p['provider_account_id'],data.payment_method_id,data.amount_minor,data.currency.upper(),json.dumps({'payment_method_id':data.payment_method_id}))).fetchone()
        body=dict(row); event(conn,'PaymentCreated','payment',row['public_id'],body); finish_idem(conn,idempotency_key,'POST /api/v1/payments',201,body); conn.commit(); return body

@router.get('/api/v1/payments/{public_id}')
def get_payment(public_id:str):
    with get_conn() as conn:
        row=conn.execute('SELECT public_id,status,amount_minor,currency_code,provider_reference,failure_code,created_at,updated_at FROM commerce.payments WHERE public_id=%s',(public_id,)).fetchone()
    if not row: raise HTTPException(404,'Payment not found')
    return row

def _payment_action(public_id,action,role):
    with get_conn() as conn:
        p=conn.execute('SELECT p.*,pp.code provider_code FROM commerce.payments p LEFT JOIN commerce.payment_providers pp ON pp.id=p.provider_id WHERE p.public_id=%s FOR UPDATE',(public_id,)).fetchone()
        if not p: raise HTTPException(404,'Payment not found')
        provider=PROVIDERS.get(p['provider_code'] or 'mock')
        if not provider: raise HTTPException(400,'Provider adapter unavailable')
        if action=='authorize':
            if p['status']=='authorized': return {'public_id':public_id,'status':'authorized'}
            transition(p['status'],'pending') if p['status']=='created' else None
            if p['status']=='created': conn.execute("UPDATE commerce.payments SET status='pending',updated_at=now() WHERE id=%s",(p['id'],))
            result=provider.authorize(p['amount_minor'],p['currency_code'],str(p['public_id']),p.get('metadata') or {})
            transition('pending',result.status) if result.status in PAYMENT_STATES['pending'] else (_ for _ in ()).throw(HTTPException(409,'Invalid provider state'))
            conn.execute('UPDATE commerce.payments SET status=%s,provider_reference=%s,failure_code=%s,updated_at=now() WHERE id=%s',(result.status,result.provider_reference,result.failure_code,p['id']))
            event(conn,'PaymentAuthorized' if result.status=='authorized' else 'PaymentFailed','payment',public_id,{'payment_id':public_id,'status':result.status}); conn.commit(); return {'public_id':public_id,'status':result.status}
        if action=='capture':
            if p['status']=='captured': return {'public_id':public_id,'status':'captured'}
            if p['status']!='authorized': raise HTTPException(409,'Illegal payment state')
            result=provider.capture(p['provider_reference'],p['amount_minor']); transition(p['status'],result.status)
            conn.execute('UPDATE commerce.payments SET status=%s,captured_amount_minor=amount_minor,updated_at=now() WHERE id=%s',(result.status,p['id']))
            conn.execute("INSERT INTO commerce.transactions(payment_id,order_id,partner_id,transaction_type,amount_minor,currency_code,provider_reference) SELECT id,order_id,(SELECT partner_id FROM commerce.orders WHERE id=order_id),'capture',amount_minor,currency_code,provider_reference FROM commerce.payments WHERE id=%s",(p['id'],))
            event(conn,'PaymentCaptured','payment',public_id,{'payment_id':public_id}); conn.commit(); return {'public_id':public_id,'status':'captured'}
        if action=='cancel':
            if p['status']=='cancelled': return {'public_id':public_id,'status':'cancelled'}
            if p['status'] not in {'authorized','pending','requires_action','created'}: raise HTTPException(409,'Illegal payment state')
            result=provider.cancel(p['provider_reference']); transition(p['status'],result.status) if p['status']!='created' else None
            conn.execute('UPDATE commerce.payments SET status=%s,updated_at=now() WHERE id=%s',(result.status,p['id'])); event(conn,'PaymentCancelled','payment',public_id,{'payment_id':public_id}); conn.commit(); return {'public_id':public_id,'status':'cancelled'}

@router.post('/api/v1/payments/{public_id}/authorize')
def authorize_payment(public_id:str,role:str=Depends(require_admin)): return _payment_action(public_id,'authorize',role)
@router.post('/api/v1/payments/{public_id}/capture')
def capture_payment(public_id:str,role:str=Depends(require_admin)): return _payment_action(public_id,'capture',role)
@router.post('/api/v1/payments/{public_id}/cancel')
def cancel_payment(public_id:str,role:str=Depends(require_admin)): return _payment_action(public_id,'cancel',role)

@router.post('/api/v1/payments/{public_id}/refunds',status_code=201)
def refund_payment(public_id:str,data:RefundCreate,idempotency_key:str|None=Header(default=None,alias='Idempotency-Key'),role:str=Depends(require_admin)):
    with get_conn() as conn:
        if not flag(conn,'payments_enabled'): raise HTTPException(403,'Payments are disabled')
        payload={'payment':public_id,**data.model_dump()}; replay=ensure_idem(conn,idempotency_key,'POST /api/v1/payments/{public_id}/refunds',payload)
        if replay is not None:return replay
        p=conn.execute('SELECT * FROM commerce.payments WHERE public_id=%s FOR UPDATE',(public_id,)).fetchone()
        if not p: raise HTTPException(404,'Payment not found')
        if p['status'] not in {'captured','partially_refunded'}: raise HTTPException(409,'Payment must be captured')
        if data.currency.upper() != p['currency_code']: raise HTTPException(400,'Refund currency must match payment currency')
        refunded=conn.execute("SELECT COALESCE(SUM(amount_minor),0) n FROM commerce.refunds WHERE payment_id=%s AND status IN ('requested','completed')",(p['id'],)).fetchone()['n']
        if refunded+data.amount_minor>p['amount_minor']: raise HTTPException(409,'Over-refund rejected')
        provider_row=conn.execute('SELECT code FROM commerce.payment_providers WHERE id=%s',(p['provider_id'],)).fetchone()
        provider=PROVIDERS.get(provider_row['code']) if provider_row else None
        if not provider: raise HTTPException(503,'Payment provider unavailable')
        result=provider.refund(p['provider_reference'],data.amount_minor)
        new_status='refunded' if refunded+data.amount_minor==p['amount_minor'] else 'partially_refunded'
        row=conn.execute("INSERT INTO commerce.refunds(payment_id,amount_minor,currency_code,status,provider_reference,reason,idempotency_key) VALUES(%s,%s,%s,%s,%s,%s,%s) RETURNING public_id,status,amount_minor,currency_code,provider_reference",(p['id'],data.amount_minor,p['currency_code'],result.status,result.provider_reference,data.reason,idempotency_key)).fetchone()
        conn.execute("INSERT INTO commerce.transactions(payment_id,order_id,transaction_type,amount_minor,currency_code,provider_reference) VALUES(%s,%s,'refund',%s,%s,%s)",(p['id'],p['order_id'],-data.amount_minor,p['currency_code'],result.provider_reference))
        conn.execute('UPDATE commerce.payments SET status=%s,refunded_amount_minor=%s,updated_at=now() WHERE id=%s',(new_status,refunded+data.amount_minor,p['id'])); event(conn,'RefundCompleted','refund',row['public_id'],dict(row)); finish_idem(conn,idempotency_key,'POST /api/v1/payments/{public_id}/refunds',201,dict(row)); conn.commit(); return row

@router.post('/api/v1/payments/webhooks/{provider_code}')
def provider_webhook(provider_code:str,data:WebhookCreate,x_signature:str|None=Header(default=None)):
    with get_conn() as conn:
        p=conn.execute('SELECT id FROM commerce.payment_providers WHERE code=%s AND is_active',(provider_code,)).fetchone()
        if not p: raise HTTPException(404,'Provider not found')
        raw=data.model_dump(); secret=os.getenv(f'DALIL_WEBHOOK_SECRET_{provider_code.upper()}') or os.getenv('DALIL_WEBHOOK_SECRET','')
        canonical=json.dumps(raw,sort_keys=True,separators=(',',':')).encode(); expected=hmac.new(secret.encode(),canonical,hashlib.sha256).hexdigest() if secret else ''
        valid=bool(x_signature and secret and hmac.compare_digest(x_signature,expected))
        if not valid: raise HTTPException(401,'Invalid webhook signature')
        existing=conn.execute('SELECT id,status FROM commerce.provider_webhook_events WHERE provider_id=%s AND event_id=%s',(p['id'],data.event_id)).fetchone()
        if existing: return {'status':'duplicate','event_id':data.event_id}
        conn.execute("INSERT INTO commerce.provider_webhook_events(provider_id,event_id,event_type,signature_valid,payload,status) VALUES(%s,%s,%s,true,%s,'received')",(p['id'],data.event_id,data.event_type,json.dumps(raw)))
        if data.payment_public_id and data.status:
            pay=conn.execute('SELECT id,status FROM commerce.payments WHERE public_id=%s FOR UPDATE',(data.payment_public_id,)).fetchone()
            if pay and data.status in PAYMENT_STATES.get(pay['status'],set()):
                conn.execute('UPDATE commerce.payments SET status=%s,provider_reference=COALESCE(%s,provider_reference),updated_at=now() WHERE id=%s',(data.status,data.provider_reference,pay['id']))
                event(conn,'Payment'+data.status.title().replace('_',''),'payment',data.payment_public_id,{'payment_id':data.payment_public_id,'source':'webhook'})
        conn.execute("UPDATE commerce.provider_webhook_events SET status='processed',processed_at=now() WHERE provider_id=%s AND event_id=%s",(p['id'],data.event_id)); conn.commit()
    return {'status':'processed','event_id':data.event_id}

@router.get('/api/v1/partners/{partner_id}/balance')
def partner_balance(partner_id:int, role:str=Depends(require_admin)):
    with get_conn() as conn:
        rows=conn.execute('SELECT currency_code,available_minor,reserved_minor,updated_at FROM commerce.partner_balance_accounts pba JOIN commerce.partner_accounts pa ON pa.id=pba.partner_account_id WHERE pa.partner_id=%s ORDER BY currency_code',(partner_id,)).fetchall()
    return {'partner_id':partner_id,'items':rows}

@router.get('/api/v1/partners/{partner_id}/settlements')
def partner_settlements(partner_id:int,limit:int=Query(100,ge=1,le=500), role:str=Depends(require_admin)):
    with get_conn() as conn:return {'items':conn.execute('SELECT public_id,currency_code,gross_minor,fee_minor,commission_minor,net_minor,status,period_start,period_end,created_at FROM commerce.settlements WHERE partner_id=%s ORDER BY id DESC LIMIT %s',(partner_id,limit)).fetchall()}
@router.get('/api/v1/partners/{partner_id}/payouts')
def partner_payouts(partner_id:int,limit:int=Query(100,ge=1,le=500), role:str=Depends(require_admin)):
    with get_conn() as conn:return {'items':conn.execute('SELECT public_id,settlement_id,amount_minor,currency_code,status,provider_reference,created_at,completed_at FROM commerce.payouts WHERE partner_id=%s ORDER BY id DESC LIMIT %s',(partner_id,limit)).fetchall()}

@router.get('/api/v1/admin/finance/transactions')
def finance_transactions(role:str=Depends(require_admin),limit:int=Query(100,ge=1,le=500)):
    with get_conn() as conn:return {'items':conn.execute('SELECT public_id,transaction_type,status,amount_minor,currency_code,provider_reference,created_at FROM commerce.transactions ORDER BY id DESC LIMIT %s',(limit,)).fetchall()}
@router.get('/api/v1/admin/finance/refunds')
def finance_refunds(role:str=Depends(require_admin),limit:int=Query(100,ge=1,le=500)):
    with get_conn() as conn:return {'items':conn.execute('SELECT public_id,payment_id,amount_minor,currency_code,status,provider_reference,created_at,completed_at FROM commerce.refunds ORDER BY id DESC LIMIT %s',(limit,)).fetchall()}
@router.get('/api/v1/admin/finance/settlements')
def finance_settlements(role:str=Depends(require_admin),limit:int=Query(100,ge=1,le=500)):
    with get_conn() as conn:return {'items':conn.execute('SELECT public_id,partner_id,currency_code,gross_minor,fee_minor,commission_minor,net_minor,status,created_at FROM commerce.settlements ORDER BY id DESC LIMIT %s',(limit,)).fetchall()}
@router.get('/api/v1/admin/finance/reconciliation')
def finance_reconciliation(role:str=Depends(require_admin),limit:int=Query(100,ge=1,le=500)):
    with get_conn() as conn:return {'items':conn.execute('SELECT id,status,started_at,completed_at,summary FROM commerce.reconciliation_runs ORDER BY id DESC LIMIT %s',(limit,)).fetchall()}
@router.post('/api/v1/admin/finance/refunds/{refund_id}/review')
def review_refund(refund_id:int,approved:bool=True,role:str=Depends(require_admin)):
    with get_conn() as conn:
        r=conn.execute('SELECT public_id,status FROM commerce.refunds WHERE id=%s FOR UPDATE',(refund_id,)).fetchone()
        if not r: raise HTTPException(404,'Refund not found')
        if r['status'] not in {'requested','completed'}: raise HTTPException(409,'Refund not reviewable')
        conn.execute("UPDATE commerce.refunds SET status=%s,completed_at=CASE WHEN %s THEN now() ELSE completed_at END WHERE id=%s",('completed' if approved else 'rejected',approved,refund_id)); conn.commit()
    return {'public_id':r['public_id'],'status':'completed' if approved else 'rejected'}
@router.post('/api/v1/admin/finance/payouts/{payout_id}/approve')
def approve_payout(payout_id:int,role:str=Depends(require_admin)):
    with get_conn() as conn:
        p=conn.execute('SELECT * FROM commerce.payouts WHERE id=%s FOR UPDATE',(payout_id,)).fetchone()
        if not p: raise HTTPException(404,'Payout not found')
        if not flag(conn,'partner_payouts_enabled'): raise HTTPException(403,'Partner payouts are disabled')
        if p['status'] not in {'requested','pending_review'}: raise HTTPException(409,'Payout not reviewable')
        bal=conn.execute('SELECT available_minor,reserved_minor FROM commerce.partner_balance_accounts pba JOIN commerce.partner_accounts pa ON pa.id=pba.partner_account_id WHERE pa.partner_id=%s AND pba.currency_code=%s FOR UPDATE',(p['partner_id'],p['currency_code'])).fetchone()
        if not bal or bal['available_minor']<p['amount_minor']: raise HTTPException(409,'Insufficient partner balance')
        conn.execute("UPDATE commerce.partner_balance_accounts pba SET available_minor=available_minor-%s,reserved_minor=reserved_minor+%s,updated_at=now() FROM commerce.partner_accounts pa WHERE pba.partner_account_id=pa.id AND pa.partner_id=%s AND pba.currency_code=%s",(p['amount_minor'],p['amount_minor'],p['partner_id'],p['currency_code']))
        conn.execute("UPDATE commerce.payouts SET status='processing' WHERE id=%s",(payout_id,)); event(conn,'PayoutRequested','payout',p['public_id'],{'payout_id':str(p['public_id'])}); conn.commit()
    return {'public_id':p['public_id'],'status':'processing'}
