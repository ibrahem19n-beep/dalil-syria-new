from decimal import Decimal, ROUND_HALF_UP

def convert_minor(amount_minor:int, rate:Decimal, target_minor_unit:int=2)->int:
    value=Decimal(amount_minor)*Decimal(rate)
    quantum=Decimal(1)
    return int(value.quantize(quantum,rounding=ROUND_HALF_UP))
