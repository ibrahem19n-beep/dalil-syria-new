import json
from pathlib import Path

DATA = Path(__file__).parents[2] / 'mobile_app' / 'data' / 'places.json'


def places():
    return json.loads(DATA.read_text(encoding='utf-8'))


def test_dataset_has_required_location_identity_fields():
    rows = places()
    assert rows
    ids = [int(p['id']) for p in rows]
    assert len(ids) == len(set(ids))
    for p in rows:
        assert p.get('name_ar') and p.get('name_en')
        assert p.get('category_ar') and p.get('category_en')
        assert p.get('address_ar') and p.get('address_en')
        assert isinstance(p.get('latitude'), (int, float))
        assert isinstance(p.get('longitude'), (int, float))
        assert 32.0 <= float(p['latitude']) <= 38.0
        assert 35.0 <= float(p['longitude']) <= 42.0
        assert p.get('source')
        assert p.get('verification')
        assert p.get('last_verified')


def test_dataset_rejects_closed_or_duplicate_coordinate_records():
    rows = places()
    for p in rows:
        status = str(p.get('status', '')).lower()
        assert 'closed' not in status and 'مغلق' not in status
    coords = [(round(float(p['latitude']), 6), round(float(p['longitude']), 6)) for p in rows]
    assert len(coords) == len(set(coords))


def test_ui_has_handlers_for_core_navigation_and_account_actions():
    app = (Path(__file__).parents[2] / 'mobile_app' / 'app.js').read_text(encoding='utf-8')
    html = (Path(__file__).parents[2] / 'mobile_app' / 'index.html').read_text(encoding='utf-8')
    for marker in ['data-tab="home"', 'data-tab="search"', 'data-tab="map"', 'data-tab="favorites"', 'data-tab="account"']:
        assert marker in html
    for marker in ['#searchBtn', '#quickNearby', '#quickMap', '#mapLocate', '#mapReset', '#allBtn', '#listView', '#mapView', '#helpBtn', '#reportBtn', '#adminBtn']:
        assert marker in app
    assert "$('#helpBtn').onclick=()=>" in app
    assert "$('#reportBtn').onclick=()=>" in app
