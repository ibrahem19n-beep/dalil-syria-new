# Dalil Syria — Admin Panel UI V6

واجهة إدارة RTL مرتبطة بواجهات `/api/v1/admin/*` الحالية.

## الأقسام
- Dashboard
- Places: بحث، تحقق، أرشفة
- Reviews: moderation
- Reports: moderation
- Users: status management
- Imports
- Audit log

توضع الواجهة خلف المصادقة/التفويض على الخادم في بيئة الإنتاج. لا تحتوي هذه النسخة على صور نهائية.
