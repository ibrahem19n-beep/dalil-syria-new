Dalil Syria — Clean Install Package v1.2.0

This package contains only the Android/mobile app source required to build the APK plus the single clean GitHub Actions workflow.

Version: 1.2.0
Version code: 3
Dataset: 265 verified places
Map: MapLibre GL JS 6.10.0 + OpenFreeMap vector style

The app includes local embedded place data, so the sample remains usable without a backend for places/search/nearby.
