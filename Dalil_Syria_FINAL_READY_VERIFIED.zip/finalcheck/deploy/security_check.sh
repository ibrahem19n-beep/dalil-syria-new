#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
fail=0

check() { if ! eval "$1" >/dev/null 2>&1; then echo "FAIL: $2"; fail=1; else echo "PASS: $2"; fi; }

check "grep -q 'read_only: true' deploy/docker-compose.production.yml" 'backend filesystem is read-only'
check "! grep -Eq '^[[:space:]]*-?[[:space:]]*\"?(5432|8000):' deploy/docker-compose.production.yml" 'database/backend are not publicly mapped'
check "grep -q 'USER 10001' backend/Dockerfile" 'backend runs as non-root user'
check "grep -q 'reverse_proxy app:80' deploy/Caddyfile" 'Caddy proxies to backend'
check "grep -q 'header.*Strict-Transport-Security\|Strict-Transport-Security' deploy/Caddyfile" 'HSTS configured'
check "grep -q 'DATABASE_URL' backend/app/db.py && ! grep -q 'change-me-before-production' backend/app/db.py" 'database URL has no insecure hard-coded credential fallback'
check "grep -q 'DALIL_AUTH_SECRET' .env.example && grep -q 'DALIL_CORS_ORIGINS' .env.example" 'required production secrets/config are documented'
check "! grep -RInE 'password[[:space:]]*=[[:space:]]*[\"'\"'](password|secret|change-me)' backend/app --exclude-dir=__pycache__" 'no obvious hard-coded application secrets'

if [ "$fail" -ne 0 ]; then exit 1; fi
echo 'Dalil Syria security verification: PASS'
