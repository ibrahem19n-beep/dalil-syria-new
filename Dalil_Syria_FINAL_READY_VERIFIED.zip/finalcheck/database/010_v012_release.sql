-- V0.12 release hardening
CREATE INDEX IF NOT EXISTS idx_places_status_updated ON places(status, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_places_slug ON places(slug);
CREATE INDEX IF NOT EXISTS idx_favorites_user_created ON favorites(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reviews_place_status_created ON reviews(place_id, status, created_at DESC);

ALTER TABLE users ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT now();
