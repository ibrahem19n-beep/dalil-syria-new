CREATE EXTENSION IF NOT EXISTS pg_trgm;
-- V0.12 search foundation: normalized search text + fast keyset-friendly indexes.
ALTER TABLE places ADD COLUMN IF NOT EXISTS search_text TEXT;
UPDATE places SET search_text = lower(trim(concat_ws(' ', name, description, address))) WHERE search_text IS NULL;
CREATE INDEX IF NOT EXISTS idx_places_search_status_id ON places(status, id DESC);
CREATE INDEX IF NOT EXISTS idx_places_search_text_trgm ON places USING gin (search_text gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_place_aliases_alias_lower ON place_aliases (lower(alias));
