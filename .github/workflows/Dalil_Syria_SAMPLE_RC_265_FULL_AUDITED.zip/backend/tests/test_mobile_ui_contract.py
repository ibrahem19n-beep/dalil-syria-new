from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[2]
APP = ROOT / "mobile_app" / "app.js"
HTML = ROOT / "mobile_app" / "index.html"
DATA = ROOT / "mobile_app" / "data" / "places.json"

def test_mobile_ui_has_favorite_handler_and_persistence():
    s = APP.read_text(encoding="utf-8")
    assert "function toggleFav(" in s
    assert "localStorage.setItem('dalil_favorites'" in s
    assert "function showCollection()" in s
    assert "ensureLocalData()" in s

def test_mobile_ui_has_map_state_persistence_and_restore():
    s = APP.read_text(encoding="utf-8")
    assert "const MAP_STATE_KEY='dalil_map_state_v2'" in s
    assert "function saveMapState(" in s
    assert "function restoreMapState(" in s
    assert "saveMapState({kind:'place'" in s
    assert "saveMapState({kind:'user'" in s
    assert "restoreMapState()}" in s

def test_static_buttons_are_wired():
    h = HTML.read_text(encoding="utf-8")
    s = APP.read_text(encoding="utf-8")
    ids = ["searchBtn","clearSearch","locate","mapLocate","mapReset","quickNearby","quickMap","allBtn","listView","mapView","close","helpBtn","reportBtn","adminBtn","sendReport"]
    for i in ids:
        assert f'id="{i}"' in h
    assert "#searchBtn" in s and "#clearSearch" in s and "#locate" in s
    assert "#mapLocate" in s and "#mapReset" in s and "#quickNearby" in s and "#quickMap" in s
    assert "#allBtn" in s and "#listView" in s and "#mapView" in s and "#close" in s
    assert "#helpBtn" in s and "#reportBtn" in s and "#adminBtn" in s and "#sendReport" in s

def test_report_is_saved_locally():
    s = APP.read_text(encoding="utf-8")
    assert "dalil_reports" in s
    assert "status:'pending'" in s

def test_local_dataset_basic_integrity():
    rows=json.loads(DATA.read_text(encoding="utf-8"))
    assert len(rows) >= 30
    assert len({str(x["id"]) for x in rows}) == len(rows)
    assert len({(float(x["latitude"]),float(x["longitude"])) for x in rows}) == len(rows)
    assert all(30 <= float(x["latitude"]) <= 37 and 35 <= float(x["longitude"]) <= 39 for x in rows)
    assert not any(str(x.get("status","")).lower() in {"closed","permanently_closed","مغلق"} for x in rows)

def test_mobile_persistence_and_local_fallback_do_not_depend_on_server_message():
    js = Path('mobile_app/app.js').read_text(encoding='utf-8')
    assert "dalil_favorites" in js
    assert "dalil_map_state_v2" in js
    assert "dalil_last_destination_v1" in js
    assert "localStorage.setItem(DESTINATION_KEY" in js
    assert "await ensureLocalData()" in js
    assert "Local data could not be loaded" in js
    assert "بيانات البحث المحلية غير متاحة حالياً" in js
