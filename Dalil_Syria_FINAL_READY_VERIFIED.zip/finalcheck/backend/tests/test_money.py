from app.commerce.money import Money

def test_add(): assert Money(100,'USD').add(Money(25,'USD')).amount_minor == 125

def test_currency_mismatch():
    try:
        Money(1,'USD').add(Money(1,'EUR'))
        assert False
    except ValueError:
        assert True

def test_allocate(): assert [x.amount_minor for x in Money(100,'USD').allocate([1,1,1])] == [34,33,33]
