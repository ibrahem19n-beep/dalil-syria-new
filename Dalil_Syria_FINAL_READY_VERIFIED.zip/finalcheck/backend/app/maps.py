"""Provider-agnostic map/geocoding foundation for Dalil Syria.
Real provider credentials are intentionally kept outside the core domain.
"""
import os
from dataclasses import dataclass

@dataclass(frozen=True)
class MapsConfig:
    provider: str
    default_lat: float
    default_lng: float
    default_zoom: int
    geocoding_enabled: bool
    satellite_enabled: bool

def _bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name, str(default)).strip().lower()
    return value in {"1", "true", "yes", "on"}

def config() -> MapsConfig:
    return MapsConfig(
        provider=os.getenv("DALIL_MAPS_PROVIDER", "auto").strip() or "auto",
        default_lat=float(os.getenv("DALIL_MAPS_DEFAULT_LAT", "35.0")),
        default_lng=float(os.getenv("DALIL_MAPS_DEFAULT_LNG", "38.5")),
        default_zoom=int(os.getenv("DALIL_MAPS_DEFAULT_ZOOM", "6")),
        geocoding_enabled=_bool("DALIL_MAPS_GEOCODING_ENABLED", True),
        satellite_enabled=_bool("DALIL_MAPS_SATELLITE_ENABLED", False),
    )

def public_config() -> dict:
    c = config()
    return {
        "provider": c.provider,
        "center": {"latitude": c.default_lat, "longitude": c.default_lng},
        "default_zoom": c.default_zoom,
        "geocoding_enabled": c.geocoding_enabled,
        "satellite_enabled": c.satellite_enabled,
        "provider_locked": c.provider != "auto",
    }

def validate_coordinates(latitude: float, longitude: float) -> None:
    if not (-90 <= latitude <= 90):
        raise ValueError("latitude out of range")
    if not (-180 <= longitude <= 180):
        raise ValueError("longitude out of range")
