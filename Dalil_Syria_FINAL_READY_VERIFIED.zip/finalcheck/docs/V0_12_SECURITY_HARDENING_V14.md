# Dalil Syria V0.12 — Security Hardening V14

- Rate limits login, registration, and refresh-token endpoints using the existing process guard.
- Adds production HSTS and no-store handling for authentication responses.
- Keeps refresh-token rotation and server-side session revocation.
- No payment providers or external services enabled.
