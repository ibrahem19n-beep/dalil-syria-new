from pathlib import Path

def test_v010_migration_exists():
    assert Path('database/008_v010_core_operational.sql').exists()

def test_place_update_supports_coordinates():
    text=Path('backend/app/repositories.py').read_text()
    assert "'latitude'" in text and "'longitude'" in text

def test_api_version_is_v010():
    text=Path('backend/app/main.py').read_text()
    assert 'version="0.12.0"' in text

def test_public_api_filters_drafts():
    text=Path('backend/app/main.py').read_text()
    assert 'public_status' in text and 'published' in text

def test_favorites_and_reviews_routes_exist():
    text=Path('backend/app/main.py').read_text()
    assert '/api/v1/me/favorites' in text
    assert '/api/v1/places/{place_id}/reviews' in text
