# Dalil Syria — Android Release 1.0.0

This is the Android packaging layer for the V0.12 project.

- Application ID: `com.dalilsyria.app`
- Version: `1.0.0`
- Target SDK: 35
- Official external App Icon: locked to the user's selected icon; no redesign.
- No new internal visual assets were selected.

## Build
Requires Android Studio/Android SDK and Gradle 8.7+ compatible with Android Gradle Plugin 8.6.1.
Open the `android/` directory in Android Studio and build a signed AAB for Google Play.

## Important release gate
This package is the Android release source/RC, not a falsely claimed signed production AAB. Signing credentials and the production API/backend endpoint must be supplied/configured in the real build environment before store upload.
