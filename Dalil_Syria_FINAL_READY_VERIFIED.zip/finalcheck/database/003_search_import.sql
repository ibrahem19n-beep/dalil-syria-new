CREATE TABLE IF NOT EXISTS import_jobs (
 id BIGSERIAL PRIMARY KEY,
 filename TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'uploaded',
 total_rows BIGINT DEFAULT 0,
 valid_rows BIGINT DEFAULT 0,
 duplicate_rows BIGINT DEFAULT 0,
 rejected_rows BIGINT DEFAULT 0,
 created_at TIMESTAMPTZ DEFAULT now(),
 completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS import_rows (
 id BIGSERIAL PRIMARY KEY,
 import_job_id BIGINT NOT NULL REFERENCES import_jobs(id) ON DELETE CASCADE,
 row_number BIGINT NOT NULL,
 payload JSONB NOT NULL,
 validation_status TEXT NOT NULL DEFAULT 'pending',
 duplicate_of_place_id BIGINT REFERENCES places(id),
 review_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE INDEX IF NOT EXISTS idx_import_rows_job ON import_rows(import_job_id);
CREATE INDEX IF NOT EXISTS idx_import_rows_duplicate ON import_rows(duplicate_of_place_id);

CREATE TABLE IF NOT EXISTS place_aliases (
 id BIGSERIAL PRIMARY KEY,
 place_id BIGINT NOT NULL REFERENCES places(id) ON DELETE CASCADE,
 alias TEXT NOT NULL,
 language_code TEXT REFERENCES languages(code),
 UNIQUE(place_id, alias, language_code)
);
CREATE INDEX IF NOT EXISTS idx_place_aliases_alias ON place_aliases(alias);
