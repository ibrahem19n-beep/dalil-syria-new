from pathlib import Path

def test_v012_migration_exists():
    assert Path('database/010_v012_release.sql').exists()

def test_release_version_and_readiness():
    text=Path('backend/app/main.py').read_text()
    assert 'version="0.12.0"' in text
    assert "@app.get('/ready')" in text

def test_public_place_lookup_is_filtered():
    text=Path('backend/app/repositories.py').read_text()
    assert 'get_public' in text
    assert "status IN ('published','active')" in text

def test_security_headers_and_request_id():
    text=Path('backend/app/main.py').read_text()
    assert "X-Content-Type-Options" in text
    assert "X-Request-ID" in text
