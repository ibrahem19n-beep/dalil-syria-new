# دليل سوريا — Sample Release Audit (265 Places)

Date: 2026-09-19

## Data gate
- Local places: 265 exactly.
- Android embedded places: 265 exactly.
- Source/mobile and Android JSON: byte-equivalent after sync.
- IDs: 265 unique.
- Coordinates: 265 unique coordinate pairs at 6-decimal precision.
- Required identity/address fields: complete for all 265.
- Source, verification and last_verified: present for all 265.
- Verification date: 2026-09-19 for all 265.
- Coordinate bounds: 33.4377..33.55397 N, 36.21336..36.34536 E.
- No permanently-closed Central Pharmacy record is present.

## Functional gate
- Automated project tests: 60 passed.
- JavaScript syntax check: app.js passed.
- JavaScript syntax check: sw.js passed.
- Bottom navigation handlers: Home/Search/Map/Saved/Account wired.
- Search, category buttons, nearby, map open/reset, favorites, details, share, call, reports and help handlers present.
- Services category was fixed to return the app's service-oriented categories instead of an empty result.
- Home map now receives the full local set (up to 500 from the local endpoint), while the visible home list remains limited to 40 cards.

## Language gate
- Arabic RTL and English LTR are implemented.
- Full UI localization table is present for the main home/search/map/account/help/report flows.
- Place names/addresses/categories use language-specific fields.
- Map layer labels switch with language.

## Offline/reliability gate
- Selected destination and map state are persisted in localStorage.
- Last selected place coordinates are restored after reopening.
- Local place/search/nearby data can operate without the backend.
- Report drafts/status are stored locally.
- Important limitation: the basemap tiles are still remote network tiles (Esri). The place/destination state is offline-persistent, but the visual basemap is NOT fully offline yet.

## Map gate
- Leaflet map is configured with street and satellite layers.
- Place markers are generated from the same place dataset used by search/details.
- The current map provider is a remote Esri tile service. Esri documents worldwide street coverage and selected urban building-footprint coverage; OpenStreetMap also documents Damascus map coverage. This supports the current online map layer, but does not make it an offline map.
- A true offline basemap requires a separate packaged/offline tile strategy.

## Installation/build gate
- Android project is synchronized and source-ready.
- A real APK was NOT produced in this environment because Android SDK/build-tools and Gradle executable are not installed here. Therefore this audit does NOT claim an APK was built or installed.
- The repository contains GitHub Actions workflows that can build the debug APK using Android SDK 35 and Gradle 8.7.

## Final status
SOURCE RELEASE CANDIDATE — FUNCTIONALLY AUDITED.
APK BUILD GATE — PENDING EXTERNAL ANDROID BUILD ENVIRONMENT.
