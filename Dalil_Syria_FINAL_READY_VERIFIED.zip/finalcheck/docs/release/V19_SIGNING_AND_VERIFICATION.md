# V19 — Release APK Signing & Verification

This stage signs the release APK outside Google Play using a persistent keystore.
Never commit the keystore or passwords. Store them as CI secrets.

Required CI secrets:
- ANDROID_KEYSTORE_BASE64
- ANDROID_KEYSTORE_PASSWORD
- ANDROID_KEY_ALIAS
- ANDROID_KEY_PASSWORD

The signed APK must be verified with `apksigner verify --verbose` and its SHA-256 recorded before distribution.
Keep encrypted backups of the keystore. Losing it prevents seamless updates.
