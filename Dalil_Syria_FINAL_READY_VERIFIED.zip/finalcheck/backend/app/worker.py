"""Small synchronous worker loops for replay-safe outbox and notifications.

Transport/provider I/O is injected so production integrations can be added without
coupling the domain layer to a vendor. Failed jobs use the database retry policy.
"""
from __future__ import annotations

import signal
import time
from collections.abc import Callable

from .commerce.outbox import claim_batch, mark_failed, mark_published
from .notifications import claim_notifications, mark_notification_failed, mark_notification_sent


def process_outbox_once(publish: Callable[[dict], None], limit: int = 50) -> int:
    rows = claim_batch(limit)
    for row in rows:
        try:
            publish(row)
            mark_published(row["event_id"])
        except Exception as exc:  # provider/transport failure: retry through DB policy
            mark_failed(row["event_id"], exc)
    return len(rows)


def process_notifications_once(send: Callable[[dict], None], limit: int = 50) -> int:
    rows = claim_notifications(limit)
    for row in rows:
        try:
            send(row)
            mark_notification_sent(row["id"])
        except Exception as exc:
            mark_notification_failed(row["id"], exc)
    return len(rows)


def run_forever(
    publish: Callable[[dict], None],
    send: Callable[[dict], None],
    interval_seconds: float = 2.0,
    batch_size: int = 50,
) -> None:
    if interval_seconds < 0.1:
        raise ValueError("interval_seconds must be >= 0.1")
    if batch_size < 1:
        raise ValueError("batch_size must be >= 1")
    stopping = False

    def _stop(_signum, _frame):
        nonlocal stopping
        stopping = True

    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)

    while not stopping:
        processed = 0
        try:
            processed += process_outbox_once(publish, batch_size)
        except Exception:
            # A transient database/runtime failure must not terminate the container.
            # Claimed rows remain governed by the DB retry/lease policy.
            pass
        try:
            processed += process_notifications_once(send, batch_size)
        except Exception:
            pass
        if processed == 0 and not stopping:
            time.sleep(interval_seconds)
