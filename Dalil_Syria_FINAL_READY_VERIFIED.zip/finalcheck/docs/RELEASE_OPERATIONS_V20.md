# V20 Operations

The project is now prepared for the external distribution stage. The remaining environment-dependent actions are:

1. Run Android build in a machine/CI runner with Android SDK and Gradle.
2. Create or load the permanent release keystore through protected CI secrets.
3. Produce signed APK.
4. Verify signature and checksum.
5. Host APK and download page on a real HTTPS domain.
6. Test installation and upgrade on real Android devices.
