from pathlib import Path


def test_worker_module_exists_and_has_both_pipelines():
    text = Path('backend/app/worker.py').read_text()
    assert 'process_outbox_once' in text
    assert 'process_notifications_once' in text
    assert 'run_forever' in text


def test_worker_uses_claim_and_ack_retry_paths():
    text = Path('backend/app/worker.py').read_text()
    assert 'claim_batch' in text
    assert 'mark_published' in text
    assert 'mark_failed' in text
    assert 'claim_notifications' in text
    assert 'mark_notification_sent' in text
    assert 'mark_notification_failed' in text


def test_v014_migration_exists():
    text = Path('database/012_v014_workers_notifications.sql').read_text()
    assert 'notification_preferences' in text
    assert 'idx_notification_processing_recovery' in text
    assert 'idx_outbox_processing_recovery' in text
