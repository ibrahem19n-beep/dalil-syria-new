def duplicate_score(name_a: str, phone_a: str | None, name_b: str, phone_b: str | None) -> int:
    score = 0
    if phone_a and phone_b and phone_a.strip() == phone_b.strip():
        score += 70
    if name_a.strip().casefold() == name_b.strip().casefold():
        score += 30
    return score
