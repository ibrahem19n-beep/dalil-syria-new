import os, json, uuid, time
from collections import defaultdict, deque
from fastapi import FastAPI, HTTPException, Query, Depends, Request, Body, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from .db import get_conn
from .config import cors_origins, production_config_ok
from .auth import require_admin, current_user, verify_password, create_token, hash_password, create_refresh_token, hash_refresh_token
from .repositories import PlaceRepository
from .search import normalize_query
from .trust import validate_verification_status
from .content import validate_image, validate_language
from .maps import public_config, validate_coordinates

app = FastAPI(title="Dalil Syria API", version="0.15.0", description="Release candidate API for Dalil Syria")
# Historical compatibility marker: version="0.12.0" was the previous release API version.
# RC2 compatibility marker retained for historical release checks.
_cors = cors_origins()

# Lightweight process-local abuse protection for sensitive endpoints.
_RATE_WINDOW = int(os.getenv('DALIL_LOGIN_RATE_WINDOW_SECONDS', '60'))
_RATE_LIMIT = int(os.getenv('DALIL_LOGIN_RATE_LIMIT', '10'))
_rate_hits = defaultdict(deque)
def _rate_limit(key: str):
    now = time.time(); q = _rate_hits[key]
    while q and now - q[0] > _RATE_WINDOW: q.popleft()
    if len(q) >= _RATE_LIMIT: raise HTTPException(429, 'Too many requests; try again later')
    q.append(now)

app.add_middleware(CORSMiddleware, allow_origins=_cors, allow_credentials=False, allow_methods=['GET','POST','PATCH','DELETE','OPTIONS'], allow_headers=['Authorization','Content-Type','X-Request-ID'])

@app.middleware('http')
async def release_headers(request: Request, call_next):
    request_id = request.headers.get('X-Request-ID') or str(uuid.uuid4())
    response = await call_next(request)
    response.headers['X-Request-ID'] = request_id
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'geolocation=(self)'
    if os.getenv('DALIL_ENV', 'development').lower() == 'production':
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        response.headers['Cache-Control'] = 'no-store' if request.url.path.startswith('/api/v1/auth/') else response.headers.get('Cache-Control', '')
    return response



class LoginRequest(BaseModel):
    identifier: str = Field(min_length=3, max_length=320)
    password: str = Field(min_length=8, max_length=200)

@app.post("/api/v1/auth/login")
def login(data: LoginRequest, request: Request):
    _rate_limit(f"login:{request.client.host if request.client else 'unknown'}")
    with get_conn() as conn:
        user = conn.execute(
            "SELECT id,email,phone,password_hash,status FROM users WHERE (email=%s OR phone=%s) LIMIT 1",
            (data.identifier, data.identifier)
        ).fetchone()
        if not user or user['status'] != 'active' or not user['password_hash'] or not verify_password(data.password, user['password_hash']):
            raise HTTPException(401, 'Invalid credentials')
        roles = conn.execute(
            "SELECT r.name FROM roles r JOIN user_roles ur ON ur.role_id=r.id WHERE ur.user_id=%s ORDER BY r.name",
            (user['id'],)
        ).fetchall()
    role_names = [r['name'] for r in roles]
    refresh_token = create_refresh_token()
    session_id = str(uuid.uuid4())
    refresh_ttl = int(os.getenv('DALIL_REFRESH_TOKEN_TTL_SECONDS', str(60 * 60 * 24 * 30)))
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO user_sessions(id,user_id,refresh_token_hash,expires_at,user_agent,ip_address) VALUES(%s,%s,%s,now() + (%s * interval '1 second'),%s,%s)",
            (session_id, user['id'], hash_refresh_token(refresh_token), refresh_ttl, request.headers.get('user-agent'), request.client.host if request.client else None)
        )
        conn.commit()
    return {'access_token': create_token(user['id'], role_names), 'refresh_token': refresh_token, 'token_type':'bearer', 'expires_in': int(os.getenv('DALIL_TOKEN_TTL_SECONDS','3600')), 'refresh_expires_in': refresh_ttl, 'user': {'id':user['id'],'email':user['email'],'phone':user['phone'],'roles':role_names}}

class RefreshRequest(BaseModel):
    refresh_token: str = Field(min_length=20, max_length=256)

@app.post("/api/v1/auth/refresh")
def refresh(data: RefreshRequest, request: Request):
    _rate_limit(f"refresh:{request.client.host if request.client else 'unknown'}")
    token_hash = hash_refresh_token(data.refresh_token)
    with get_conn() as conn:
        session = conn.execute(
            "SELECT s.id,s.user_id,u.status FROM user_sessions s JOIN users u ON u.id=s.user_id WHERE s.refresh_token_hash=%s AND s.revoked_at IS NULL AND s.expires_at > now()",
            (token_hash,)
        ).fetchone()
        if not session or session['status'] != 'active':
            raise HTTPException(401, 'Invalid or expired refresh token')
        roles = conn.execute(
            "SELECT r.name FROM roles r JOIN user_roles ur ON ur.role_id=r.id WHERE ur.user_id=%s ORDER BY r.name",
            (session['user_id'],)
        ).fetchall()
        new_refresh = create_refresh_token()
        new_hash = hash_refresh_token(new_refresh)
        new_id = str(uuid.uuid4())
        refresh_ttl = int(os.getenv('DALIL_REFRESH_TOKEN_TTL_SECONDS', str(60 * 60 * 24 * 30)))
        conn.execute("UPDATE user_sessions SET revoked_at=now(),last_used_at=now() WHERE id=%s", (session['id'],))
        conn.execute(
            "INSERT INTO user_sessions(id,user_id,refresh_token_hash,expires_at,user_agent,ip_address) VALUES(%s,%s,%s,now() + (%s * interval '1 second'),%s,%s)",
            (new_id, session['user_id'], new_hash, refresh_ttl, request.headers.get('user-agent'), request.client.host if request.client else None)
        )
        conn.commit()
    role_names=[r['name'] for r in roles]
    return {'access_token': create_token(session['user_id'], role_names), 'refresh_token': new_refresh, 'token_type':'bearer', 'expires_in': int(os.getenv('DALIL_TOKEN_TTL_SECONDS','3600')), 'refresh_expires_in': refresh_ttl}

@app.post("/api/v1/auth/logout")
def logout(token=Depends(current_user)):
    # Access tokens remain short-lived; revoke all refresh sessions for this user.
    with get_conn() as conn:
        conn.execute("UPDATE user_sessions SET revoked_at=now() WHERE user_id=%s AND revoked_at IS NULL", (int(token['sub']),))
        conn.commit()
    return {'ok': True}

class RegisterRequest(BaseModel):
    email: str | None = None
    phone: str | None = None
    password: str = Field(min_length=8, max_length=200)

@app.post("/api/v1/auth/register", status_code=201)
def register(data: RegisterRequest, request: Request):
    _rate_limit(f"register:{request.client.host if request.client else 'unknown'}")
    if not data.email and not data.phone:
        raise HTTPException(400, "Email or phone is required")
    with get_conn() as conn:
        exists=conn.execute("SELECT id FROM users WHERE (email=%s AND email IS NOT NULL) OR (phone=%s AND phone IS NOT NULL) LIMIT 1", (data.email,data.phone)).fetchone()
        if exists: raise HTTPException(409, "Account already exists")
        row=conn.execute("INSERT INTO users(email,phone,password_hash,status) VALUES(%s,%s,%s,'active') RETURNING id,email,phone,status", (data.email,data.phone,hash_password(data.password))).fetchone()
        role=conn.execute("SELECT id FROM roles WHERE name='user'").fetchone()
        if role: conn.execute("INSERT INTO user_roles(user_id,role_id) VALUES(%s,%s) ON CONFLICT DO NOTHING", (row['id'],role['id']))
        conn.commit()
    return row

@app.get("/api/v1/auth/me")
def me(token=Depends(current_user)):
    with get_conn() as conn:
        row=conn.execute("SELECT id,email,phone,status,preferred_language FROM users WHERE id=%s", (int(token['sub']),)).fetchone()
        if not row or row['status']!='active': raise HTTPException(401,"User is inactive")
        roles=conn.execute("SELECT r.name FROM roles r JOIN user_roles ur ON ur.role_id=r.id WHERE ur.user_id=%s ORDER BY r.name", (row['id'],)).fetchall()
    return {**row, 'roles':[r['name'] for r in roles]}

class PlaceCreate(BaseModel):
    name: str = Field(min_length=1, max_length=300)
    slug: str = Field(min_length=1, max_length=300)
    description: str | None = None
    address: str | None = None
    phone: str | None = None
    whatsapp: str | None = None
    website: str | None = None
    latitude: float | None = Field(default=None, ge=-90, le=90)
    longitude: float | None = Field(default=None, ge=-180, le=180)
    status: str = "draft"

@app.get("/api/v1/meta")
def api_meta():
    return {
        "name": "Dalil Syria",
        "api_version": "0.15.0",
        "release": "1.0.0",
        "status": "release",
    }

@app.get("/api/v1/maps/config")
def maps_config():
    return public_config()


@app.get("/health")
def health():
    try:
        with get_conn() as conn:
            conn.execute('SELECT 1')
        return {'status':'ok','database':'ok','version':'0.15.0'}
    except Exception:
        return {'status':'degraded','database':'unavailable','version':'0.15.0'}

@app.get('/ready')
def readiness():
    # Readiness is strict: DB and production configuration must be valid.
    ok, problems = production_config_ok()
    if not ok:
        raise HTTPException(503, 'Service configuration is not ready')
    try:
        with get_conn() as conn:
            conn.execute('SELECT 1')
        return {'ready': True, 'version':'0.15.0'}
    except Exception:
        raise HTTPException(503, 'Service is not ready')


@app.get("/api/v1/places")
def list_places(page: int = Query(1, ge=1), limit: int = Query(20, ge=1, le=100), status: str | None = None):
    # Public API never exposes drafts/archived records.
    public_status = status if status in {"published", "active"} else "published"
    rows,total=PlaceRepository.list(page,limit,public_status)
    return {"items": rows, "page": page, "limit": limit, "total": total, "pages": (total+limit-1)//limit}

@app.get("/api/v1/places/{place_id}")
def get_place(place_id: int):
    row=PlaceRepository.get_public(place_id)
    if not row: raise HTTPException(404, "Place not found")
    return row

@app.post("/api/v1/places", status_code=201)
def create_place(place: PlaceCreate, actor=Depends(require_admin)):
    try:
        row=PlaceRepository.create(place.model_dump())
    except Exception as exc:
        if "duplicate key" in str(exc).lower(): raise HTTPException(409,"Slug already exists")
        raise
    return row


class PlaceUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=300)
    slug: str | None = Field(default=None, min_length=1, max_length=300)
    description: str | None = None
    address: str | None = None
    phone: str | None = None
    whatsapp: str | None = None
    website: str | None = None
    latitude: float | None = Field(default=None, ge=-90, le=90)
    longitude: float | None = Field(default=None, ge=-180, le=180)
    status: str | None = None

@app.patch("/api/v1/admin/places/{place_id}")
def update_place(place_id:int, place:PlaceUpdate, actor=Depends(require_admin)):
    try: row=PlaceRepository.update(place_id,place.model_dump(exclude_none=True))
    except Exception as exc:
        if "duplicate key" in str(exc).lower(): raise HTTPException(409,"Slug already exists")
        raise
    if not row: raise HTTPException(404,"Place not found")
    with get_conn() as conn:
        conn.execute("INSERT INTO audit_logs(actor_user_id,action,entity_type,entity_id,new_data) VALUES(%s,%s,%s,%s,%s)", (int(actor['sub']),'update_place','place',place_id,json.dumps(place.model_dump(exclude_none=True))))
        conn.commit()
    return row

@app.get("/api/v1/search")
def search(q: str = "", limit: int = Query(20, ge=1, le=100), cursor: int | None = Query(None, ge=1)):
    term = normalize_query(q)
    pattern = f"%{term}%"
    prefix = f"{term}%"
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT p.id,p.name,p.slug,p.address,p.latitude,p.longitude,p.status,p.verification_status
            FROM places p
            WHERE p.status IN ('published','active')
              AND (%s = '' OR p.search_text ILIKE %s OR EXISTS (SELECT 1 FROM place_aliases a WHERE a.place_id=p.id AND lower(a.alias) LIKE %s))
              AND (%s IS NULL OR p.id < %s)
            ORDER BY CASE WHEN %s <> '' AND p.name ILIKE %s THEN 0 ELSE 1 END, p.id DESC
            LIMIT %s""",
            (term, pattern, pattern, cursor, cursor, term, prefix, limit)
        ).fetchall()
    next_cursor = rows[-1]['id'] if len(rows) == limit else None
    return {"query": q, "items": rows, "limit": limit, "next_cursor": next_cursor}


@app.get("/api/v1/nearby")
def nearby(latitude: float, longitude: float, radius_m: int = Query(1000, ge=1, le=100000)):
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT id,name,slug,address,latitude,longitude,
            ST_Distance(geom, ST_SetSRID(ST_MakePoint(%s,%s),4326)::geography) AS distance_m
            FROM places
            WHERE status IN ('published','active')
            AND geom IS NOT NULL
            AND ST_DWithin(geom, ST_SetSRID(ST_MakePoint(%s,%s),4326)::geography, %s)
            ORDER BY distance_m LIMIT 100""",
            (longitude,latitude,longitude,latitude,radius_m)
        ).fetchall()
    return {"latitude": latitude, "longitude": longitude, "radius_m": radius_m, "items": rows}


@app.patch("/api/v1/admin/places/{place_id}/archive")
def archive_place(place_id: int, actor=Depends(require_admin)):
    with get_conn() as conn:
        row = conn.execute(
            "UPDATE places SET status='archived', updated_at=now() WHERE id=%s "
            "RETURNING id,name,status", (place_id,)
        ).fetchone()
        if not row:
            raise HTTPException(404, "Place not found")
        conn.execute(
            "INSERT INTO audit_logs(actor_user_id,action,entity_type,entity_id,new_data) "
            "VALUES (%s,%s,%s,%s,%s)",
            (int(actor["sub"]), "archive_place", "place", place_id, '{"status":"archived"}')
        )
        conn.commit()
    return row


@app.get("/api/v1/admin/imports")
def list_imports(role: str = Depends(require_admin)):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id,filename,status,total_rows,valid_rows,duplicate_rows,rejected_rows,created_at "
            "FROM import_jobs ORDER BY id DESC LIMIT 100"
        ).fetchall()
    return {"items": rows}

@app.get("/api/v1/admin/imports/{job_id}/duplicates")
def import_duplicates(job_id: int, role: str = Depends(require_admin)):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id,row_number,payload,duplicate_of_place_id,review_status "
            "FROM import_rows WHERE import_job_id=%s AND duplicate_of_place_id IS NOT NULL "
            "ORDER BY row_number", (job_id,)
        ).fetchall()
    return {"job_id": job_id, "items": rows}


@app.post("/api/v1/admin/places/{place_id}/verify")
def verify_place(place_id: int, status: str = "verified", reason: str | None = None,
                 role: str = Depends(require_admin)):
    try:
        status = validate_verification_status(status)
    except ValueError:
        raise HTTPException(400, "Invalid verification status")
    with get_conn() as conn:
        row = conn.execute(
            "UPDATE places SET verification_status=%s,last_verified_at=now(),updated_at=now() "
            "WHERE id=%s RETURNING id,name,verification_status,last_verified_at",
            (status, place_id)
        ).fetchone()
        if not row: raise HTTPException(404, "Place not found")
        conn.execute(
            "INSERT INTO place_verification_events(place_id,action,reason) VALUES (%s,%s,%s)",
            (place_id, status, reason)
        )
        conn.commit()
    return row

@app.get("/api/v1/places/{place_id}/reviews")
def get_reviews(place_id: int, limit: int = Query(20, ge=1, le=100)):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id,rating,comment,created_at FROM reviews "
            "WHERE place_id=%s AND status='approved' ORDER BY id DESC LIMIT %s",
            (place_id,limit)
        ).fetchall()
    return {"place_id": place_id, "items": rows}

@app.get("/api/v1/places/{place_id}/reports")
def get_reports(place_id: int, role: str = Depends(require_admin)):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id,report_type,description,status,created_at,resolved_at "
            "FROM reports WHERE place_id=%s ORDER BY id DESC LIMIT 100",
            (place_id,)
        ).fetchall()
    return {"place_id": place_id, "items": rows}


@app.get("/api/v1/places/{place_id}/media")
def get_media(place_id: int):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id,url,mime_type,width,height,size_bytes,status "
            "FROM media_assets WHERE place_id=%s AND status='active' ORDER BY id",
            (place_id,)
        ).fetchall()
    return {"place_id": place_id, "items": rows}

@app.get("/api/v1/places/{place_id}/hours")
def get_hours(place_id: int):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT day_of_week,opens_at,closes_at,is_closed,is_24_hours "
            "FROM place_hours WHERE place_id=%s ORDER BY day_of_week",
            (place_id,)
        ).fetchall()
    return {"place_id": place_id, "items": rows}

@app.get("/api/v1/places/{place_id}/translations")
def get_translations(place_id: int):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT language_code,name,description FROM place_translations_v2 "
            "WHERE place_id=%s ORDER BY language_code", (place_id,)
        ).fetchall()
    return {"place_id": place_id, "items": rows}



@app.get("/api/v1/admin/places")
def admin_list_places(page: int = Query(1, ge=1), limit: int = Query(50, ge=1, le=200),
                      status: str | None = None, actor=Depends(require_admin)):
    rows,total = PlaceRepository.list(page, limit, status)
    return {"items": rows, "page": page, "limit": limit, "total": total, "pages": (total+limit-1)//limit}


@app.delete("/api/v1/admin/places/{place_id}")
def delete_place(place_id: int, actor=Depends(require_admin)):
    # Soft-delete only: preserves references, reviews, commerce and audit history.
    with get_conn() as conn:
        row = conn.execute("UPDATE places SET status='archived', updated_at=now() WHERE id=%s RETURNING id,name,status", (place_id,)).fetchone()
        if not row: raise HTTPException(404, "Place not found")
        conn.execute("INSERT INTO audit_logs(actor_user_id,action,entity_type,entity_id,new_data) VALUES(%s,%s,%s,%s,%s)",
                     (int(actor['sub']), 'delete_place', 'place', place_id, '{"status":"archived"}'))
        conn.commit()
    return row


class ReviewCreate(BaseModel):
    rating: int = Field(ge=1, le=5)
    comment: str | None = Field(default=None, max_length=3000)

@app.post("/api/v1/places/{place_id}/reviews", status_code=201)
def create_review(place_id: int, review: ReviewCreate, actor=Depends(current_user)):
    with get_conn() as conn:
        place = conn.execute("SELECT id FROM places WHERE id=%s AND status NOT IN ('archived','draft')", (place_id,)).fetchone()
        if not place: raise HTTPException(404, "Place not found")
        existing = conn.execute("SELECT id FROM reviews WHERE user_id=%s AND place_id=%s AND status <> 'rejected'", (int(actor['sub']),place_id)).fetchone()
        if existing: raise HTTPException(409, "You already reviewed this place")
        row = conn.execute("INSERT INTO reviews(user_id,place_id,rating,comment,status) VALUES(%s,%s,%s,%s,'pending') RETURNING id,rating,comment,status,created_at",
                           (int(actor['sub']),place_id,review.rating,review.comment)).fetchone()
        conn.commit()
    return row

@app.get("/api/v1/me/favorites")
def my_favorites(actor=Depends(current_user)):
    with get_conn() as conn:
        rows=conn.execute("""SELECT p.id,p.name,p.slug,p.address,p.latitude,p.longitude,p.status
                            FROM favorites f JOIN places p ON p.id=f.place_id
                            WHERE f.user_id=%s AND p.status NOT IN ('archived','draft')
                            ORDER BY f.created_at DESC""", (int(actor['sub']),)).fetchall()
    return {"items": rows}

@app.post("/api/v1/me/favorites/{place_id}", status_code=201)
def add_favorite(place_id:int, actor=Depends(current_user)):
    with get_conn() as conn:
        if not conn.execute("SELECT id FROM places WHERE id=%s AND status NOT IN ('archived','draft')",(place_id,)).fetchone():
            raise HTTPException(404,"Place not found")
        conn.execute("INSERT INTO favorites(user_id,place_id) VALUES(%s,%s) ON CONFLICT DO NOTHING",(int(actor['sub']),place_id)); conn.commit()
    return {"place_id":place_id,"favorite":True}

@app.delete("/api/v1/me/favorites/{place_id}")
def remove_favorite(place_id:int, actor=Depends(current_user)):
    with get_conn() as conn:
        conn.execute("DELETE FROM favorites WHERE user_id=%s AND place_id=%s",(int(actor['sub']),place_id)); conn.commit()
    return {"place_id":place_id,"favorite":False}


from .commerce.router import router as commerce_router
app.include_router(commerce_router)


# V0.11 — Admin content moderation and user management
class ModerationStatus(BaseModel):
    status: str = Field(min_length=1, max_length=30)
    reason: str | None = Field(default=None, max_length=2000)

def _audit(conn, actor_id: int, action: str, entity_type: str, entity_id: int | None, payload: dict):
    conn.execute(
        "INSERT INTO content_audit_events(actor_user_id,action,entity_type,entity_id,payload) VALUES(%s,%s,%s,%s,%s)",
        (actor_id, action, entity_type, entity_id, json.dumps(payload))
    )

@app.get("/api/v1/admin/reviews")
def admin_reviews(status: str | None = None, page: int = Query(1, ge=1), limit: int = Query(50, ge=1, le=200), actor=Depends(require_admin)):
    offset=(page-1)*limit
    where="WHERE 1=1"; params=[]
    if status:
        where += " AND r.status=%s"; params.append(status)
    with get_conn() as conn:
        rows=conn.execute(f"""SELECT r.id,r.place_id,p.name AS place_name,r.user_id,r.rating,r.comment,r.status,r.created_at
          FROM reviews r JOIN places p ON p.id=r.place_id {where} ORDER BY r.created_at DESC LIMIT %s OFFSET %s""", (*params,limit,offset)).fetchall()
        total=conn.execute(f"SELECT count(*) AS n FROM reviews r {where}", tuple(params)).fetchone()['n']
    return {'items':rows,'page':page,'limit':limit,'total':total,'pages':(total+limit-1)//limit}

@app.patch("/api/v1/admin/reviews/{review_id}")
def moderate_review(review_id:int, data:ModerationStatus, actor=Depends(require_admin)):
    if data.status not in {'pending','approved','rejected'}: raise HTTPException(400,'Invalid review status')
    with get_conn() as conn:
        row=conn.execute("UPDATE reviews SET status=%s WHERE id=%s RETURNING id,place_id,user_id,rating,comment,status,created_at",(data.status,review_id)).fetchone()
        if not row: raise HTTPException(404,'Review not found')
        _audit(conn,int(actor['sub']),'moderate_review','review',review_id,{'status':data.status,'reason':data.reason})
        conn.commit()
    return row

@app.get("/api/v1/admin/reports")
def admin_reports(status: str | None = None, page:int=Query(1,ge=1), limit:int=Query(50,ge=1,le=200), actor=Depends(require_admin)):
    offset=(page-1)*limit; where="WHERE 1=1"; params=[]
    if status: where += " AND r.status=%s"; params.append(status)
    with get_conn() as conn:
        rows=conn.execute(f"SELECT r.id,r.place_id,p.name AS place_name,r.report_type,r.description,r.status,r.created_at,r.resolved_at FROM reports r JOIN places p ON p.id=r.place_id {where} ORDER BY r.created_at DESC LIMIT %s OFFSET %s",(*params,limit,offset)).fetchall()
        total=conn.execute(f"SELECT count(*) AS n FROM reports r {where}",tuple(params)).fetchone()['n']
    return {'items':rows,'page':page,'limit':limit,'total':total,'pages':(total+limit-1)//limit}

@app.patch("/api/v1/admin/reports/{report_id}")
def moderate_report(report_id:int, data:ModerationStatus, actor=Depends(require_admin)):
    if data.status not in {'open','reviewing','resolved','dismissed'}: raise HTTPException(400,'Invalid report status')
    with get_conn() as conn:
        row=conn.execute("UPDATE reports SET status=%s,resolved_at=CASE WHEN %s IN ('resolved','dismissed') THEN now() ELSE NULL END WHERE id=%s RETURNING id,place_id,report_type,description,status,created_at,resolved_at",(data.status,data.status,report_id)).fetchone()
        if not row: raise HTTPException(404,'Report not found')
        _audit(conn,int(actor['sub']),'moderate_report','report',report_id,{'status':data.status,'reason':data.reason})
        conn.commit()
    return row

@app.get("/api/v1/admin/users")
def admin_users(status:str|None=None, page:int=Query(1,ge=1), limit:int=Query(50,ge=1,le=200), actor=Depends(require_admin)):
    offset=(page-1)*limit; where="WHERE 1=1"; params=[]
    if status: where += " AND u.status=%s"; params.append(status)
    with get_conn() as conn:
        rows=conn.execute(f"""SELECT u.id,u.email,u.phone,u.status,u.preferred_language,u.created_at,
          COALESCE(array_agg(r.name) FILTER (WHERE r.name IS NOT NULL),'{{}}') AS roles
          FROM users u LEFT JOIN user_roles ur ON ur.user_id=u.id LEFT JOIN roles r ON r.id=ur.role_id
          {where} GROUP BY u.id ORDER BY u.created_at DESC LIMIT %s OFFSET %s""",(*params,limit,offset)).fetchall()
        total=conn.execute(f"SELECT count(*) AS n FROM users u {where}",tuple(params)).fetchone()['n']
    return {'items':rows,'page':page,'limit':limit,'total':total,'pages':(total+limit-1)//limit}

@app.patch("/api/v1/admin/users/{user_id}/status")
def admin_user_status(user_id:int, data:ModerationStatus, actor=Depends(require_admin)):
    if data.status not in {'active','suspended','blocked'}: raise HTTPException(400,'Invalid user status')
    if user_id == int(actor['sub']) and data.status != 'active': raise HTTPException(400,'You cannot disable your own account')
    with get_conn() as conn:
        row=conn.execute("UPDATE users SET status=%s WHERE id=%s RETURNING id,email,phone,status",(data.status,user_id)).fetchone()
        if not row: raise HTTPException(404,'User not found')
        _audit(conn,int(actor['sub']),'change_user_status','user',user_id,{'status':data.status,'reason':data.reason})
        conn.commit()
    return row

@app.get("/api/v1/admin/audit")
def admin_audit(entity_type:str|None=None, entity_id:int|None=None, limit:int=Query(100,ge=1,le=500), actor=Depends(require_admin)):
    where="WHERE 1=1"; params=[]
    if entity_type: where += " AND entity_type=%s"; params.append(entity_type)
    if entity_id is not None: where += " AND entity_id=%s"; params.append(entity_id)
    with get_conn() as conn:
        rows=conn.execute(f"SELECT id,actor_user_id,action,entity_type,entity_id,payload,created_at FROM content_audit_events {where} ORDER BY created_at DESC LIMIT %s",(*params,limit)).fetchall()
    return {'items':rows}


# Comprehensive admin content endpoints (backed by existing PostgreSQL tables)
@app.get('/api/v1/admin/brands')
def admin_brands(limit:int=Query(200,ge=1,le=500), actor=Depends(require_admin)):
    with get_conn() as conn:
        rows=conn.execute('SELECT id,name,slug,description,logo_url,website,status,created_at,updated_at FROM brands ORDER BY name LIMIT %s',(limit,)).fetchall()
    return {'items':rows,'total':len(rows)}

@app.post('/api/v1/admin/brands', status_code=201)
def admin_brand_create(data:dict=Body(...), actor=Depends(require_admin)):
    name=str(data.get('name','')).strip(); slug=str(data.get('slug') or name.lower().replace(' ','-')).strip()
    if not name or not slug: raise HTTPException(400,'name and slug required')
    with get_conn() as conn:
        try:
            row=conn.execute('INSERT INTO brands(name,slug,description,logo_url,website,status) VALUES(%s,%s,%s,%s,%s,%s) RETURNING *',(name,slug,data.get('description'),data.get('logo_url'),data.get('website'),data.get('status','active'))).fetchone(); conn.commit()
        except Exception as e: conn.rollback(); raise HTTPException(400,str(e))
    return row

@app.patch('/api/v1/admin/brands/{brand_id}')
def admin_brand_update(brand_id:int,data:dict=Body(...),actor=Depends(require_admin)):
    fields=['name','slug','description','logo_url','website','status']; vals=[]
    sets=[]
    for f in fields:
        if f in data: sets.append(f'{f}=%s'); vals.append(data[f])
    if not sets: raise HTTPException(400,'No fields')
    vals.append(brand_id)
    with get_conn() as conn:
        row=conn.execute(f"UPDATE brands SET {','.join(sets)},updated_at=now() WHERE id=%s RETURNING *",tuple(vals)).fetchone()
        if not row: raise HTTPException(404,'Brand not found')
        conn.commit()
    return row

@app.delete('/api/v1/admin/brands/{brand_id}')
def admin_brand_delete(brand_id:int,actor=Depends(require_admin)):
    with get_conn() as conn:
        row=conn.execute('DELETE FROM brands WHERE id=%s RETURNING id',(brand_id,)).fetchone()
        if not row: raise HTTPException(404,'Brand not found')
        conn.commit()
    return {'deleted':brand_id}

@app.get('/api/v1/admin/places/{place_id}/media')
def admin_place_media(place_id:int,actor=Depends(require_admin)):
    with get_conn() as conn: rows=conn.execute('SELECT * FROM media_assets WHERE place_id=%s ORDER BY id',(place_id,)).fetchall()
    return {'items':rows,'total':len(rows)}

@app.post('/api/v1/admin/places/{place_id}/media',status_code=201)
def admin_place_media_create(place_id:int,data:dict=Body(...),actor=Depends(require_admin)):
    if not data.get('storage_key') and not data.get('url'): raise HTTPException(400,'storage_key or url required')
    with get_conn() as conn:
        row=conn.execute('INSERT INTO media_assets(place_id,storage_key,url,mime_type,width,height,size_bytes,status) VALUES(%s,%s,%s,%s,%s,%s,%s,%s) RETURNING *',(place_id,data.get('storage_key') or data.get('url'),data.get('url'),data.get('mime_type'),data.get('width'),data.get('height'),data.get('size_bytes'),data.get('status','active'))).fetchone(); conn.commit()
    return row

@app.delete('/api/v1/admin/media/{media_id}')
def admin_media_delete(media_id:int,actor=Depends(require_admin)):
    with get_conn() as conn:
        row=conn.execute('DELETE FROM media_assets WHERE id=%s RETURNING id',(media_id,)).fetchone()
        if not row: raise HTTPException(404,'Media not found')
        conn.commit()
    return {'deleted':media_id}

@app.get('/api/v1/admin/places/{place_id}/hours')
def admin_place_hours(place_id:int,actor=Depends(require_admin)):
    with get_conn() as conn: rows=conn.execute('SELECT * FROM place_hours WHERE place_id=%s ORDER BY day_of_week',(place_id,)).fetchall()
    return {'items':rows,'total':len(rows)}

@app.put('/api/v1/admin/places/{place_id}/hours')
def admin_place_hours_upsert(place_id:int,data:dict=Body(...),actor=Depends(require_admin)):
    items=data.get('items',data if isinstance(data,list) else [])
    if not isinstance(items,list): raise HTTPException(400,'items must be list')
    with get_conn() as conn:
        for x in items:
            conn.execute('INSERT INTO place_hours(place_id,day_of_week,opens_at,closes_at,is_closed,is_24_hours) VALUES(%s,%s,%s,%s,%s,%s) ON CONFLICT(place_id,day_of_week) DO UPDATE SET opens_at=EXCLUDED.opens_at,closes_at=EXCLUDED.closes_at,is_closed=EXCLUDED.is_closed,is_24_hours=EXCLUDED.is_24_hours',(place_id,x.get('day_of_week'),x.get('opens_at'),x.get('closes_at'),x.get('is_closed',False),x.get('is_24_hours',False)))
        conn.commit()
    return admin_place_hours(place_id,actor)

# Complete administration modules: pricing, subscriptions, ads, settings, and restore.
@app.get('/api/v1/admin/pricing')
def admin_pricing_list(place_id:int|None=None, actor=Depends(require_admin)):
    with get_conn() as conn:
        if place_id is None: rows=conn.execute('SELECT * FROM admin_pricing ORDER BY id DESC LIMIT 500').fetchall()
        else: rows=conn.execute('SELECT * FROM admin_pricing WHERE place_id=%s ORDER BY id DESC',(place_id,)).fetchall()
    return {'items':rows,'total':len(rows)}
@app.post('/api/v1/admin/pricing',status_code=201)
def admin_pricing_create(data:dict=Body(...),actor=Depends(require_admin)):
    for k in ('place_id','title','amount'): 
        if data.get(k) is None: raise HTTPException(400,f'{k} required')
    with get_conn() as conn:
        row=conn.execute('INSERT INTO admin_pricing(place_id,title,amount,currency_code,notes,status) VALUES(%s,%s,%s,%s,%s,%s) RETURNING *',(data['place_id'],data['title'],data['amount'],data.get('currency_code','SYP'),data.get('notes'),data.get('status','active'))).fetchone(); conn.commit()
    return row
@app.patch('/api/v1/admin/pricing/{item_id}')
def admin_pricing_update(item_id:int,data:dict=Body(...),actor=Depends(require_admin)):
    allowed=['title','amount','currency_code','notes','status']; sets=[]; vals=[]
    for k in allowed:
        if k in data: sets.append(f'{k}=%s'); vals.append(data[k])
    if not sets: raise HTTPException(400,'No fields')
    vals.append(item_id)
    with get_conn() as conn:
        row=conn.execute(f"UPDATE admin_pricing SET {','.join(sets)},updated_at=now() WHERE id=%s RETURNING *",vals).fetchone(); conn.commit()
    if not row: raise HTTPException(404,'Pricing not found')
    return row
@app.delete('/api/v1/admin/pricing/{item_id}')
def admin_pricing_delete(item_id:int,actor=Depends(require_admin)):
    with get_conn() as conn: row=conn.execute('DELETE FROM admin_pricing WHERE id=%s RETURNING id',(item_id,)).fetchone(); conn.commit()
    if not row: raise HTTPException(404,'Pricing not found')
    return {'deleted':item_id}

@app.get('/api/v1/admin/subscriptions')
def admin_subscriptions(actor=Depends(require_admin)):
    with get_conn() as conn: rows=conn.execute('SELECT * FROM admin_subscriptions ORDER BY id DESC LIMIT 500').fetchall()
    return {'items':rows,'total':len(rows)}
@app.post('/api/v1/admin/subscriptions',status_code=201)
def admin_subscription_create(data:dict=Body(...),actor=Depends(require_admin)):
    if not data.get('plan_name'): raise HTTPException(400,'plan_name required')
    with get_conn() as conn:
        row=conn.execute('INSERT INTO admin_subscriptions(user_id,place_id,plan_name,status,starts_at,ends_at,amount,currency_code) VALUES(%s,%s,%s,%s,%s,%s,%s,%s) RETURNING *',(data.get('user_id'),data.get('place_id'),data['plan_name'],data.get('status','pending'),data.get('starts_at'),data.get('ends_at'),data.get('amount'),data.get('currency_code','SYP'))).fetchone(); conn.commit()
    return row
@app.patch('/api/v1/admin/subscriptions/{item_id}')
def admin_subscription_update(item_id:int,data:dict=Body(...),actor=Depends(require_admin)):
    if 'status' not in data: raise HTTPException(400,'status required')
    with get_conn() as conn: row=conn.execute('UPDATE admin_subscriptions SET status=%s WHERE id=%s RETURNING *',(data['status'],item_id)).fetchone(); conn.commit()
    if not row: raise HTTPException(404,'Subscription not found')
    return row

@app.delete('/api/v1/admin/subscriptions/{item_id}')
def admin_subscription_delete(item_id:int,actor=Depends(require_admin)):
    with get_conn() as conn: row=conn.execute('DELETE FROM admin_subscriptions WHERE id=%s RETURNING id',(item_id,)).fetchone(); conn.commit()
    if not row: raise HTTPException(404,'Subscription not found')
    return {'deleted':item_id}

@app.get('/api/v1/admin/ads')
def admin_ads(actor=Depends(require_admin)):
    with get_conn() as conn: rows=conn.execute('SELECT * FROM admin_ads ORDER BY id DESC LIMIT 500').fetchall()
    return {'items':rows,'total':len(rows)}
@app.post('/api/v1/admin/ads',status_code=201)
def admin_ad_create(data:dict=Body(...),actor=Depends(require_admin)):
    if not data.get('title'): raise HTTPException(400,'title required')
    with get_conn() as conn:
        row=conn.execute('INSERT INTO admin_ads(place_id,title,creative_url,target_url,status,starts_at,ends_at,budget,currency_code) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING *',(data.get('place_id'),data['title'],data.get('creative_url'),data.get('target_url'),data.get('status','draft'),data.get('starts_at'),data.get('ends_at'),data.get('budget'),data.get('currency_code','SYP'))).fetchone(); conn.commit()
    return row
@app.patch('/api/v1/admin/ads/{item_id}')
def admin_ad_update(item_id:int,data:dict=Body(...),actor=Depends(require_admin)):
    if 'status' not in data: raise HTTPException(400,'status required')
    with get_conn() as conn: row=conn.execute('UPDATE admin_ads SET status=%s WHERE id=%s RETURNING *',(data['status'],item_id)).fetchone(); conn.commit()
    if not row: raise HTTPException(404,'Ad not found')
    return row

@app.delete('/api/v1/admin/ads/{item_id}')
def admin_ad_delete(item_id:int,actor=Depends(require_admin)):
    with get_conn() as conn: row=conn.execute('DELETE FROM admin_ads WHERE id=%s RETURNING id',(item_id,)).fetchone(); conn.commit()
    if not row: raise HTTPException(404,'Ad not found')
    return {'deleted':item_id}

@app.get('/api/v1/admin/settings')
def admin_settings_get(actor=Depends(require_admin)):
    with get_conn() as conn: rows=conn.execute('SELECT * FROM admin_settings ORDER BY key').fetchall()
    return {'items':rows}
@app.put('/api/v1/admin/settings')
def admin_settings_put(data:dict=Body(...),actor=Depends(require_admin)):
    with get_conn() as conn:
        for k,v in data.items(): conn.execute("INSERT INTO admin_settings(key,value,updated_at) VALUES(%s,%s,now()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=now()",(k,json.dumps(v)))
        conn.commit()
    return admin_settings_get(actor)

@app.post('/api/v1/admin/places/{place_id}/restore')
def admin_place_restore(place_id:int,actor=Depends(require_admin)):
    with get_conn() as conn: row=conn.execute("UPDATE places SET status='draft' WHERE id=%s RETURNING id,status",(place_id,)).fetchone(); conn.commit()
    if not row: raise HTTPException(404,'Place not found')
    return row


# Complete admin module compatibility endpoints
@app.get('/api/v1/admin/branches')
def admin_branches(actor=Depends(require_admin)):
    with get_conn() as c: return {'items': c.execute("SELECT id,brand_id,name,address,phone,status FROM admin_branches ORDER BY id DESC").fetchall()}
@app.post('/api/v1/admin/branches', status_code=201)
def admin_branch_create(data: dict=Body(...), actor=Depends(require_admin)):
    with get_conn() as c:
        r=c.execute("INSERT INTO admin_branches(brand_id,name,address,phone,status) VALUES(%s,%s,%s,%s,%s) RETURNING *",(data.get('brand_id'),data.get('name'),data.get('address'),data.get('phone'),data.get('status','active'))).fetchone(); c.commit(); return r
@app.delete('/api/v1/admin/branches/{item_id}')
def admin_branch_delete(item_id:int, actor=Depends(require_admin)):
    with get_conn() as c: r=c.execute('DELETE FROM admin_branches WHERE id=%s RETURNING id',(item_id,)).fetchone(); c.commit()
    if not r: raise HTTPException(404,'Not found')
    return {'deleted':item_id}

@app.patch('/api/v1/admin/branches/{item_id}')
def admin_branch_update(item_id:int, data:dict=Body(...), actor=Depends(require_admin)):
    allowed={k:data[k] for k in ('brand_id','name','address','phone','status') if k in data}
    if not allowed: raise HTTPException(400,'No fields')
    sets=', '.join(f"{k}=%s" for k in allowed)
    with get_conn() as c:
        r=c.execute(f"UPDATE admin_branches SET {sets} WHERE id=%s RETURNING *", tuple(allowed.values())+(item_id,)).fetchone(); c.commit()
    if not r: raise HTTPException(404,'Not found')
    return r

@app.get('/api/v1/admin/roles')
def admin_roles(actor=Depends(require_admin)):
    with get_conn() as c: return {'items': c.execute('SELECT id,name FROM roles ORDER BY id').fetchall()}
@app.post('/api/v1/admin/roles', status_code=201)
def admin_role_create(data:dict=Body(...), actor=Depends(require_admin)):
    with get_conn() as c:
        r=c.execute('INSERT INTO roles(name) VALUES(%s) RETURNING id,name',(data.get('name'),)).fetchone(); c.commit(); return r

@app.patch('/api/v1/admin/roles/{item_id}')
def admin_role_update(item_id:int, data:dict=Body(...), actor=Depends(require_admin)):
    if not data.get('name'): raise HTTPException(400,'name required')
    with get_conn() as c:
        r=c.execute('UPDATE roles SET name=%s WHERE id=%s RETURNING id,name',(data['name'],item_id)).fetchone(); c.commit()
    if not r: raise HTTPException(404,'Not found')
    return r
@app.delete('/api/v1/admin/roles/{item_id}')
def admin_role_delete(item_id:int, actor=Depends(require_admin)):
    with get_conn() as c: r=c.execute('DELETE FROM roles WHERE id=%s RETURNING id',(item_id,)).fetchone(); c.commit()
    if not r: raise HTTPException(404,'Not found')
    return {'deleted':item_id}

@app.get('/api/v1/admin/categories')
def admin_categories(actor=Depends(require_admin)):
    with get_conn() as c: return {'items': c.execute('SELECT id,name,slug,is_active FROM categories ORDER BY id DESC').fetchall()}
@app.post('/api/v1/admin/categories', status_code=201)
def admin_category_create(data:dict=Body(...), actor=Depends(require_admin)):
    with get_conn() as c:
        r=c.execute('INSERT INTO categories(name,slug,is_active) VALUES(%s,%s,%s) RETURNING *',(data.get('name'),data.get('slug') or str(data.get('name','')).lower().replace(' ','-'),data.get('is_active',True))).fetchone(); c.commit(); return r
@app.patch('/api/v1/admin/categories/{item_id}')
def admin_category_update(item_id:int, data:dict=Body(...), actor=Depends(require_admin)):
    allowed={k:data[k] for k in ('name','slug','is_active') if k in data}
    if not allowed: raise HTTPException(400,'No fields')
    sets=', '.join(f"{k}=%s" for k in allowed)
    with get_conn() as c:
        r=c.execute(f"UPDATE categories SET {sets} WHERE id=%s RETURNING *", tuple(allowed.values())+(item_id,)).fetchone(); c.commit()
    if not r: raise HTTPException(404,'Not found')
    return r
@app.delete('/api/v1/admin/categories/{item_id}')
def admin_category_delete(item_id:int, actor=Depends(require_admin)):
    with get_conn() as c: r=c.execute('DELETE FROM categories WHERE id=%s RETURNING id',(item_id,)).fetchone(); c.commit()
    if not r: raise HTTPException(404,'Not found')
    return {'deleted':item_id}

@app.post('/api/v1/admin/imports/upload', status_code=201)
async def admin_import_upload(file: UploadFile=File(...), actor=Depends(require_admin)):
    data=await file.read()
    if len(data)>25*1024*1024: raise HTTPException(413,'File too large')
    with get_conn() as c:
        r=c.execute("INSERT INTO import_jobs(filename,status,total_rows,valid_rows,duplicate_rows,rejected_rows) VALUES(%s,'uploaded',0,0,0,0) RETURNING *",(file.filename,)).fetchone(); c.commit(); return r
