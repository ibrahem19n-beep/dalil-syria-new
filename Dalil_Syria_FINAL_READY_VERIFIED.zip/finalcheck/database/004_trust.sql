CREATE TABLE IF NOT EXISTS place_verification_events (
 id BIGSERIAL PRIMARY KEY,
 place_id BIGINT NOT NULL REFERENCES places(id) ON DELETE CASCADE,
 actor_user_id BIGINT REFERENCES users(id),
 action TEXT NOT NULL,
 reason TEXT,
 created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_favorites (
 user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 place_id BIGINT NOT NULL REFERENCES places(id) ON DELETE CASCADE,
 created_at TIMESTAMPTZ DEFAULT now(),
 PRIMARY KEY(user_id, place_id)
);

CREATE INDEX IF NOT EXISTS idx_reviews_place_status ON reviews(place_id,status);
CREATE INDEX IF NOT EXISTS idx_reports_place_status ON reports(place_id,status);
CREATE INDEX IF NOT EXISTS idx_verification_place ON place_verification_events(place_id);
