import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MOBILE = ROOT / "mobile_app"
ICON_DIR = MOBILE / "assets" / "brand" / "icon"


def test_official_app_icon_assets_are_present():
    for name in (
        "dalil-syria-app-icon-master-1536.png",
        "dalil-syria-app-icon-512.png",
        "dalil-syria-app-icon-192.png",
        "dalil-syria-app-icon-180.png",
    ):
        assert (ICON_DIR / name).is_file()


def test_manifest_points_to_approved_external_icon():
    manifest = json.loads((MOBILE / "manifest.webmanifest").read_text(encoding="utf-8"))
    paths = {item["src"] for item in manifest["icons"]}
    assert "assets/brand/icon/dalil-syria-app-icon-192.png" in paths
    assert "assets/brand/icon/dalil-syria-app-icon-512.png" in paths
    assert all(item.get("purpose") == "any" for item in manifest["icons"])


def test_pwa_shell_and_service_worker_are_registered():
    index = (MOBILE / "index.html").read_text(encoding="utf-8")
    worker = (MOBILE / "sw.js").read_text(encoding="utf-8")
    assert 'serviceWorker.register("./sw.js")' in index
    assert "dalil-syria-shell-v2" in worker
    assert "./index.html" in worker
    assert "./app.js" in worker


def test_service_worker_does_not_cache_api_responses():
    worker = (MOBILE / "sw.js").read_text(encoding="utf-8")
    assert "url.pathname.startsWith('/api/')" in worker


def test_local_place_data_is_safe_and_has_no_known_closed_listing():
    data = json.loads((MOBILE / "data" / "places.json").read_text(encoding="utf-8"))
    assert len(data) >= 11
    ids = [item["id"] for item in data]
    assert len(ids) == len(set(ids))
    assert 3001 not in ids  # Central Pharmacy was verified as permanently closed.
    for item in data:
        assert item["name_ar"] and item["name_en"]
        assert -90 <= float(item["latitude"]) <= 90
        assert -180 <= float(item["longitude"]) <= 180
        assert item["last_verified"] == "2026-09-19"


def test_offline_location_and_destination_state_is_persisted():
    app = (MOBILE / "app.js").read_text(encoding="utf-8")
    assert "MAP_STATE_KEY='dalil_map_state_v2'" in app
    assert "localStorage.setItem(MAP_STATE_KEY" in app
    assert "navigator.geolocation.getCurrentPosition" in app
    assert "saveMapState({kind:'place'" in app
