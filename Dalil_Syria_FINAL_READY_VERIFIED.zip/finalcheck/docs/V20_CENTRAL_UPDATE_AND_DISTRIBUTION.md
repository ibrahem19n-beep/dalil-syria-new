# Dalil Syria V0.12 — V20 Central Update & APK Distribution

## Goal
Distribute a standalone Android APK outside Google Play while keeping content and most feature behavior centrally updateable through the backend.

## Update model
- Backend-controlled: places, branches, categories, translations, hours, media URLs, notices, feature flags, search configuration, and content.
- APK update required only for native Android changes, permissions, embedded runtime changes, security-critical client fixes, or major offline assets.
- App must fail gracefully if the backend is unavailable and must never execute untrusted downloaded code.

## Distribution model
1. Official HTTPS landing/download page.
2. Release APK served with immutable versioned filename.
3. SHA-256 checksum published for every release.
4. APK signed with one permanent release keystore.
5. Keystore backed up offline and never committed to Git.
6. Previous stable APK remains available for rollback.

## Security rules
- Never install APKs from unknown mirrors.
- Never rotate signing key casually; Android updates require the same signing identity.
- Do not put keystore, passwords, tokens, or private keys in repository files.
- Use HTTPS only.
- Keep release notes and checksum beside every APK.

## Release checklist
- Build release APK
- Sign with permanent keystore
- Verify signer certificate
- Verify APK checksum
- Install cleanly on Android test device
- Test upgrade over previous version
- Test backend unavailable behavior
- Publish versioned APK and checksum
- Update download page
- Keep rollback version
