# Dalil Syria V0.12 — V18

APK release build bridge completed.

Added:
- Separate release APK workflow.
- Android SDK/build-tools installation.
- Release artifact verification.
- Release APK artifact upload.
- Documentation for signing and publication.

Status:
- Debug build path exists.
- Release unsigned APK build path exists.
- Signing is intentionally the next controlled stage.
