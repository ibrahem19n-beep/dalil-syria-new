import os


def env(name: str, default: str | None = None) -> str | None:
    value = os.getenv(name, default)
    return value.strip() if isinstance(value, str) else value


def required(name: str) -> str:
    value = env(name)
    if not value:
        raise RuntimeError(f'{name} is required')
    return value


def cors_origins() -> list[str]:
    raw = env('DALIL_CORS_ORIGINS', 'http://localhost:8080') or ''
    return [x.strip() for x in raw.split(',') if x.strip()]


def production_config_ok() -> tuple[bool, list[str]]:
    problems = []
    for name in ('POSTGRES_PASSWORD', 'DALIL_AUTH_SECRET'):
        if not env(name):
            problems.append(f'{name} is required')
    if env('DALIL_ENV', 'development') == 'production':
        if len(env('DALIL_AUTH_SECRET', '') or '') < 32:
            problems.append('DALIL_AUTH_SECRET must be at least 32 characters in production')
        origins = cors_origins()
        if not origins or '*' in origins:
            problems.append('DALIL_CORS_ORIGINS must explicitly list allowed origins in production')
    return not problems, problems
