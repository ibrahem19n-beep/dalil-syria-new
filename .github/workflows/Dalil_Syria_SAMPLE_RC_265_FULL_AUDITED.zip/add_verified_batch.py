import json, hashlib, shutil, subprocess, os
from pathlib import Path
root=Path('/mnt/data/dalil_work/current')
p=root/'mobile_app/data/places.json'
rows=json.loads(p.read_text(encoding='utf-8'))
existing_names={x['name_ar'].strip().lower() for x in rows}
existing_coords={(round(float(x['latitude']),5),round(float(x['longitude']),5)) for x in rows}
new=[
(2161,'صيدلية الملقي','Al-Malqi Pharmacy','صيدليات','Pharmacies','المزة، دمشق','Al Mazzeh, Damascus','33.51115','36.26240','OpenStreetMap/Mapcarta','8G5RG766+FX'),
(2162,'صيدلية المساكن','Al-Masaken Pharmacy','صيدليات','Pharmacies','دمشق','Damascus','33.54772','36.31985','OpenStreetMap/Mapcarta','8G5RG8X9+3W'),
(2163,'صيدلية العطاء','Al-Ataa Pharmacy','صيدليات','Pharmacies','دمر، دمشق','Dummar, Damascus','33.54062','36.24363','OpenStreetMap/Mapcarta','8G5RG6RV+6F'),
(2164,'صيدلية سلامة','Salama Pharmacy','صيدليات','Pharmacies','نهر عيشة، دمشق','Nahr Aisha, Damascus','33.50300','36.27300','OpenStreetMap/Mapcarta','8G5RF7PQ+J6'),
(2165,'صيدلية كبب','Kabab Pharmacy','صيدليات','Pharmacies','دمشق','Damascus','33.49957','36.29475','OpenStreetMap/Mapcarta','8G5RF7XV+RW'),
(2166,'مشفى الهلال الأحمر','Red Crescent Hospital','مشافي','Hospitals','دمشق','Damascus','33.51400','36.30783','OpenStreetMap/Mapcarta','8G5RG8C5+F4'),
(2167,'مشفى التوفيق','Al-Tawfiq Hospital','مشافي','Hospitals','دمشق، قرب بولفار دمشق','Damascus, near Damascus Boulevard','33.51410','36.29030','OpenStreetMap/Mapcarta','8G5RG77Q+XP'),
(2168,'مشفى الكندي','Al-Kindi Hospital','مشافي','Hospitals','دمشق','Damascus','33.50583','36.29578','OpenStreetMap/Mapcarta','8G5RG74W+88'),
(2169,'مشفى الشرق','Al-Sharq Hospital','مشافي','Hospitals','دمشق','Damascus','33.51900','36.29600','OpenStreetMap/Mapcarta','8G5RG79W+H6'),
(2170,'مستشفى المهايني الحديث','Al-Mahaini Modern Hospital','مشافي','Hospitals','الميدان، دمشق','Al-Midan, Damascus','33.48869','36.29470','OpenStreetMap/Mapcarta','8G5RF7QV+FV'),
(2171,'فروج وائل','Waeil Chicken Restaurant','مطاعم','Restaurants','دمشق','Damascus','33.48679','36.29213','OpenStreetMap/Mapcarta','8G5RF7PR+PR'),
(2172,'هارموني كافيه','Harmony Cafe','مقاهي','Cafes','دمشق','Damascus','33.51608','36.31939','OpenStreetMap/Mapcarta','8G5RG889+CQ'),
(2173,'المطعم الصحي','Healthy Restaurant','مطاعم','Restaurants','ركن الدين، دمشق','Rukn Al-Din, Damascus','33.51914','36.29411','OpenStreetMap/Mapcarta','8G5RG79V+MJ'),
(2174,'أبو عارف','Abu Arif Restaurant','مطاعم','Restaurants','المزة، دمشق','Al Mazzeh, Damascus','33.50069','36.24845','OpenStreetMap/Mapcarta','8G5RG62X+79'),
(2175,'مطعم السماح وعربشة','Al-Samah & Arabasha Restaurant','مطاعم','Restaurants','المزة الغربية، دمشق','West Mezzeh, Damascus','33.50069','36.24850','OpenStreetMap/Mapcarta','8G5RG62X+7C'),
(2176,'مطعم باب مصلى','Bab Musalla Restaurant','مطاعم','Restaurants','باب مصلى، دمشق','Bab Musalla, Damascus','33.49916','36.29978','OpenStreetMap/Mapcarta','8G5RF7XX+MW'),
(2177,'مطعم ومقهى أشكم','Askim Restaurant and Cafe','مطاعم ومقاهي','Restaurants & Cafes','دمشق','Damascus','33.51412','36.29022','OpenStreetMap/Mapcarta','8G5RG77R+J3'),
(2178,'مزاج','Mazaj Restaurant','مطاعم','Restaurants','برزة، دمشق','Barzeh, Damascus','33.53985','36.30572','OpenStreetMap/Mapcarta','8G5RG8Q4+W7'),
(2179,'دار مسك','Dar Misk Restaurant','مطاعم','Restaurants','دمشق القديمة','Old Damascus','33.50653','36.30730','OpenStreetMap/Mapcarta','8G5RG844+JW'),
(2180,'السوق التجاري','Commercial Market','أسواق ومولات','Markets & Malls','دمشق','Damascus','33.55152','36.31527','OpenStreetMap/Mapcarta','8G5RH828+J4'),
]
for id_,ar,en,ca,ce,aa,ae,lat,lon,source,plus in new:
    lat=float(lat);lon=float(lon)
    key=ar.strip().lower(); c=(round(lat,5),round(lon,5))
    if key in existing_names or c in existing_coords: continue
    rows.append({'id':id_,'name_ar':ar,'name_en':en,'category_ar':ca,'category_en':ce,'address_ar':aa,'address_en':ae,'phone':'','latitude':lat,'longitude':lon,'rating':None,'review_count':0,'hours':'','hours_en':'','aliases':[ar,en,plus.lower()],'source':source,'verification':'coordinate_and_place_type_verified_2026-09-19','last_verified':'2026-09-19','opening_hours':[]})
    existing_names.add(key);existing_coords.add(c)
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
# generate JS wrapper matching existing format
js=root/'mobile_app/data/places.js'
js.write_text('window.DALIL_LOCAL_PLACES = '+json.dumps(rows,ensure_ascii=False,indent=2)+';\n',encoding='utf-8')
# sync Android embedded mobile app
src=root/'mobile_app'; dst=root/'android/app/src/main/assets/mobile_app'
if dst.exists(): shutil.rmtree(dst)
shutil.copytree(src,dst)
print('TOTAL',len(rows))
print('ADDED',len(rows)-181)
print('UNIQUE_IDS',len({x['id'] for x in rows}))
print('UNIQUE_COORDS',len({(round(float(x['latitude']),5),round(float(x['longitude']),5)) for x in rows}))
