# Dalil Syria V0.12 — Release Hardening

V0.12 is the final build-hardening pass before Release Candidate 1.

## Included
- API version 0.12.0.
- Strict `/ready` readiness endpoint.
- Request IDs via `X-Request-ID`.
- Security response headers.
- Configurable CORS through `DALIL_CORS_ORIGINS`.
- Public place detail and search endpoints now filter out drafts/archived records.
- Search pagination now returns total/pages.
- Database indexes for public listing, favorites and review access patterns.
- Migration `010_v012_release.sql`.
- Release regression tests.

## Production environment
Set at minimum:
- `POSTGRES_PASSWORD`
- `DALIL_AUTH_SECRET`
- `DALIL_CORS_ORIGINS`

Never use the development fallback secrets in production.

## V11 worker runtime
The release now includes a dedicated background worker container for outbox and notification processing with replay-safe claim/ack/retry behavior. External delivery providers remain disabled until configured and approved.
