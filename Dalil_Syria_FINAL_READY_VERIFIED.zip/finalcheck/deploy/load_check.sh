#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
python -m compileall -q backend/app
if command -v pytest >/dev/null 2>&1; then pytest -q; else echo 'WARNING: pytest unavailable; skipped automated suite'; fi
if command -v curl >/dev/null 2>&1 && [ "${DALIL_LOAD_URL:-}" != "" ]; then
  n="${DALIL_LOAD_REQUESTS:-200}"
  i=0; ok=0
  while [ "$i" -lt "$n" ]; do
    if curl -fsS --max-time 5 "$DALIL_LOAD_URL" >/dev/null 2>&1; then ok=$((ok+1)); fi
    i=$((i+1))
  done
  echo "Load smoke: $ok/$n successful"
  [ "$ok" -eq "$n" ]
else
  echo 'Load smoke not run: set DALIL_LOAD_URL to a reachable health/readiness URL.'
fi
