from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP

@dataclass(frozen=True)
class Money:
    amount_minor: int
    currency_code: str
    def add(self, other):
        if self.currency_code != other.currency_code: raise ValueError('currency mismatch')
        return Money(self.amount_minor + other.amount_minor, self.currency_code)
    def subtract(self, other):
        if self.currency_code != other.currency_code: raise ValueError('currency mismatch')
        return Money(self.amount_minor - other.amount_minor, self.currency_code)
    def multiply(self, rate):
        return Money(int((Decimal(self.amount_minor) * Decimal(str(rate))).quantize(Decimal('1'), rounding=ROUND_HALF_UP)), self.currency_code)
    def allocate(self, parts):
        if not parts or any(p < 0 for p in parts) or sum(parts) <= 0: raise ValueError('invalid allocation')
        q, r = divmod(self.amount_minor, sum(parts)); return [Money(q*p + (1 if i < r else 0), self.currency_code) for i,p in enumerate(parts)]
