from pathlib import Path

def test_v011_migration_exists():
    assert Path('database/009_v011_admin_content.sql').exists()

def test_admin_moderation_routes_exist():
    text=Path('backend/app/main.py').read_text()
    for route in ['/api/v1/admin/reviews','/api/v1/admin/reports','/api/v1/admin/users','/api/v1/admin/audit']:
        assert route in text

def test_api_version_is_v011():
    text=Path('backend/app/main.py').read_text()
    assert 'version="0.12.0"' in text
