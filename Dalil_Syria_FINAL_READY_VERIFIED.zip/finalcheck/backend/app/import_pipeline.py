"""Provider-neutral CSV import preparation: normalize, validate, score duplicates."""
import csv, io, re
from dataclasses import dataclass
from .imports import duplicate_score
from .maps import validate_coordinates

REQUIRED = ('name',)
ALIASES = {'الاسم':'name','اسم':'name','name':'name','title':'name','الهاتف':'phone','phone':'phone','العنوان':'address','address':'address','خط العرض':'latitude','latitude':'latitude','خط الطول':'longitude','longitude':'longitude'}

def normalize_text(value):
    return re.sub(r'\s+', ' ', (value or '').replace('\u200f','').replace('\u200e','')).strip()

def normalize_row(row):
    out={}
    for k,v in row.items():
        key=ALIASES.get(normalize_text(k).casefold(), normalize_text(k).casefold())
        out[key]=normalize_text(v)
    return out

def parse_csv(text):
    reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
    if not reader.fieldnames: raise ValueError('CSV header is required')
    return [normalize_row(r) for r in reader]

@dataclass(frozen=True)
class Validation:
    valid: bool
    reason: str | None = None

def validate_row(row):
    if not normalize_text(row.get('name')): return Validation(False,'name_required')
    try:
        lat=row.get('latitude'); lon=row.get('longitude')
        if lat or lon:
            if not lat or not lon: return Validation(False,'coordinates_incomplete')
            validate_coordinates(float(lat), float(lon))
    except (TypeError, ValueError): return Validation(False,'invalid_coordinates')
    return Validation(True)

def classify_duplicate(row, candidates):
    best_score=0; best_id=None
    for candidate in candidates:
        score=duplicate_score(row.get('name',''), row.get('phone'), candidate.get('name',''), candidate.get('phone'))
        if score>best_score:
            best_score, best_id=score, candidate.get('id')
    return {'duplicate': best_score >= 70, 'score': best_score, 'place_id': best_id}
