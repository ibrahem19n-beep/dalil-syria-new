# دليل سوريا — RELEASE 1.0.0

هذه هي حزمة الإصدار النهائية القابلة للتسليم بعد RC2 وPRODUCTION.

## الحالة
- Release: **1.0.0**
- **Core project baseline: V0.12**
- Technical packaging freeze: historical V8 label (packaging only; not the core project version)
- API: **0.12.0**
- Production deployment: Docker Compose + Caddy
- PostgreSQL/PostGIS: داخلي وغير منشور للعامة
- HTTPS: إلزامي عبر Caddy في بيئة الإنتاج
- Backup/Restore: متوفران في `deploy/`

## التشغيل الإنتاجي
1. انسخ `.env.example` إلى `.env` على الخادم.
2. استبدل جميع القيم التجريبية بأسرار قوية وفريدة.
3. اضبط `CADDY_DOMAIN` على النطاق الحقيقي.
4. اضبط `DALIL_CORS_ORIGINS` على أصل التطبيق الحقيقي فقط.
5. شغّل `deploy/release_check.sh` قبل الإطلاق.
6. شغّل `docker compose -f deploy/docker-compose.production.yml up -d --build`.
7. تحقق من `/health` و`/ready` و`/api/v1/meta` من خلال النطاق HTTPS.
8. اختبر النسخ الاحتياطي والاستعادة قبل اعتبار النظام جاهزاً نهائياً.

> لا تُعتبر بيئة الإنتاج متحققة فعلياً إلا بعد تشغيل Docker على خادم حقيقي واختبار DNS وTLS والنسخ الاحتياطي والاستعادة.

## ما لم يُفعل تلقائياً
- لا توجد مفاتيح إنتاج حقيقية داخل الحزمة.
- لا يتم نشر قاعدة البيانات أو Backend مباشرة إلى الإنترنت.
- لا يتم تفعيل المدفوعات/الإعلانات/الاشتراكات تلقائياً.

## V7 production verification
Run `./deploy/security_check.sh` for static production hardening checks. Use `DALIL_LOAD_URL=... ./deploy/load_check.sh` for a reachable deployment smoke test.


## PWA hardening
- Service worker added for the public mobile app shell.
- Local static assets use cache-first for faster repeat opens.
- Navigation falls back to the cached app shell when offline.
- API responses are intentionally not cached by the service worker.
- No additional visual asset was selected or installed in this step.
