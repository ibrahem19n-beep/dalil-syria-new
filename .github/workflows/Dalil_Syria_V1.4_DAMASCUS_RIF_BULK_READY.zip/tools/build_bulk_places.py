#!/usr/bin/env python3
import argparse, json, math, re, sys
from pathlib import Path

# Coarse bbox used only to reduce the cloud query. Final membership is determined
# by the exact Overture division polygons for Damascus (SY-DI) and Rif Dimashq (SY-RD).
BBOX = (35.70, 32.90, 37.45, 34.35)  # west, south, east, north
RELEASE = '2026-08-19.0'
TARGET_REGIONS = ('SY-DI', 'SY-RD')
REGION_NAMES = {
    'SY-DI': ('دمشق', 'Damascus'),
    'SY-RD': ('ريف دمشق', 'Rif Dimashq'),
}
ARABIC_RE = re.compile(r'[\u0600-\u06ff]')


def norm(s: str) -> str:
    s = str(s or '').strip().lower().replace('ـ', '')
    s = re.sub(r'[\u064B-\u065F\u0670]', '', s)
    return re.sub(r'\s+', ' ', s)


def clean_name(s: str) -> str:
    return re.sub(r'\s+', ' ', str(s or '').strip())


def category(primary: str, basic: str = ''):
    s = f'{primary} {basic}'.lower()
    rules = [
        (['restaurant', 'food', 'bakery', 'confectionery', 'pizza', 'مطعم', 'مخبز', 'حلويات'], 'مطاعم', 'Restaurants'),
        (['cafe', 'coffee', 'tea_house', 'مقهى', 'كوفي'], 'مقاهي', 'Cafes'),
        (['hotel', 'lodging', 'hostel', 'resort', 'فندق', 'نزل', 'منتجع'], 'فنادق', 'Hotels'),
        (['pharmacy', 'صيدلي'], 'صيدلية', 'Pharmacies'),
        (['hospital', 'clinic', 'healthcare', 'مشفى', 'مستشفى', 'عيادة', 'مركز صحي'], 'مشافي', 'Hospitals'),
        (['fuel', 'gas_station', 'petrol', 'محطة وقود', 'بنزين'], 'محطات وقود', 'Fuel Stations'),
        (['supermarket', 'grocery', 'convenience_store', 'سوبر', 'بقال', 'ماركت'], 'سوبر ماركت', 'Supermarkets'),
        (['car', 'auto', 'vehicle', 'mechanic', 'car_repair', 'tire', 'سيارات', 'ميكانيك', 'إطارات'], 'خدمة سيارات', 'Car Services'),
        (['bank', 'exchange', 'currency', 'money', 'صراف', 'مصرف', 'حوالات'], 'صرافة', 'Exchange & Banking'),
        (['school', 'university', 'college', 'education', 'مدرسة', 'جامعة', 'معهد', 'تعليم'], 'تعليم', 'Education'),
        (['museum', 'attraction', 'landmark', 'tourism', 'monument', 'سياحة', 'متحف', 'معلم', 'موقع أثري'], 'سياحة', 'Tourism'),
        (['telecom', 'internet', 'computer', 'اتصالات', 'إنترنت', 'كمبيوتر'], 'إنترنت', 'Internet & Telecom'),
        (['shopping', 'mall', 'market', 'store', 'shop', 'retail', 'متجر', 'سوق', 'تسوق'], 'تسوق', 'Shopping'),
        (['pool', 'swimming', 'مسابح', 'مسبح'], 'مسابح', 'Pools'),
        (['chalet', 'vacation_rental', 'شاليه', 'شاليهات'], 'شاليهات', 'Chalets'),
        (['car_rental', 'rental', 'تأجير سيارات'], 'تأجير سيارات', 'Car Rental'),
    ]
    for needles, a, e in rules:
        if any(x in s for x in needles):
            return a, e
    return 'خدمات', 'Services'


def extract_first_struct_name(text):
    return text


def main():
    ap = argparse.ArgumentParser(description='Bulk import clean Dalil Syria places for Damascus + Rif Dimashq')
    ap.add_argument('--limit', type=int, default=10000)
    ap.add_argument('--input', default='mobile_app/data/places.json')
    ap.add_argument('--output', default='mobile_app/data/places.json')
    ap.add_argument('--release', default=RELEASE)
    args = ap.parse_args()
    if args.limit < 1:
        raise SystemExit('--limit must be >= 1')

    try:
        import duckdb
    except Exception as e:
        print('duckdb missing:', e, file=sys.stderr)
        return 2

    con = duckdb.connect()
    con.execute('INSTALL httpfs; LOAD httpfs; INSTALL spatial; LOAD spatial;')
    con.execute("SET s3_region='us-west-2'")

    west, south, east, north = BBOX
    release = str(args.release).strip()
    places_path = f's3://overturemaps-us-west-2/release/{release}/theme=places/type=place/*'
    divisions_path = f's3://overturemaps-us-west-2/release/{release}/theme=divisions/type=division_area/*'

    # Exact boundary: union the current Overture division areas for the two
    # governorates. The bbox is only a coarse prefilter.
    region_sql = f"""
    WITH region_parts AS (
      SELECT region, geometry
      FROM read_parquet('{divisions_path}', filename=true, hive_partitioning=1)
      WHERE country = 'SY'
        AND region IN ('SY-DI','SY-RD')
        AND bbox.xmax >= {west} AND bbox.xmin <= {east}
        AND bbox.ymax >= {south} AND bbox.ymin <= {north}
        AND geometry IS NOT NULL
    )
    SELECT region, ST_AsGeoJSON(geometry) AS geometry_json
    FROM region_parts
    ORDER BY region
    """
    try:
        region_rows = con.execute(region_sql).fetchall()
    except Exception as e:
        print('OVERTURE_REGION_QUERY_FAILED', e, file=sys.stderr)
        return 3

    regions = {}
    for code, geom_json in region_rows:
        if code in TARGET_REGIONS and geom_json:
            regions.setdefault(code, []).append(json.loads(geom_json))
    missing = [c for c in TARGET_REGIONS if c not in regions]
    if missing:
        print('Missing exact Overture division polygons:', ','.join(missing), file=sys.stderr)
        return 4

    # Build the exact target polygon in DuckDB for a spatial point-in-region filter.
    region_geom_sql = f"""
    SELECT region, ST_Union_Agg(geometry) AS geometry
    FROM read_parquet('{divisions_path}', filename=true, hive_partitioning=1)
    WHERE country = 'SY'
      AND region IN ('SY-DI','SY-RD')
      AND bbox.xmax >= {west} AND bbox.xmin <= {east}
      AND bbox.ymax >= {south} AND bbox.ymin <= {north}
      AND geometry IS NOT NULL
    GROUP BY region
    """

    # The schema after the September release moved away from the legacy categories
    # field; use basic_category + taxonomy.primary instead.
    sql = f"""
    WITH regions AS ({region_geom_sql}),
    target AS (SELECT ST_Union_Agg(geometry) AS geometry FROM regions)
    SELECT
       p.id,
       p.names.primary AS name_primary,
       p.basic_category AS basic_category,
       p.taxonomy.primary AS taxonomy_primary,
       p.confidence,
       p.addresses[1].freeform AS address_freeform,
       p.addresses[1].locality AS address_locality,
       p.addresses[1].region AS address_region,
       p.addresses[1].postcode AS address_postcode,
       p.phones[1] AS phone_primary,
       p.websites[1] AS website_primary,
       p.operating_status,
       to_json(p.sources) AS sources_json,
       CASE WHEN ST_Intersects(p.geometry, di.geometry) THEN 'SY-DI' ELSE 'SY-RD' END AS governorate_code,
       ST_X(p.geometry) AS lon,
       ST_Y(p.geometry) AS lat
    FROM read_parquet('{places_path}', filename=true, hive_partitioning=1) p
    CROSS JOIN target t
    JOIN regions di ON di.region = 'SY-DI'
    JOIN regions rd ON rd.region = 'SY-RD'
    WHERE p.geometry IS NOT NULL
      AND p.bbox.xmax >= {west} AND p.bbox.xmin <= {east}
      AND p.bbox.ymax >= {south} AND p.bbox.ymin <= {north}
      AND ST_Intersects(p.geometry, t.geometry)
      AND COALESCE(p.confidence, 0) >= 0.50
      AND COALESCE(p.operating_status, 'open') <> 'permanently_closed'
    ORDER BY
      COALESCE(p.confidence, 0) DESC,
      (p.phones IS NOT NULL) DESC,
      (p.websites IS NOT NULL) DESC,
      (p.addresses IS NOT NULL) DESC
    LIMIT {max(args.limit * 4, 40000)}
    """
    try:
        rows = con.execute(sql).fetchall()
    except Exception as e:
        print('OVERTURE_PLACES_QUERY_FAILED', e, file=sys.stderr)
        return 5

    out = []
    seen_exact = set()
    used_phones = {}
    for r in rows:
        (oid, name, basic, tax, conf, address, locality, region, postcode,
         phone, website, status, sources_json, governorate_code, lon, lat) = r
        if not name or lon is None or lat is None:
            continue
        name = clean_name(name)
        if not name:
            continue
        lon = float(lon); lat = float(lat)
        if not (west <= lon <= east and south <= lat <= north):
            continue
        primary_cat = str(tax or basic or '')
        cat_ar, cat_en = category(primary_cat, str(basic or ''))
        ar = name if ARABIC_RE.search(name) else ''
        en = name if not ar else ''
        addr = clean_name(address or '')
        if locality and locality not in addr:
            addr = f'{addr}, {locality}' if addr else str(locality)
        if postcode and postcode not in addr:
            addr = f'{addr}, {postcode}' if addr else str(postcode)

        exact_key = (str(oid), round(lat, 6), round(lon, 6))
        if exact_key in seen_exact:
            continue
        seen_exact.add(exact_key)

        phone_s = str(phone or '').strip()
        phone_norm = re.sub(r'\D+', '', phone_s)
        quality = round(
            min(1.0, max(0.0, float(conf or 0))) * 0.65
            + (0.15 if phone_s else 0)
            + (0.10 if website else 0)
            + (0.10 if addr else 0), 3
        )
        verification = 'source_confirmed' if quality >= 0.75 else 'imported'
        pid = 200000000 + len(out) + 1
        out.append({
            'id': pid,
            'name_ar': ar or name,
            'name_en': en or name,
            'category_ar': cat_ar,
            'category_en': cat_en,
            'address_ar': addr,
            'address_en': addr,
            'phone': phone_s,
            'website': str(website or ''),
            'latitude': lat,
            'longitude': lon,
            'rating': None,
            'review_count': 0,
            'hours': '',
            'hours_en': '',
            'aliases': [name],
            'source': f'Overture Maps Places {release}',
            'source_id': str(oid),
            'source_records_json': str(sources_json or ''),
            'confidence': round(float(conf or 0), 4),
            'quality_score': quality,
            'operating_status': str(status or ''),
            'region_scope': 'SY-DI,SY-RD',
            'governorate_code': governorate_code,
            'governorate_ar': REGION_NAMES.get(governorate_code, ('',''))[0],
            'governorate_en': REGION_NAMES.get(governorate_code, ('',''))[1],
            'verification': verification,
            'last_verified': '2026-09-20',
        })
        if phone_norm:
            used_phones.setdefault(phone_norm, []).append(pid)
        if len(out) >= args.limit:
            break

    old_path = Path(args.input)
    old = json.loads(old_path.read_text(encoding='utf-8')) if old_path.exists() else []
    merged = []
    seen_merge = set()
    seen_old_ids = set()
    for p in old:
        try:
            pid = int(p['id'])
            lat = float(p['latitude']); lon = float(p['longitude'])
        except Exception:
            continue
        if pid in seen_old_ids:
            continue
        seen_old_ids.add(pid)
        name_key = norm(p.get('name_ar') or p.get('name_en') or p.get('name'))
        key = (round(lat, 5), round(lon, 5), name_key)
        if key in seen_merge:
            continue
        merged.append(p)
        seen_merge.add(key)

    for p in out:
        key = (round(p['latitude'], 5), round(p['longitude'], 5), norm(p.get('name_ar') or p.get('name_en')))
        if key in seen_merge:
            continue
        merged.append(p)
        seen_merge.add(key)

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(merged, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')

    # Keep explicit large import batches for audit/rebuild without requiring a new APK per batch.
    bulk = [p for p in merged if int(p['id']) >= 200000000]
    bdir = Path('bulk_batches')
    bdir.mkdir(exist_ok=True)
    for old_batch in bdir.glob('places_batch_*.json'):
        old_batch.unlink()
    sizes = [2000, 2000, 2000, 2000, 2000]
    pos = 0; bi = 1
    for size in sizes:
        if pos >= len(bulk):
            break
        batch = bulk[pos:pos + size]
        pos += size
        (bdir / f'places_batch_{bi:02d}.json').write_text(
            json.dumps(batch, ensure_ascii=False, separators=(',', ':')), encoding='utf-8'
        )
        bi += 1

    # Store the exact source polygons used for the region filter for auditing.
    boundary = {
        'type': 'FeatureCollection',
        'features': [
            {
                'type': 'Feature',
                'properties': {'code': code, 'name_ar': REGION_NAMES[code][0], 'name_en': REGION_NAMES[code][1]},
                'geometry': geom_parts[0] if len(geom_parts) == 1 else {'type': 'GeometryCollection', 'geometries': geom_parts},
            }
            for code, geom_parts in regions.items()
        ]
    }
    Path('bulk_batches/damascus_rif_dimashq_boundaries.geojson').write_text(
        json.dumps(boundary, ensure_ascii=False, separators=(',', ':')), encoding='utf-8'
    )

    manifest = {
        'release': release,
        'target_regions': list(TARGET_REGIONS),
        'coarse_bbox': BBOX,
        'boundary_source': 'Overture divisions division_area; exact spatial intersection',
        'verified_existing': len(old),
        'overture_candidates_after_exact_boundary': len(rows),
        'overture_cleaned_selected': len(out),
        'bulk_total_after_merge_dedupe': len(bulk),
        'final_total': len(merged),
        'target_limit': args.limit,
        'batches_created': bi - 1,
        'verification_counts': {},
    }
    for p in bulk:
        k = p.get('verification', 'imported')
        manifest['verification_counts'][k] = manifest['verification_counts'].get(k, 0) + 1

    Path('bulk_batches/MANIFEST.json').write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8'
    )
    print(json.dumps(manifest, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
